<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Fitser</title>
    <link rel="shortcut icon" href="<?=base_url()?>public/front_assets/css/images/favIcon.png" type="image/x-icon">
    <link rel="icon" href="<?=base_url()?>public/front_assets/css/images/favIcon.png" type="image/x-icon">
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700" rel="stylesheet">
    <!-- BOOTSTRAP STYLE -->
    <link rel="stylesheet" type="text/css" href="<?=base_url()?>public/front_assets/css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="<?=base_url()?>public/front_assets/css/bootstrap-datetimepicker.css"/>
    <!-- JQUERY LIBRARY -->
    <script type="text/javascript" src="<?=base_url()?>public/front_assets/js/jquery-2.1.4.js"></script>
    <!-- BOOTSTRAP SCRIPTS -->
    <script type="text/javascript" src="<?=base_url()?>public/front_assets/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="<?=base_url()?>public/front_assets/js/moment-with-locales.js"></script>
    <script type="text/javascript" src="<?=base_url()?>public/front_assets/js/bootstrap-datetimepicker.js"></script>
    <script src="<?=base_url()?>public/front_assets/js/jquery.counterup.min.js"></script>
    <script src="<?=base_url()?>public/front_assets/js/script.js"></script>
    <!-- FONT AWESOME-->
    <link rel="stylesheet" type="text/css" href="<?=base_url()?>public/front_assets/css/font-awesome.css" />
    <link rel="stylesheet" type="text/css" href="<?=base_url()?>public/front_assets/owlcarousel/animate.css">
    <link rel="stylesheet" href="<?=base_url()?>public/front_assets/owlcarousel/owl.carousel.min.css">
    <link rel="stylesheet" href="<?=base_url()?>public/front_assets/owlcarousel/owl.theme.default.min.css">
    <script src="<?=base_url()?>public/front_assets/owlcarousel/owl.carousel.min.js"></script>
    <!-- SITE STYLES -->
    <link rel="stylesheet" type="text/css" href="<?=base_url()?>public/front_assets/css/global.css" />
    <link rel="stylesheet" type="text/css" href="<?=base_url()?>public/front_assets/css/site.css" />
    <link rel="stylesheet" type="text/css" href="<?=base_url()?>public/front_assets/css/responsive.css" />
    <link rel="stylesheet" type="text/css" href="<?=base_url()?>public/front_assets/css/intlTelInput.css" />
    <style>
      #contact_submit {
        background: #990000;
          text-align: center;
          color: #fff;
          width: 100%;
          padding: 15px;
          font-family: 'Lato', sans-serif;
          font-weight: 700;
          font-size: 15px;
          border: 0;
      }
      input.error {
          border: 1px dotted red;
      }
      textarea.error {
          border: 1px dotted red;
      }
      .form-group {
          position: relative;
      }
    </style>
</head>
<body>
<div class="side_quote"> <img class="show_side" src="<?=base_url()?>public/front_assets/css/images/request.png">
  <form action="#">
    <div class="form-group">
      <input type="text" class="form-control" id="" placeholder="Name">
    </div>
    <div class="form-group">
      <input type="text" class="form-control" id="" placeholder="Email">
    </div>
    <div class="form-group">
      <input type="text" class="form-control" id="" placeholder="Phone No">
    </div>
    <div class="form-group">
      <textarea class="form-control" id="" placeholder="Your Message" rows="2"></textarea>
    </div>
    <div class=" text-left">
      <button type="submit" class="btn btn-success">Submit</button>
      <button type="submit" class="btn btn-danger">Close</button>
    </div>
  </form>
</div>
<header class="land_header">
  <div class="container">
    <div class="row">
      <div class="col-sm-3"> <a href="https://www.fitser.com/" class="logo"><img src="<?=base_url()?>public/front_assets/css/images/logo.png" alt="*" /></a> </div>
      <!-- col-sm-3 -->
      <div class="col-sm-9">
          <div class="wrapCallUs"> <span class="callUs"><img src="<?=base_url()?>public/front_assets/css/images/iconPhone.png" alt="*">Call Us Today : <span class="flag"><img src="<?=base_url()?>public/front_assets/css/images/flagUsa.png" alt="*"></span> <a href="tel:(+1) 3605383135">(+1) 3605383135 </a> <span class="flag"><img src="<?=base_url()?>public/front_assets/css/images/flagAus.png" alt="*"></span><a href="tel:(+61) 280113465">(+61) 280113465</a> </span>
            <ul class="listSocialTop">
              <li><a href="https://www.facebook.com/FitserNews" target="_blank"><i class="fa fa-facebook"></i></a></li>
              <li><a href="https://twitter.com/FitserNews" target="_blank"><i class="fa fa-twitter"></i></a></li>            
              <li><a href="https://www.linkedin.com/company/fitser" target="_blank"><i class="fa fa-linkedin"></i></a></li>
              <li><a href="https://www.youtube.com/c/FitserNews" target="_blank"><i class="fa fa-youtube"></i></a></li>
            </ul>
          </div>
      </div>
      <!-- col-sm-9 --> 
    </div>
  </div>
</header>
<div class="wraperBanner"> <img src="<?=base_url()?>public/front_assets/css/images/banner3.jpg" alt="" />
 <div class="banner_caption web_dev">
 	<h2>Website Development Services For Your Business </h2>


 	<!-- <h4>WEB DEVELOPMENT</h4> -->
 </div>
  <div class="banner_form">
    <div class="wraperGITForm" id="GITForm">
      <h2>Get in Touch with Us </h2>
      <div class="GITBody">
        <form action="" method="post" id="contact_form" class="contact_form">
          <?php if($this->session->flashdata('success_msg')){?>
            <div class="success_msg">
                <p><?php echo $this->session->flashdata('success_msg'); ?></p>
            </div>
          <?php }?>
          <div class="form-group">
              <input type="text" class="form-control" id="name" placeholder="Name" name="name" required autocomplete="off">
          </div>
          <div class="form-group">
              <input type="email" class="form-control" id="email" placeholder="Email" name="email" required autocomplete="off">
          </div>
          <div class="form-group">
              <div class="row">
                  <div class="col-xs-3">
                      <input type="text" class="form-control" id="country_code" placeholder="Country Code" name="country_code" title="Country Code">
                  </div>
                  <!-- col-sm-4 -->
                  <div class="col-xs-9">
                      <input type="text" class="form-control" id="phone" placeholder="Phone" name="phone" required autocomplete="off">
                  </div>
                  <!-- col-sm-8 -->
              </div>
              
          </div>
          <div class="form-group">
              <input type="text" class="form-control" id="schedule" placeholder="Schedule" name="schedule" required autocomplete="off" readonly>
          </div>
          <div class="form-group">
              <textarea class="form-control" id="message" placeholder="Message" rows="2" name="message" required autocomplete="off"></textarea>
          </div>
          <div class="">
            <input type="submit" class="btn btn-default" id="contact_submit" value="Submit">
          </div>
        </form>
      </div>
    </div>
    <!-- wraperGITForm --> 
  </div>
  <!-- text-right --> 
</div>

<!-- wraperBanner -->
<div class="sectionWelcome">
  <div class="container">
    <h1>Welcome</h1>
    <p>We hold an omnipotent position in serving the customers and providing them a reliable, classy and standard solution regarding their project demand. We ensure the customers wide range of services, professionalism and perfection.</p>
    <p>You have a website with wonderful images, great content and a commendable web design. Still you are not acquiring desired results.</p>
    <p>WONDERING ABOUT THE REASON BEHIND?<br>
      ARE YOU VISIBLE TO THE TARGETED AUDIENCE?<br>
      Chances of getting noticed reduce substantially if you are not present on the first page of Google and other search engines. Can you really afford to stay back when your competition is already on the first page of the search engine results?</p>
    <p>The search engines are capacitated to drive the modern consumers to the requisite service or product. With expertise in strategic SEO solutions, at Fitser, we design solutions to drive traffic and sales to local businesses as well as the e-commerce and the corporate websites. We, a web design company with presence in Australia, India, Romania, Panama and the United Kingdom invest in research and development and come with the requisite tools and data to help your business acquire more leads.</p>
    <p>If you want to better your visibility, ranking in the search engine results pages and increase traffic, we are just a call away.</p>
    <p><a href="#GITForm" class="btnCallBack">Request a Call Back</a></p>
  </div>
</div>
<!-- sectionWelcome --> 

<!-- Portfolio:Start -->
<div class="home-portfolio">
  <div class="container">
    <h2>Our Portfolio</h2>
    <div class="port_box">
     <div class="portfolio-view-all"> <a href="#">view all</a> </div>
      <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 portfolio-nav">
        <div>
          <div class="left-nav mt">
            <ul class="nav nav-pills nav-stacked">
              <!--<li><a data-toggle="tab" href="#menu-1">All</a></li>-->
              <li class="active"><a data-toggle="tab" href="#menu-2" style="color: #fff;">Web Development</a></li>
              <!--<li><a data-toggle="tab" href="#menu-3">Web Design</a></li>
              <li><a data-toggle="tab" href="#menu-4">Graphic design</a></li>
              <li><a data-toggle="tab" href="#menu-5">Logo Design</a></li>-->
            </ul>
          </div>
          <div class="clearfix"></div>
          <h1 class="portfolio-heading">our portfolio</h1>
          <h1 class="portfolio-link-no">01</h1>
        </div>
      </div>
      <!--/.col4-->
      <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12 portfolio-wrapper">
        <div class="tab-content">
          
          <div id="menu-2" class="tab-pane fade in active">
            <div class="row">
              <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
                <div class="row">
                  <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 portfolio-padding-fixer"> <img src="<?=base_url()?>public/front_assets/images/web1.png" class="img-responsive center-block">
                    <div class="overlay-portfolio">
                      <div>
                        <div>
                          <h1>STAR SHIP</h1>
                          <p>Web Development</p>
                          <a href="#"> <i class="fa fa-arrows-alt" aria-hidden="true"></i> </a> <a href="#"> <i class="fa fa-paperclip" aria-hidden="true"></i> </a> </div>
                      </div>
                    </div>
                    <!--/.overlay-portfolio--> 
                  </div>
                  <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 portfolio-padding-fixer"> <img src="<?=base_url()?>public/front_assets/images/web2.png" class="img-responsive center-block">
                    <div class="overlay-portfolio">
                      <div>
                        <div>
                          <h1>SMASH REPAIRS</h1>
                          <p>Web Development</p>
                          <a href="#"> <i class="fa fa-arrows-alt" aria-hidden="true"></i> </a> <a href="#"> <i class="fa fa-paperclip" aria-hidden="true"></i> </a> </div>
                      </div>
                    </div>
                    <!--/.overlay-portfolio--> 
                  </div>
                </div>
                <!--/.row-->
                <div class="row">
                  <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 portfolio-padding-fixer"> <img src="<?=base_url()?>public/front_assets/images/web4.png" class="img-responsive center-block">
                    <div class="overlay-portfolio">
                      <div>
                        <div>
                          <h1>BASSI GROUP</h1>
                          <p>Web Development</p>
                          <a href="#"> <i class="fa fa-arrows-alt" aria-hidden="true"></i> </a> <a href="#"> <i class="fa fa-paperclip" aria-hidden="true"></i> </a> </div>
                      </div>
                    </div>
                    <!--/.overlay-portfolio--> 
                  </div>
                </div>
                <!--/.row--> 
              </div>
              <!--/.col6-->
              <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 portfolio-padding-fixer"> <img src="<?=base_url()?>public/front_assets/images/web3.png" class="img-responsive center-block">
                <div class="overlay-portfolio">
                  <div>
                    <div>
                      <h1>GLOBAL</h1>
                      <p>Web Development</p>
                      <a href="#"> <i class="fa fa-arrows-alt" aria-hidden="true"></i> </a> <a href="#"> <i class="fa fa-paperclip" aria-hidden="true"></i> </a> </div>
                  </div>
                </div>
                <!--/.overlay-portfolio--> 
              </div>
              <!--/.col6--> 
            </div>
            <!--/.row-->
            <div class="row">
              <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 portfolio-padding-fixer"> <img src="<?=base_url()?>public/front_assets/images/web5.png" class="img-responsive center-block">
                <div class="overlay-portfolio">
                  <div>
                    <div>
                      <h1>sweet bouquet</h1>
                       <p>Web Development</p>
                      <a href="#"> <i class="fa fa-arrows-alt" aria-hidden="true"></i> </a> <a href="#"> <i class="fa fa-paperclip" aria-hidden="true"></i> </a> </div>
                  </div>
                </div>
                <!--/.overlay-portfolio--> 
              </div>
              <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12 portfolio-padding-fixer"> <img src="<?=base_url()?>public/front_assets/images/web6.png" class="img-responsive center-block">
                <div class="overlay-portfolio">
                  <div>
                    <div>
                      <h1>THE MOON AND YOU</h1>
                       <p>Web Development</p>
                      <a href="#"> <i class="fa fa-arrows-alt" aria-hidden="true"></i> </a> <a href="#"> <i class="fa fa-paperclip" aria-hidden="true"></i> </a> </div>
                  </div>
                </div>
                <!--/.overlay-portfolio--> 
              </div>
            </div>
            <!--/.row--> 
          </div>
          
          
          
          
        </div>
        <!--/.tab-content--> 
      </div>
      <!--/.col8--> 
    </div>
    <!--/.row--> 
  </div>
  <!--/.container--> 
</div>
<!--/.row--> 
<!-- Portfolio:End -->

<div class="sectionClientSay">
  <div class="container">
    <h1>WHAT OUR CLIENT SAYS</h1>
    <div class="wraperTestimonials">
      <div class="iconTestimonial"> <img src="<?=base_url()?>public/front_assets/css/images/iconTestimonial.png" alt="*" /> </div>
      <div class="owl-carousel owl-theme sliderTestimonial">
        <div class="item">
          <div class="wrapTestimonials">
            <div class="contentTestimonials">
              <p class="author">LOUISE DEMARTIN</p>
              <p>Rakesh and his team have been wonderful in helping me produce a new website, very modern and interactive, I pad and I phone compatible with the ability to allow my colleagues to change our website any time we need to. I can highly recommend Rakesh for a difficult job well done. And I will add, at a very reasonable price. Thank you again</p>
            </div>
            <!-- contentTestimonials --> 
          </div>
        </div>
        <!-- item -->
        <div class="item">
          <div class="wrapTestimonials">
            <div class="contentTestimonials">
              <p class="author">FEARN ERIKA</p>
              <p>Thank you for all you have done for me and my business.  You have been great to work with</p>
              
            </div>
            <!-- contentTestimonials --> 
            
          </div>
        </div>
        <!-- item -->
        <div class="item">
          <div class="wrapTestimonials">
            <div class="contentTestimonials">
              <p class="author">NATALIE</p>
              <p>Great communication, always assisting us with our needs. Awesome to work with and very professional.</p>
            </div>
            <!-- contentTestimonials -->
          </div>
        </div>
        <!-- item -->
        <div class="item">
          <div class="wrapTestimonials">
            <div class="contentTestimonials">
              <p class="author">MIKE</p>
              <p>Fitser has been great with designing our webpage all the way through. They consistently encouraged the latest designs and tricks to help my website look professional and up to date. Soumo Pratihar, the manager who was dealing with my page, was always  polite and fast on getting the works done. It’s a company i could trust and would definitely recommend to anybody.</p>
              
            </div>
            <!-- contentTestimonials --> 
          </div>
        </div>
        <!-- item --> 
      </div>
      <!-- owl-carousol --> 
    </div>
    <!-- wraperTestimonials --> 
    <a href="#GITForm" class="btnCallBack">Request a Call Back</a> </div>
</div>
<!-- sectionClientSay -->
<div class="sectionCounter">
  <div class="container">
    <div class="row">
      <div class="col-sm-3">
        <div class="wraperCounter">
          <h3>Projects</h3>
          <div class="numscroller numscroller-big-bottom" data-slno="5" data-min="0" data-max="620" data-delay="1" data-increment="1">0</div>
        </div>
      </div>
      <!-- col-sm-3 -->
      <div class="col-sm-3">
        <div class="wraperCounter">
          <h3>Working Days</h3>
          <div class="numscroller numscroller-big-bottom" data-slno="5" data-min="0" data-max="365" data-delay="1" data-increment="1">0</div>
        </div>
      </div>
      <!-- col-sm-3 -->
      <div class="col-sm-3">
        <div class="wraperCounter">
          <h3>Team Member</h3>
          <div class="numscroller numscroller-big-bottom" data-slno="5" data-min="0" data-max="100" data-delay="1" data-increment="1">0</div>
        </div>
      </div>
      <!-- col-sm-3 -->
      <div class="col-sm-3">
        <div class="wraperCounter">
          <h3>Happy Clients</h3>
          <div class="numscroller numscroller-big-bottom" data-slno="5" data-min="0" data-max="500" data-delay="1" data-increment="1">0</div>
        </div>
      </div>
      <!-- col-sm-3 --> 
    </div>
  </div>
</div>
<!-- sectionCounter -->
<section class="callback">
  <div class="container">
    <h3>Have Questions? Feel Free To Ask Us!</h3>
    <a href="#" class="callback_bttn">Request A call back</a> </div>
</section>
<section class="footer">
  <div class="container">
    <h3>Contact Us</h3>
    <span><i class="fa fa-phone" aria-hidden="true"></i><a href="tel:03340624483">(+1) 3605383135, (+61) 280113465</a></span> <span><i class="fa fa-envelope" aria-hidden="true"></i><a href="mailto:info@fitser.com">info@fitser.com</a></span> </div>
</section>
<div class="sectionFooterBottom">
  <div class="container">
    <p>© 2018 Fitser . All Rights Reserved</p>
  </div>
</div>
    <!-- sectionFooterBottom --> 
    <script src="<?=base_url()?>public/front_assets/js/numscroller-1.0.js"></script>
    <script src="<?=base_url()?>public/front_assets/js/intlTelInput.js"></script>
    <script src="<?=base_url()?>public/front_assets/js/jquery.validate.min.js"></script>
    <script src="<?=base_url()?>public/front_assets/js/custom.js" type="text/javascript"></script>
    <script>
          $(function () {
                $('#schedule').datetimepicker({
                    format: 'DD-MM-YYYY HH:mm',
                    ignoreReadonly: true
                });
            });
        var input = document.querySelector("#country_code");
        window.intlTelInput(input, {
          autoPlaceholder: "off",
          separateDialCode: true,
        });
        $("#contact_form").validate({
          errorPlacement: function(error, element) {
          // Append error within linked label
          $( element )
            .closest( "form" )
              .find( "label[for='" + element.attr( "id" ) + "']" )
                .append( error );
        },
        errorElement: "span",
        messages: {
          name: {
            required: " (required)"
          },
          email: {
            required: " (required)",
            email: true
          },
          phone: {
            required: " (required)"
          },
          schedule: {
            required: " (required)"
          },
          message: {
            required: " (required)"
          }
        }
        })
    </script>
    <!--DATE TIME PICKER-->
</body>
</html>