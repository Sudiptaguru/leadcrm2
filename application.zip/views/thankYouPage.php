<!DOCTYPE html>
<html>
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Fitser</title>
    <link rel="shortcut icon" href="<?=base_url()?>public/front_assets/css/images/favIcon.png" type="image/x-icon">
    <link rel="icon" href="<?=base_url()?>public/front_assets/css/images/favIcon.png" type="image/x-icon">
    <link rel="stylesheet" type="text/css" href="<?=base_url()?>public/front_assets/css/all.css">
    
    
    <!-- Global site tag (gtag.js) - Google Ads: 784397410 -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=AW-784397410"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());
    
      gtag('config', 'AW-784397410');
    </script>
    <script>
      gtag('event', 'conversion', {'send_to': 'AW-784397410/DnLOCLz0h4wBEOLog_YC'});
    </script>

  </head>
  <body>
    <header class="land_header">
      <div class="container">
        <div class="row">
          <div class="col-sm-3"> <a href="#" class="logo"><img src="<?=base_url()?>public/front_assets/css/images/logo.png" alt="*" /></a> </div>
          <!-- col-sm-3 -->
          <div class="col-sm-9">
            <div class="wrapCallUs"><span class="callUs"><img src="<?=base_url()?>public/front_assets/css/images/iconPhone.png" alt="*">Call Us Today : <span class="flag"><img src="<?=base_url()?>public/front_assets/css/images/flagUsa.png" alt="*" /></span> <a href="tel:(+1) 3605383135">(+1) 3605383135 </a> <span class="flag"><img src="<?=base_url()?>public/front_assets/css/images/flagAus.png" alt="*" /></span><a href="tel:(+61) 280113465">(+61) 280113465</a> </span>
            <ul class="listSocialTop">
              <li><a href="https://www.facebook.com/FitserNews" target="_blank"><i class="fa fa-facebook"></i></a></li>
              <li><a href="https://twitter.com/FitserNews" target="_blank"><i class="fa fa-twitter"></i></a></li>
              <li><a href="https://www.linkedin.com/company/fitser" target="_blank"><i class="fa fa-linkedin"></i></a></li>
              <li><a href="https://www.youtube.com/c/FitserNews" target="_blank"><i class="fa fa-youtube"></i></a></li>
            </ul>
          </div>
        </div>
        <!-- col-sm-9 -->
      </div>
    </div>
  </header>
  <div class="wraperBanner"> <img src="<?=base_url()?>public/front_assets/css/images/bgBannerTy.jpg" alt="" />
    
  </div>
  <!-- wraperBanner -->
  <div class="contentThankYou">    
    <div class="">
      <p><i class="fa fa-check-circle"></i></p>
      <h4>Thank You</h4>
      <p>We will get back you soon</p>
      
    </div>
    <!-- container -->
  </div>
  <!-- contentThankYou -->
  <!-- sectionCounter -->
  <section class="callback">
    <div class="container">
      <h3 style="text-align:center;float: none;">Have Questions? Feel Free To Ask Us!</h3>
      <!-- <a href="#GITForm" class="callback_bttn">Request a Call Back</a> </div> -->
    </section>
    <section class="footer">
      <div class="container">
        <h3>Contact Us</h3>
        <span><i class="fa fa-phone" aria-hidden="true"></i><span class="flag"><img src="<?=base_url()?>public/front_assets/css/images/flagUsa.png" alt="*" /></span> <a href="tel:(+1) 3605383135">(+1) 3605383135 </a>
        <span class="flag"><img src="<?=base_url()?>public/front_assets/css/images/flagAus.png" alt="*" /></span><a href="tel:(+61) 280113465">(+61) 280113465</a>
      </span>
      <div> <span><i class="fa fa-envelope" aria-hidden="true"></i><a href="mailto:info@fitser.com">info@fitser.com</a></span> </div>
    </div>
  </section>
  <div class="sectionFooterBottom">
    <div class="container">
      <p>© <?=date('Y')?> Fitser . All Rights Reserved</p>
    </div>
  </div>
  <!-- sectionFooterBottom -->
</body>
</html>