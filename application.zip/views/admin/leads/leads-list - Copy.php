<!-- Load header -->
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
	<!-- Content Header (Page header) -->
	<section class="content-header">

		<ol class="bread_crumb">
			<li><a href="#"><img src="<?=base_url('public/admin/')?>images/home_ico.png" alt=""></a></li>
			<li><a href="<?=base_url('admin/leads')?>">Leads</a></li>
			<li class="active">My Leads</li>

		</ol>

		<ol class="breadcrumb setting_btn">
			<ul class="add_list">

				<li class=""><a href="#" class="btn btn-creat" data-toggle="modal"
						data-target="#ImportsModal">Import leads <i class="fa fa-caret-down"></i></a>

				</li>
				<li class=""><a href="#" class="btn btn-creat" data-toggle="modal"
						data-target="#ceartModal" id="add-lead-modal">Add lead <i class="fa fa-plus" aria-hidden="true"></i></a>

				</li>
				<!-- <li class="dropdown"><a href="" class="dropdown-toggle" type="button" data-toggle="dropdown"
						aria-haspopup="true" aria-expanded="false">Edit columns <i class="fa fa-caret-down"></i></a>
					<div class="dropdown-menu">
						<a class="dropdown-item" href="#">Follow up</a>
						<a class="dropdown-item" href="#">Call reminder</a>
						<a class="dropdown-item" href="#">Appointment</a>
					</div>
				</li>
				<li class="dropdown"><a href="" class="dropdown-toggle" type="button" data-toggle="dropdown"
						aria-haspopup="true" aria-expanded="false"><img src="<?=base_url('public/admin/')?>images/filter.png" alt=""></a>
					<div class="dropdown-menu">
						<a class="dropdown-item" href="#">Follow up</a>
						<a class="dropdown-item" href="#">Call reminder</a>
						<a class="dropdown-item" href="#">Appointment</a>
					</div>
				</li> -->
			</ul>
		</ol>
	</section>

	<!-- Main content -->
	<section class="content leads_page">
		<!-- Small boxes (Stat box) -->
		<div class="row">

			<div class="col-md-12">
				<div class="table-responsive">
					<table width="100%" border="0" cellspacing="0" cellpadding="0" class="table" id="leads_table">
						<thead>
							<tr>
								<th><input type="checkbox"></th>
								<th>Name</th>
								<th>Lead stage</th>
								<th>Last contacted time</th>
								<th>Sales owner</th>
								<th>Work</th>
								<th>subscription status</th>
								<th>Actions</th>
							</tr>
						</thead>
						<tbody>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</section>
	<!-- /.content -->
</div>

<!-- Modal -->
<div class="modal fade" id="ImportsModal" tabindex="-1" role="dialog" aria-labelledby="">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
						aria-hidden="true">&times;</span></button>
				<h4 class="modal-title" id="">IMPORT CONTACTS
					<span class="step_btn btn">Step 1 of 2</span></h4>

			</div>
			<div class="modal-body">
				<form action="" class="row">
					<div class="col-md-12">
						<p>Import your contacts using your own file, or use our <a href="">sample CSV</a>. <i
								class="fa fa-question-circle-o"></i> </p>
					</div>

					<div class="col-md-12">
						<div class="form-group">
							<div class="drag_sec">
								<div class="choose-file">
									<input type="file">
									<label><span class="img_sec"><img src="./images/csv_img.png" alt=""></span> Drop or upload your file
										here</label>
									<p>(.csv, .xlsx formats supported)</p>
								</div>
							</div>
						</div>
					</div>

					<div class="col-md-12">
						<div class="form-group">
							<label>Select an import option for this file</label>
							<select name="" id="" class="form-control">
								<option value="">Create new contacts</option>
								<option value="">Create new and update existing contacts (without overwrite)</option>
								<option value="">Create new and update existing contacts (with overwrite)</option>
							</select>
						</div>
					</div>
					<div class="col-md-12">

						<div class="form-group">
							<input type="checkbox" id="Skip"> <label for="Skip">Skip duplicates automatically by matching
								<span>Primary email <i class="fa fa-caret-down"></i></span></label>
						</div>

					</div>

					<div class="col-md-12">

						<div class="form-group">
							<a href="javascript:void(0)" class="show_more1">Manage email subscriptions <i
									class="fa fa-caret-down"></i></a>
							<span class="more_checkbox1">
								<div class="form-group">
									<input type="checkbox" id="Subscribe"> <label for="Subscribe">Subscribe contacts to all types of
										emails</label>
								</div>

							</span>
						</div>

					</div>
					<div class="col-md-12">

						<div class="form-group">
							<a href="javascript:void(0)" class="show_more2">Manage sales owner <i class="fa fa-caret-down"></i></a>
							<span class="more_checkbox2">
								<div class="form-group">
									<select id="single3" class="js-states form-control">
										<option>Sales Owner</option>
										<option>Sales Owner1</option>
										<option>Sales Owner2</option>
										<option>Sales Owner3</option>
									</select>
								</div>
							</span>
						</div>
					</div>
				</form>
			</div>
			<div class="modal-footer">

				<button type="button" class="btn btn-creat " data-dismiss="modal">Close</button>
				<button type="button" class="btn btn-save" data-dismiss="modal" data-toggle="modal"
					data-target="#ImportsModal1">Next</button>
			</div>
		</div>
	</div>
</div>

<!-- Modal -->
<div class="modal fade" id="ImportsModal1" tabindex="-1" role="dialog" aria-labelledby="">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
						aria-hidden="true">&times;</span></button>
				<h4 class="modal-title" id="">IMPORT CONTACTS
					<span class="step_btn btn">Step 2 of 2</span></h4>

			</div>
			<div class="modal-body">
				<form action="" class="row">
					<div class="col-md-12">
						<p>Map columns in your file to fields in Freshsales. </p>
						<hr>
					</div>

					<div class="col-md-6">
						<label><i class="fa fa-file-text-o"></i> FILE COLUMN </label>
					</div>
					<div class="col-md-6">
						<label>FRESHSALES FIELD</label>
					</div>
					<div class="col-md-12">
						<hr>
					</div>
					<div class="col-md-6">
						<p>dfsfsf</p>
					</div>
					<div class="col-md-6">

						<div class="form-group">
							<div class="form-group">
								<select id="single4" class="js-states form-control">
									<option>Choose a value</option>
									<option>Choose a value1</option>
									<option>Choose a value2</option>
									<option>Choose a value3</option>
								</select>
							</div>
						</div>

					</div>
				</form>
			</div>
			<div class="modal-footer">

				<button type="button" class="btn btn-creat " data-dismiss="modal" data-toggle="modal"
					data-target="#ImportsModal">Back</button>
				<button type="button" class="btn btn-save">Import</button>
			</div>
		</div>
	</div>
</div>
<?php
	/*---------Create dynamic lead form------------------------*/
	$saved_data = $this->common_model->select('company_contact_form_elements', ['user_id', $admin['id']], '*', 'rank', 'ASC');
?>
<!-- Add leade modal -->
<!-- Modal -->
<div class="modal fade" id="ceartModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
						aria-hidden="true">&times;</span></button>
				<h4 class="modal-title" id="myModalLabel">Add Lead</h4>
			</div>
			<form id="frm-lead" method="post" action="" class="">
				<div class="modal-body">
					<div class="col-md-12">
						<div class="form-group">
							<label>First Name</label>
							<input type="text" class="form-control" name="first_name" id="first_name" placeholder="First Name" required>
						</div>
					</div>
					<div class="col-md-12">
						<div class="form-group">
							<label>Last Name</label>
							<input type="text" class="form-control" name="last_name" id="last_name" placeholder="Last Name" required>
						</div>
					</div>
					<div class="col-md-12">
						<div class="form-group">
							<label>Company Name</label>
							<!-- <input type="text" class="form-control" name="company_name" id="company_name" placeholder="Company Name" required> -->
							<select name="company_name" id="company_name" class="js-states form-control company-list" required>
								<option>Sales Company</option>
							</select>
						</div>
					</div>
					<div class="col-md-12">
						<div class="row app_mail">
							<div class="form-group register_email">
								<div class="col-md-12">
									<label>Email</label>
								</div>								
								<div class="col-md-1">
									<input type="radio" name="RadioGroup1" value="radio" id="RadioGroup1_0" checked>
								</div>
								<div class="row email-section">
									<div class="col-md-6">
										<input type="email" class="form-control default" name="email[]" id="email" placeholder="Enter Value" required>
									</div>
									<div class="col-md-4">
										<select id="pick_label" name="pick_label[]" class="default js-states form-control" required>
											<option value="">Pick a label</option>
											<option value="work">Work</option>
											<option value="personal">Personal</option>
										</select>
									</div>
								</div>
							</div>
							<a href="#" class="btn btn-add app_btn add_email_section">
								<img src="<?=base_url('public/admin/')?>images/add_ico.png" alt=""> Add	Email
							</a>
						</div>
					</div>
					<div class="col-md-12">
						<div class="form-group">
							<label>Mobile</label>
							<input type="tel" minlength="10" maxlength="15" id="mobile" name="mobile" class="form-control" placeholder="Mobile" required>
						</div>
					</div>
					<div class="col-md-12">
						<div class="form-group">
							<label>Work</label>
							<input type="text" class="form-control" id="work" name="work" placeholder="Work" required>
						</div>
					</div>
					<div class="col-md-12">
						<div class="form-group">
							<label>Sales Owner</label>
							<select id="sales_owner" name="sales_owner" class="js-states form-control users-list" required>
								<option>Sales Owner</option>
							</select>
						</div>
					</div>
					<div class="col-md-12">
						<div class="form-group">
							<label>Subscription Status</label>
							<?php
								$this->db->where('status', 1);
								$subscription = $this->db->get('subscription_types')->result();
							?>
							<select id="subscription_status" name="subscription_status" class="js-states form-control" required>
								<?php
									foreach($subscription as $value){
										echo '<option value="'.$value->subscription_type_id.'">'.$value->type_name.'</option>';
									}
								?>
							</select>
						</div>
					</div>
					<div class="clearfix"></div>
				</div>
				<div class="modal-footer">
					<div class="col-md-12">
						<div class="form-group">
							<input type="hidden" id="lead_id" name="lead_id" value="">
							<input type="hidden" id="stage" name="stage" value="">
							<input type="hidden" id="cloneStatus" name="cloneStatus" value="">
							<!-- <button type="button" class="btn btn-creat pull-left"><i class="fa fa-pencil"></i> Customize fields</button> -->
							<button type="button" class="btn btn-creat " id="btn-close-lead" data-dismiss="modal">Close</button>
							<button type="submit" class="btn btn-save" id="btn-add-lead">Save 			
							</button>
							<button class="buttonload" style="display: none">
								<i class="fa fa-refresh fa-spin"></i> Loading
							</button>
						</div>
					</div>
				</div>			
			</form>
		</div>
	</div>
</div>
<style>
	/* Style buttons */
.buttonload {
	padding: 8px 13px;
    border: #16364d 1px solid;
    display: inline-block;
    font-size: 13px;
    color: #fff;
    background: #16364d;
}

	.company-title span {
		color: #3c8dbc;
		font-size: 15px;
		font-weight: 600;
		margin-bottom: 0px;
	}

	.company-title {
		color: #000;
	}
	label.error{
		/* background: #f00; */
		color: #f00;
		padding: 3px 5px;
		margin-top: 2px;
		border-radius: 5px;
	}
	.form-control.error{
		border: 1px solid #f00;
		/* background: #fff; */
	}

</style>
<script>
	adminPage = 'leadList';
	var table = '';
	$(document).ready(function () {
		var now = new Date();
		var date = now.getFullYear() + "-" + now.getMonth() + "-" + now.getDate();
		table = $('#leads_table').DataTable({

			"processing": true, //Feature control the processing indicator.
			"serverSide": true, //Feature control DataTables' server-side processing mode.
			"order": [], //Initial no order.

			// Load data for the table's content from an Ajax source
			"ajax": {
				"url": "<?php echo site_url('admin/leads/all_content_list')?>",
				"type": "POST",
				"data": function (args) {
					args.start_date = '',
						args.end_date = ''
				}
			},

			//Set column definition initialisation properties.
			"columnDefs": [{
				"targets": 'no-sort',
				"orderable": false, //set not orderable
			}, ],
			rowReorder: {
				selector: 'td:nth-child(2)'
			},
			//responsive: true,
			scrollX: true,
			dom: 'Bfrtip',
			buttons: [{
					extend: 'excel',
					filename: 'leads_list_' + date,
					className: "btn btn-round_small btn-img",
					text: '<i class="fa fa-file-excel-o" aria-hidden="true"></i> Export',
					tag: 'span',
					exportOptions: {
						columns: [0, 1, 2, 3, 4, 5, 6, 7]
					}
				}
				//'excel'
			]
		});
		// $('#btn_filter').click(function () {
		// 	table.draw();
		// });
		// $(document).on("click", '#delete.cstm_view', function () {
		// 	$('#modalContent').html('<p>Would you like to continue ?</p>');
		// 	var id = $(this).prop('title');
		// 	$('#modalContent').attr('title', id);
		// 	$('#myModal').modal('show');
		// });
		$(document).on('click', '#delete.action', function () {
			var id = $(this).data('id');
			Swal.fire({
				html: '<img src="'+logo_url+'public/admin/images/logo.png" alt="no-image">',
				title: "Are you sure want to delete ?",
				type: "warning",
				showCancelButton: true, // true or false  
				confirmButtonColor: "#dd6b55",
				cancelButtonColor: "#48cab2",
				confirmButtonText: "Yes !!!", 
			}).then((result) => {
				if (result.value) {
					$.ajax({
						type: "POST",
						url: base_url+'leads/update-status',
						data: {
							id: id,
							status: 3,
							'column': 'status'
						},
						success: function(response) {
							if(response.status.error_code == 0){
								//populate all required fields
								swalAlert(response.status.message, 'success');
								table.draw();
							}else{
								swalAlert(response.status.message, 'warning');
							}
						},
						error: function(response){
							swalAlert('Something wrong, try again', 'warning');
						} 
					});
				}
			});			
		});
		// $('#start_date').datepicker({
		// 	maxDate: '0',
		// 	format: 'yyyy-mm-dd',
		// 	setDate: new Date()
		// });

		// $('#end_date').datepicker({
		// 	maxDate: '0',
		// 	format: 'yyyy-mm-dd',
		// 	setDate: new Date()
		// });

		$('.js-example-basic-single').select2({});

		
	});

	//Add email section
	$(document).on('click', '.add_email_section', function(){
			let rand = Math.floor((Math.random() * 100) + 1);
			$('.register_email').append('<div class="mail-section-2 email-section-'+rand+'"><div class="col-md-1"></div><div class="col-md-6"> <input type="email" class="form-control" name="email[]" id="email" placeholder="Enter Value" required></div><div class="col-md-4"> <select id="pick_label" name="pick_label[]" class="js-states form-control" required><option value="work">Work</option><option value="personal">Personal</option> </select></div><div class="col-md-1"><i class="fa fa-minus-circle" aria-hidden="true" onclick="removeSection('+rand+')"></i></div><div class="clearfix"></div></div>');
		})

	function removeSection(x){
		$('.email-section-'+x).remove();
	}

	$(document).on("change", ".assign_to", function () {
		var user_id = $('option:selected', this).val();
		var project_id = $('option:selected', this).data('project_id');

		//alert(project_id);
		if (user_id == "") {
			alert("Please select a person to assign");
		} else {
			$.ajax({
				type: "POST",
				url: '<?php echo base_url('admin/leads/assign_project')?>',
				data: 'user_id=' + user_id + "&project_id=" + project_id,
				dataType: 'json',
				success: function (response) {
					//console.log(response);return false;
					window.location.reload('<?php echo base_url('admin/leads'); ?>');
				},
				error: function (response) {
					alert("Please try again");
				}
			});
		};
	})

	//perform reset modal
	$('#add-lead-modal').on('click', function(){

	})
	// Submit lead add form
	// validate signup form on keyup and submit
	var validator = $("#frm-lead").validate({
			rules: {
				first_name: "required",
				last_name: "required",
				company_name: "required",
				email: {
					required: true,
					email: true
				},				
				pick_label: "required",
				mobile: "required",
				work: "required",
				sales_owner: "required",
				subscription_status: "required",
			},
			messages: {
				firstname: "Please enter your firstname",
				lastname: "Please enter your lastname",
				company_name: "Please enter company name",
				email: "Please enter a valid email address",
				pick_label: "Please enter label",
				mobile: "Please enter mobile number",
				work: "Please enter work for",
				sales_owner: "Please select sales owner",
				subscription_status: "Please select subscription status",
			},
			submitHandler: function(form) {
				$.ajax({
					url: base_url+'leads/store',
					type: 'POST',
					data: $(form).serialize(),
					beforeSend: function() {
						$("#btn-add-lead").hide();
						$(".buttonload").show();	
					},
					success: function(response) {
						console.log(response)
						$(".buttonload").hide();						
						$("#btn-add-lead").show();
						console.log(response.status.error_code);
						if(response.status.error_code == 0){
							resetApplicationForm();							
							$("#btn-close-lead").click();
							swalAlert(response.status.message, 'success');
							//draw table with updated rows
							table.draw();
						}else{
							swalAlert(response.status.message, 'warning');
						}
					},
					error: function(response){
						$(".buttonload").hide();						
						$("#btn-add-lead").show();
						swalAlert('Something wrong, try again', 'warning');
					}           
				});
			}
	});
	function resetApplicationForm(){
		validator.resetForm();
	}

	$('#btn-close-lead').click(function(){
		$('.modal-title').text('Add Lead');
	})

	$(document).on('click', '#edit.action', function(){
		let id = $(this).data('id');
		$.ajax({
				url: base_url+'leads/get-lead',
				type: 'GET',
				data: {
					id: id
				},
				beforeSend: function() {
					
				},
				success: function(response) {
					if(response.status.error_code == 0){
						//populate all required fields
						populateLeadInfo(response.result.data, cloneStatus = false);
						$('.modal-title').text('Edit Lead');
						$('#ceartModal').modal('show');
					}else{
						swalAlert(response.status.message, 'warning');
					}
				},
				error: function(response){
					swalAlert('Something wrong, try again', 'warning');
				}           
			});
	})

	$(document).on('click', '#clone.action', function(){
		let id = $(this).data('id');
		$.ajax({
				url: base_url+'leads/get-lead',
				type: 'GET',
				data: {
					id: id
				},
				beforeSend: function() {
					
				},
				success: function(response) {
					if(response.status.error_code == 0){
						//populate all required fields
						populateLeadInfo(response.result.data, cloneStatus = true);

						$('#cloneStatus').val('1');
						$('.modal-title').text('Clone Lead');
						$('#ceartModal').modal('show');
					}else{
						swalAlert(response.status.message, 'warning');
					}
				},
				error: function(response){
					swalAlert('Something wrong, try again', 'warning');
				}           
			});
	})

	function populateLeadInfo(d = null, cloneStatus){
		let data = d['data'][0];
		let emails = d['email'];
		console.log(cloneStatus)
		if(cloneStatus != true){
			$('#lead_id').val(data.lead_id);
		}else{
			$('#lead_id').val('');
		}
		$('#stage').val(data.stage);
		$('#first_name').val(data.name);
		$('#last_name').val(data.lname);
		$('#mobile').val(data.mobile);
		$('#work').val(data.work);
		
		//populate emails
		$.each(emails, function(key, val){
			if(val.is_default == 1){
				$('#email.default').val(val.email);
				$('#pick_label.default option[value="'+val.label_for+'"]').attr("selected", "selected");
			}else{
				console.log('else');
				let rand = Math.floor((Math.random() * 100) + 1);
				$('.register_email').append('<div class="mail-section-2 email-section-'+rand+'"><div class="col-md-1"></div><div class="col-md-6"> <input type="email" class="form-control" name="email[]" id="email" placeholder="Enter Value" required value="'+val.email+'"></div><div class="col-md-4"> <select id="pick_label" name="pick_label[]" class="js-states form-control" required><option value="work" '+val.label_for+'>Work1</option><option value="personal" '+val.label_for+'>Personal1</option> </select></div><div class="col-md-1"><i class="fa fa-minus-circle" aria-hidden="true" onclick="removeSection('+rand+')"></i></div><div class="clearfix"></div></div>');
			}
		})
		
		//select company
		$('#company_name option[value="'+data.company_id+'"]').attr("selected", "selected");
		$('#sales_owner option[value="'+data.sale_owner+'"]').attr("selected", "selected");
		$('#subscription_status option[value="'+data.subscription_status+'"]').attr("selected", "selected");				
	}
</script>
