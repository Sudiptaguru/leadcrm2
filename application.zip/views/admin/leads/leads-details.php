<!-- load header -->
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper detail_page">
	<!-- Content Header (Page header) -->
	<div class="row">
		<div class="col-md-8 pad2R">
			<section class="content-header">
				<ol class="bread_crumb">
					<li><a href="#"><img src="<?=base_url('public/admin/')?>images/home_ico.png" alt=""></a></li>
          <li><a href="<?=base_url('admin/leads')?>">Leads</a></li>
          
					<li class="active"><?=$projectEmail->email?$projectEmail->email:''?></li>
				</ol>
				<ol class="breadcrumb setting_btn">
					<ul class="add_list">
						<li class=""><a href="#" class="btn btn-creat" data-toggle="modal" data-target="#stage1"><i class="fa fa-envelope-o"></i> Email</a></li>
						<li class=""><a href="javascript:void(0)" class="btn btn-creat action" id="edit" data-id="<?=$project[0]['lead_id']?>"><i class="fa fa-pencil"></i> Edit</a> </li>
						<!-- <li class="dropdown"><a href="javascript:void(0)" class="dropdown-toggle" type="button" data-toggle="dropdown"
								aria-haspopup="true" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
							<div class="dropdown-menu"> <a class="dropdown-item" href="#">Follow up</a> <a class="dropdown-item"
									href="#">Call reminder</a> <a class="dropdown-item" href="#">Appointment</a> </div>
						</li>
						<li class="dropdown"><a href="javascript:void(0)"><img src="<?=base_url('public/admin/')?>images/Settings_ico1.png" alt=""></a> </li> -->
					</ul>
				</ol>
			</section>
			<!-- Main content -->
			<section class="content leads_page">
				<!-- Small boxes (Stat box) -->
				<div class="row">
					<div class="col-md-12">
						<div class="user_detail_sec">
							<div class="user_head">
								<div class="profile_img_sec">
									<div class="profile_img"> 
                    <!-- <img src="<?=base_url('public/admin/')?>images/user2-160x160.jpg" alt=""> -->
                    <span style="font-size: 50px; margin-left: 20px; font-weight: 700; color: #3c9ad2;">
                      <?=$projectEmail->email?strtoupper(substr($projectEmail->email, 0, 1)):''?>
                    </span>
                  </div>
									<div class="badge">0</div>
                </div>
								<div class="profile_txt">
									<h3><?=$projectEmail->email?$projectEmail->email:''?> <span><img src="<?=base_url('public/admin/')?>images/fb_ico.png" alt=""></span><span><img src="<?=base_url('public/admin/')?>images/tw_ico.png"
												alt=""></span><span><img src="<?=base_url('public/admin/')?>images/in_ico.png" alt=""></span> <a href="javascript:void(0)"><i
												class="fa fa-pencil"></i></a></h3>
									<h4><?=$project[0]['company_name']?> <a href="javascript:void(0)"><i class="fa fa-pencil"></i></a></h4>
									<!-- <p><i class="fa fa-map-marker"></i> Click to add location <a href="javascript:void(0)"><i class="fa fa-pencil"></i></a>
									</p> -->
									<div class="tag_area"> <img src="<?=base_url('public/admin/')?>images/tag.png" alt=""> <a href="javascript:void(0)" class="btn btn-save"><?=$project[0]['stage']?>
										</a> 
										<!-- <span>Click to add tags</span> <a href="javascript:void(0)"><i class="fa fa-pencil"></i></a>  -->
									</div>
								</div>
							</div>
							<div class="user_ul_sec">
								<ul class="user_fields_list">
									<li>
										<label class="switch">
											<input type="checkbox" id="show-empty" checked>
											<span class="slider round"></span> </label>
									</li>
									<li>Hide empty fields</li>
									<li><a href="javascript:void(0)"><i class="fa fa-search" aria-hidden="true"></i></a></li>
								</ul>
							</div>
							<div class="slider_area">
								<div id="slider-carousel" class="owl-carousel">
									<div class="item">
										<div class="col-md-12">
											<div class="row">
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Emails</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" value="<?=$projectEmail->email?$projectEmail->email:''?>">
                                <!-- <span class="edit"><i class="fa fa-pencil"></i></span> -->
                               </div>
														</div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Mobile</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" value="<?=$project[0]['mobile']?$project[0]['mobile']:''?>">
                                <span class="edit"><i class="fa fa-pencil"></i></span>
                              </div>
														</div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Work</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" value="<?=$project[0]['work']?$project[0]['work']:''?>">
                                <span class="edit"><i class="fa fa-pencil"></i></span> 
                              </div>
														</div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Sales owner</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" value="<?=$project[0]['sales_user_name']?$project[0]['sales_user_name']:''?>">
                                <!-- <span class="edit"><i class="fa fa-pencil"></i></span> -->
                               </div>
														</div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Unqualified reason</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" placeholder="Not available" value="">
                                <span class="edit"><i class="fa fa-pencil"></i></span> 
                              </div>
														</div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Subscription status</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" placeholder="Not available" value="<?=$project[0]['type_name']?$project[0]['type_name']:''?>">
                                <!-- <span class="edit"><i class="fa fa-pencil"></i></span>  -->
                              </div>
														</div>
													</div>
												</div>
												<?php
													print_r($projectDetails);
												?>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Territory</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" id="country" placeholder="Not available" value="<?=isset($projectDetails->country)?$projectDetails->country:""?>">
																<span class="edit"><i class="fa fa-pencil"></i> <i style="display: none" class="fa fa-check" data-id="country" data-column="country"></i></span> </div>
														</div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Time zone</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" placeholder="Not available" value="">
																<span class="edit"><i class="fa fa-pencil"></i></span> </div>
														</div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Other phone numbers</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" id="other_phone" placeholder="Not available" value="<?=isset($projectDetails->other_phone)?$projectDetails->other_phone:""?>">
                                <span class="edit"><i class="fa fa-pencil"></i> <i style="display: none" class="fa fa-check" data-id="other_phone" data-column="other_phone"></i></span>
                              </div>
														</div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Address</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" id="address" placeholder="Not available" value="<?=isset($projectDetails->address)?$projectDetails->address:""?>">
                                <span class="edit"><i class="fa fa-pencil"></i> <i style="display: none" class="fa fa-check" data-id="address" data-column="address"></i></span>
                              </div>
														</div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Zipcode</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" id="zip" placeholder="Not available" value="<?=isset($projectDetails->zip)?$projectDetails->zip:""?>">
                                <span class="edit"><i class="fa fa-pencil"></i> <i style="display: none" class="fa fa-check" data-id="zip" data-column="zip"></i></span> </div>
                                </div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Company address</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" id="company_address" placeholder="Not available" value="<?=isset($projectDetails->company_address)?$projectDetails->company_address:""?>">
                                <span class="edit"><i class="fa fa-pencil"></i> <i style="display: none" class="fa fa-check" data-id="company_address" data-column="company_address"></i></span>
                               </div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
									<div class="item">
										<div class="col-md-12">
											<div class="row">
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Company city</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" placeholder="Not available" value="">
																<span class="edit"><i class="fa fa-pencil"></i></span> </div>
														</div>
													</div>
												</div>

												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Company state</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" placeholder="Not available" value="">
																<span class="edit"><i class="fa fa-pencil"></i></span> </div>
														</div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Company zipcode</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" placeholder="Not available" value="">
																<span class="edit"><i class="fa fa-pencil"></i></span> </div>
														</div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Company country</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" placeholder="Not available" value="">
																<span class="edit"><i class="fa fa-pencil"></i></span> </div>
														</div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Number of employees</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" placeholder="Not available" value="">
																<span class="edit"><i class="fa fa-pencil"></i></span> </div>
														</div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Company annual revenue</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" value="$0">
																<span class="edit"><i class="fa fa-pencil"></i></span> </div>
														</div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Company website</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" placeholder="Not available" value="">
																<span class="edit"><i class="fa fa-pencil"></i></span> </div>
														</div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Company phone</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" placeholder="Not available" value="">
																<span class="edit"><i class="fa fa-pencil"></i></span> </div>
														</div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Industry type</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" placeholder="Not available" value="">
																<span class="edit"><i class="fa fa-pencil"></i></span> </div>
														</div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Business type</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" placeholder="Not available" value="">
																<span class="edit"><i class="fa fa-pencil"></i></span> </div>
														</div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Deal name</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" placeholder="Not available" value="">
																<span class="edit"><i class="fa fa-pencil"></i></span> </div>
														</div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Deal Currency</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" value="USD">
																<span class="edit"><i class="fa fa-pencil"></i></span> </div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
									<div class="item">
										<div class="col-md-12">
											<div class="row">
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Deal value</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" value="$0.00">
																<span class="edit"><i class="fa fa-pencil"></i></span> </div>
														</div>
													</div>
												</div>

												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Deal value in Base Currency</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" value="$0.00">
																<span class="edit"><i class="fa fa-pencil"></i></span> </div>
														</div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Deal expected close date
																</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" placeholder="Not available" value="">
																<span class="edit"><i class="fa fa-pencil"></i></span> </div>
														</div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Source</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" placeholder="Not available" value="">
																<span class="edit"><i class="fa fa-pencil"></i></span> </div>
														</div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Campaign
																</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" placeholder="Not available" value="">
																<span class="edit"><i class="fa fa-pencil"></i></span> </div>
														</div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Medium</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" value="$0">
																<span class="edit"><i class="fa fa-pencil"></i></span> </div>
														</div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Keyword</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" placeholder="Not available" value="">
																<span class="edit"><i class="fa fa-pencil"></i></span> </div>
														</div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Last contacted time</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" placeholder="Not available" value="">
																<span class="edit"><i class="fa fa-pencil"></i></span> </div>
														</div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Last contacted mode</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" placeholder="Not available" value="">
																<span class="edit"><i class="fa fa-pencil"></i></span> </div>
														</div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Last activity type
																</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" placeholder="Not available" value="">
																<span class="edit"><i class="fa fa-pencil"></i></span> </div>
														</div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Last activity date
																</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" placeholder="Not available" value="">
																<span class="edit"><i class="fa fa-pencil"></i></span> </div>
														</div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Active sales sequences
																</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" value="USD">
																<span class="edit"><i class="fa fa-pencil"></i></span> </div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
									<div class="item">
										<div class="col-md-12">
											<div class="row">
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Completed sales sequences
																</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" placeholder="Not available" value="" readonly>
															</div>
														</div>
													</div>
												</div>

												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Last seen
																</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" placeholder="Not available" value="" readonly>
															</div>
														</div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Recent note

																</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" placeholder="Not available" value="" readonly>
															</div>
														</div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Created by
																</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" value="User Name" readonly>
															</div>
														</div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Created at
																</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" value="19 hours ago" readonly></div>
														</div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Updated by
																</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" value="User Name" readonly>
															</div>
														</div>
													</div>
												</div>

												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Updated at</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" value="19 hours ago" readonly>
															</div>
														</div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Web forms
																</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" placeholder="Not available" value="" readonly>
															</div>
														</div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Last assigned at
																</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" value="19 hours ago" readonly>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>

							<div class="Lead_stage_area">
								<p><i class="fa fa-calendar"></i> Lead stage changed: <?=timeDuration($project[0]['lead_update_on'], date('Y-m-d H:i'))?> (<?=$project[0]['stage']?>)</p>
								<?php
								$stages = $this->common_model->select('lead_stages', ['id <='=> 5, 'status'=> 1], 'stage', 'id', 'asc');

								?>
								<!-- <ul class="Lead_stage_list">
									<?php
										$stageMatched = false;
										foreach($stages as $value){                      
										$class = '';
										if(!$stageMatched){
											$class= 'active';
											if(strtolower($value->stage) == $project[0]['stage']){                          
											$stageMatched = true;
											}
										}
										?>
											<li class="<?=$class?>"><a href="#" class="lead-stage" data-val="<?=strtolower($value->stage)?>"><?=$value->stage?></a></li>
										<?php
										}
									?>
									<li>
										<a id="showmenu" href="#" class="lead-stage" data-val="unqualified"> Unqualified </a>
										<div class="menu" style="display: none;">
											<ul>
												<li><a href="javascript:void(0)">Interested</a></li>
												<li><a href="javascript:void(0)">Unqualified</a></li>
											</ul>
										</div>
									</li>
								</ul> -->
											<!-- I new  -->
								
								<ul class="Lead_stage_list">
								<?php
								$lifecycle = $this->common_model->select('lead_lifecycle', ['status'=> 1], '*', 'lead_lifecycle_id', 'asc');
								foreach ($lifecycle as $key => $cycle) {
									$stages = $this->common_model->select('lead_company_lifecycle_stages', ['user_id'=> $admin['id'], 'lead_lifecycle_id'=> $cycle->lead_lifecycle_id], '*', 'rank', 'ASC');
									if(empty($stages)){
										$stages = $this->common_model->select('lead_lifecycle_stages', ['status'=>1, 'lead_lifecycle_id'=> $cycle->lead_lifecycle_id], '*', 'rank', 'ASC');
									}
									?>
									<li class="">
										<a data-id="lead-<?=$key?>" href="javascript:void(0)" class="lead-stage-bkp lead-cycle" data-val="<?=strtolower($cycle->lifecycle)?>"><?=$cycle->lifecycle?></a>
									<?php				
										if($stages){
											echo '<div id="lead-'.$key.'" class="lead-menu menu" style="display: none;">
													<ul>';
											for($i=0; $i<count($stages); $i++){
												$class = '';
												if(!$stageMatched){
													$class= 'active';
													if(strtolower($stages[$i]->stage) == $project[0]['stage']){                          
													$stageMatched = true;
													}
												}
									?>
										<li><a href="javascript:void(0)" class="update-lifecycle" data-val="<?=$stages[$i]->stage?>" data-parent="<?=$cycle->lead_lifecycle_id?>"><?=$stages[$i]->stage?></a></li>
										<?php
											}
											echo '</ul>
										</div>';
										}
											?>
										</li>
									<?php
									}
								?>
								</ul>
							</div>
							<script>
								$(document).ready(function() {
									$('.lead-cycle').click(function() {
										let child = $(this).data('id');
										$('.lead-menu').hide();
										$('#'+child).slideToggle("fast");
									});
								});
							</script>
							<!-- <div class="conversations_area">
								<h4>RECENT CONVERSATIONS</h4>

								<div class="No_conversations">
									<p>No conversations found.</p>
									<p><a href="javascript:void(0)">Send an email</a> or <a href="javascript:void(0)">Add call log</a></p>
								</div>
							</div> -->
							<div class="activities_area">
								<h4>RECENT ACTIVITIES</h4>

								<div class="row">
									<div class="col-md-8">
										<div class="activiti_list_main activiti_list_main_srolling">
										<ul class="activiti_list">
											<!-- <li>
												<a href="javascript:void(0)" class="btn btn-view activiti_li">Today</a>
											</li> -->
											<?php
											$leadLogs = $this->common_model->select('lead_logs', ['user_id'=> $this->admin['id'], 'lead_id'=>$project[0]['lead_id']], '*', 'id', 'ASC');
											if(!empty($leadLogs)){
												foreach ($leadLogs as $key => $value) {
											?>
											<li><span class="star_sec"><i class="fa fa-star-o"></i></span>
												<span class="text_sec">
													<p><?=$value->message?></p>
													<p><small><i class="fa fa-shopping-bag"></i> <?=$admin['name']?> <i class="fa fa-circle"></i> <?=timeDuration($value->created_at, date('Y-m-d H:i'))?></small>
													</p>

												</span>
											</li>
											<?php
												}
											}
											?>

											<!-- <li><a href="javascript:void(0)" class="btn btn-view activiti_li">View all</a></li> -->
										</ul>
										</div>
									</div>
									<div class="col-md-4">
										<div class="score_area">
											<p>SCORE</p>
											<div class="score_txt">0</div>
											<p><small>Last seen:</small></p>
											<p><small>---</small></p>
											<p><small>Last contacted:</small></p>
											<p><small>---</small></p>
											<p><small>Last modified:</small></p>
											<p><small>19 hours ago</small></p>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
			<!-- /.content -->
		</div>
		<div class="col-md-4 right_panel_sec">
			<div class="row">
				<div class="convert_sec">
					<div class="wrapper_box wrapper_box_notes">
						<div class="wrapper_head border_bottom">
							<h3>NOTES</h3>
							<ul class="add_list no-border">
								<li class="dropdown">
									<a href="javascript:void(0)" title="Notes">
										<img src="<?=base_url('public/admin/')?>images/convert_list_img7.png" alt="">
									</a>
								</li>
							</ul>
						</div>
						<br>
						<div class="summary_table">
							<textarea name="" id="lead-notes-text" cols="" rows="5" placeholder="Start typing..." class="form-control"></textarea>
							<div class="trying_to_conact">
								<input type="button" value="Save" id="btn-add-note"/>
							</div>
							<div class="trying_to_conact" id="sec-lead-notes">
								<?php
                                    $leadNotes = $this->common_model->select('lead_notes', ['user_id'=> $this->admin['id'], 'lead_id'=>$project[0]['lead_id'], 'status'=> 1], '*', 'lead_note_id', 'ASC');
									if(!empty($leadNotes)){
										foreach ($leadNotes as $key => $value) {
											?>
											<div class="parent-<?=$value->lead_note_id?>">
											<div class="trying_to_conact_l">
												<svg width="12px" height="12px" viewBox="0 0 18 18" xmlns="http://www.w3.org/2000/svg"><g stroke="#000" fill="none" fill-rule="evenodd"><path d="M10.921.52H4.113c-.94 0-1.702.761-1.702 1.701v13.616c0 .94.762 1.702 1.702 1.702h10.212c.94 0 1.702-.762 1.702-1.702V5.625L10.921.52z"></path><path d="M10.921.52v4.105a1 1 0 0 0 1 1h4.106"></path><path d="M12.623 9.88H5.815M12.623 13.284H5.815M7.517 6.476H5.815" stroke-linecap="round" stroke-linejoin="round"></path></g></svg>									
											</div>
											<div class="trying_to_conact_r">
												<span>
													<span id="lead-note-txt-<?=$value->lead_note_id?>">
														<?=$value->note?>
													</span>
													<b style="float:right; display:inline-block;">
													<a href="#"><i style="margin-left:10px; display:inlne-block;" class="fa fa-pencil edit-lead-note" aria-hidden="true" data-id="<?=$value->lead_note_id?>"></i></a>
													<a href="#"><i class="fa fa-trash-o delete-sec" data-id="<?=$value->lead_note_id?>" data-key="lead_note_id" data-table="lead_notes" aria-hidden="true"></i></a>
													<div class="clearfix"></div>
													</b>
												</span>
												<b><svg width="14" height="14" viewBox="0 0 14 14" xmlns="http://www.w3.org/2000/svg" class="svg-sm"><g fill-rule="nonzero" fill="none"><path fill-opacity=".01" fill="#FFF" d="M0 0h14v14H0z"></path><g transform="translate(1 1)" stroke="#2C5CC5"><rect x=".068" y="9.5" width="12" height="3" rx="1"></rect><path d="M1.044 9.451h10.054a.1.1 0 0 0 .098-.08l.874-4.433a.1.1 0 0 0-.128-.114l-3.48 1.09a.1.1 0 0 1-.114-.04L6.154 2.56a.1.1 0 0 0-.166 0L3.789 5.874a.1.1 0 0 1-.113.04L.194 4.825a.1.1 0 0 0-.128.115l.88 4.431a.1.1 0 0 0 .098.081z"></path><circle stroke-width="1.2" cx="6.068" cy=".5" r="1"></circle></g></g></svg> &nbsp; <?=$admin['name']?></b>
												<i></i>												
												<div class="clearfix"></div>
											</div>
											</div>											
											<div class="clearfix"></div>
											<?php
										}
									}
								?>
							</div>
						</div>
						<div class="clearfix"></div>
					</div>
					<script>
						
						var lead_note_id = '';
						$(document).on('click', '.edit-lead-note', function(){
							let id = $(this).data('id');
							lead_note_id = id;
							$('#lead-notes-text').val($('#lead-note-txt-'+id).html().trim());
						})

						$(document).on('click', '.delete-sec', function(){
							let id = $(this).data('id');
							let t = $(this);
							Swal.fire({
									html: '<img src="'+logo_url+'public/admin/images/logo.png" alt="no-image">',
									title: "Are you sure to delete this ?",
									type: "warning",
									showCancelButton: true, // true or false  
									confirmButtonColor: "#dd6b55",
									cancelButtonColor: "#48cab2",
									confirmButtonText: "Yes !!!", 
								}).then((result) => {
									if (result.value) {
										$.ajax({
											type: "POST",
											url: base_url+'leads/deleteSection',
											data: {
													lead_id: "<?=$project[0]['lead_id']?>",
													id: id,
													key: $(this).data('key'),
													table: $(this).data('table'),
											},
											success: function(response) {
												if(response.status.error_code == 0){
													//populate all required fields
													swalAlert(response.status.message, 'success');
													t.parents('.parent-'+id).remove();
												}else{
													swalAlert(response.status.message, 'warning');
												}
											},
											error: function(response){
												swalAlert('Something wrong, try again', 'warning');
											} 
										});
									}
								});
						})
					</script>
					<!-- Task view -->
					<div class="wrapper_box wrapper_box_task" style="display:none">
						<div class="wrapper_head border_bottom">
							<h3>TASKS</h3>
							<ul class="add_list no-border">
								<li class="dropdown"><a href="#" data-toggle="modal" data-target="#stage01"><img src="<?=base_url('public/admin/')?>images/convert_list_img7.png" alt=""></a>
								</li>
							</ul>
						</div>
						<br>
						<div class="summary_table" id="sec-lead-task">
						<?php
							$leadTask = $this->common_model->select('lead_tasks', ['user_id'=> $this->admin['id'], 'lead_id'=>$project[0]['lead_id'], 'status'=> 1], '*', 'lead_task_id ', 'DESC');
							if(!empty($leadTask)){
								foreach ($leadTask as $key => $value) {
									?>
							<div class="taskbox parent-<?=$value->lead_task_id?>">
								<div class="tak_top">
									<h3><?=$value->title?> 
									<span>
									<a href="#">
										<i class="fa fa-pencil edit-lead-task" aria-hidden="true" data-id="<?=$value->lead_task_id?>" data-title="<?=$value->title?>" data-desc="<?=$value->description?>" data-type="<?=$value->type?>" data-date="<?=$value->date?>" data-outcome="<?=$value->outcome?>"></i>
									</a> 
									<!-- <a href="#"><i class="fa fa-trash-o" aria-hidden="true"></i></a> -->
									<a href="#"><i class="fa fa-trash-o delete-sec" data-id="<?=$value->lead_task_id?>" data-key="lead_task_id" data-table="lead_tasks" aria-hidden="true"></i></a>
								</span>
									</h3>																
								</div>
								<div class="tak_mid">
									<b><svg width="14" height="14" viewBox="0 0 14 14" xmlns="http://www.w3.org/2000/svg" class="svg-sm"><g fill-rule="nonzero" fill="none"><path fill-opacity=".01" fill="#FFF" d="M0 0h14v14H0z"></path><g transform="translate(1 1)" stroke="#2C5CC5"><rect x=".068" y="9.5" width="12" height="3" rx="1"></rect><path d="M1.044 9.451h10.054a.1.1 0 0 0 .098-.08l.874-4.433a.1.1 0 0 0-.128-.114l-3.48 1.09a.1.1 0 0 1-.114-.04L6.154 2.56a.1.1 0 0 0-.166 0L3.789 5.874a.1.1 0 0 1-.113.04L.194 4.825a.1.1 0 0 0-.128.115l.88 4.431a.1.1 0 0 0 .098.081z"></path><circle stroke-width="1.2" cx="6.068" cy=".5" r="1"></circle></g></g></svg> &nbsp; <?=$admin['name']?></b>
									<i>Due date: -</i>
								</div>
								<div class="clearfix"></div>
							</div>
							  <?php
								}
							}
							  ?>
						</div>
						<div class="clearfix"></div>
					</div>
					<script>
						var lead_task_id = '';
						$(document).on('click', '.edit-lead-task', function(){
							let id = $(this).data('id');
							lead_task_id = id;
							$('#task-title').val($(this).data('title'));
							$('#task-description').val($(this).data('desc'));
							$('#task-type').val($(this).data('type'));
							$('#task-date').val($(this).data('date'));
							$('#outcome').val($(this).data('outcome'));

							$('#stage01').modal('show');
						})
					</script>
					<div class="wrapper_box wrapper_box_files" style="display:none">
						<div class="wrapper_head border_bottom">
							<h3>FILES</h3>
							<ul class="add_list no-border">
								<li class="dropdown"><a href="#" data-toggle="modal" data-target="#stage02"><img src="<?=base_url('public/admin/')?>images/convert_list_img7.png" alt=""></a>
								</li>
							</ul>
						</div>
						<br>
						<div class="summary_table" id="sec-lead-file">
						<?php
							$leadFiles = $this->common_model->select('lead_files', ['user_id'=> $this->admin['id'], 'lead_id'=>$project[0]['lead_id']], '*', 'lead_file_id ', 'DESC');
							if(!empty($leadFiles)){
								foreach ($leadFiles as $key => $value) {
									?>
							<div class="taskbox parent-<?=$value->lead_file_id?>">
								<div class="tak_top_l">
									<i class="fa fa-file-text-o" aria-hidden="true"></i>
								</div>
								<div class="tak_top_r">
									<div class="tak_top">
										<h3 style="color: #2196F3">
											<a href="<?=base_url('public/lead_files/'.$value->file)?>" target="_blank">
											<?=$value->file_name?>
											</a>
											<span>
												<a href=""><i class="fa fa-pencil" aria-hidden="true"></i></a> 
												<!-- <a href=""><i class="fa fa-trash-o" aria-hidden="true"></i></a> -->
												<a href="#"><i class="fa fa-trash-o delete-sec" data-id="<?=$value->lead_file_id?>" data-key="lead_file_id" data-table="lead_files" aria-hidden="true"></i></a>
											</span>
										</h3>
									</div>
									<div class="tak_mid">
										<b><svg width="14" height="14" viewBox="0 0 14 14" xmlns="http://www.w3.org/2000/svg" class="svg-sm"><g fill-rule="nonzero" fill="none"><path fill-opacity=".01" fill="#FFF" d="M0 0h14v14H0z"></path><g transform="translate(1 1)" stroke="#2C5CC5"><rect x=".068" y="9.5" width="12" height="3" rx="1"></rect><path d="M1.044 9.451h10.054a.1.1 0 0 0 .098-.08l.874-4.433a.1.1 0 0 0-.128-.114l-3.48 1.09a.1.1 0 0 1-.114-.04L6.154 2.56a.1.1 0 0 0-.166 0L3.789 5.874a.1.1 0 0 1-.113.04L.194 4.825a.1.1 0 0 0-.128.115l.88 4.431a.1.1 0 0 0 .098.081z"></path><circle stroke-width="1.2" cx="6.068" cy=".5" r="1"></circle></g></g></svg> &nbsp; <?=$admin['name']?></b>
										<i>Due date: -</i>
									</div>
								</div>
								<div class="clearfix"></div>
							  </div>
							  <?php
								}
							}
							  ?>
						</div>
						<div class="clearfix"></div>
					</div>
				</div>

				<!-- Appointments -->
				
				<!--  -->
				<div class="convert_list_sec">
					<ul class="convert_list">
						<li><a href="javascript:void(0)" title="Notes" class="right-side-menu convert_list_active" data-parent="notes"><img src="<?=base_url('public/admin/')?>images/convert_list_img.png" alt=""></a></li>
						<li><a href="javascript:void(0)" title="Task" class="right-side-menu" data-parent="task"><img src="<?=base_url('public/admin/')?>images/convert_list_img1.png" alt=""></a></li>
						<!-- <li><a href="javascript:void(0)" title="Files"><img src="<?=base_url('public/admin/')?>images/convert_list_img2.png" alt=""></a></li> -->
						<li><a href="javascript:void(0)" title="Files"  class="right-side-menu" data-parent="files"><img src="<?=base_url('public/admin/')?>images/convert_list_img3.png" alt=""></a></li>
						<!-- <li><a href="javascript:void(0)" ><img src="<?=base_url('public/admin/')?>images/convert_list_img4.png" alt=""></a></li>
						<li><a href="javascript:void(0)"><img src="<?=base_url('public/admin/')?>images/convert_list_img5.png" alt=""></a></li>
						<li><a href="javascript:void(0)"><img src="<?=base_url('public/admin/')?>images/convert_list_img6.png" alt=""></a></li> -->
						<li><a href="#" data-toggle="modal" data-target="#dealModal" title="Deals"><img src="<?=base_url('public/admin/')?>images/convert_list_img6.png" alt=""></a></li>
						<li><a href="javascript:void(0)" title="Remonders"><img src="<?=base_url('public/admin/')?>images/convert_list_img7.png" alt=""></a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- Right side menu toggle -->
<script>
	$(document).ready(function(){
		$('.right-side-menu').on('click', function(){
			let p = $(this).data('parent');
			
			$('.right-side-menu').removeClass('convert_list_active');
			$(this).addClass('convert_list_active');
			$('.wrapper_box').hide();
			$('.wrapper_box_'+p).show();
		})
	})
</script>
<!-- /.content-wrapper -->
<!-- <footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 2.4.0
    </div>
    Copyright &copy; 2014-2016  All rights
    reserved.
  </footer>-->

<!-- Control Sidebar -->

<!-- /.control-sidebar -->
<!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
<div class="control-sidebar-bg"></div>

<!-- Modal -->
<div class="modal fade" id="ImportsModal" tabindex="-1" role="dialog" aria-labelledby="">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
						aria-hidden="true">&times;</span></button>
				<h4 class="modal-title" id="">IMPORT CONTACTS <span class="step_btn btn">Step 1 of 2</span></h4>
			</div>
			<div class="modal-body">
				<form action="" class="row">
					<div class="col-md-12">
						<p>Import your contacts using your own file, or use our <a href="javascript:void(0)">sample CSV</a>. <i
								class="fa fa-question-circle-o"></i> </p>
					</div>
					<div class="col-md-12">
						<div class="form-group">
							<div class="drag_sec">
								<div class="choose-file">
									<input type="file">
									<label><span class="img_sec"><img src="<?=base_url('public/admin/')?>images/csv_img.png" alt=""></span> Drop or upload your file
										here</label>
									<p>(.csv, .xlsx formats supported)</p>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-12">
						<div class="form-group">
							<label>Select an import option for this file</label>
							<select name="" id="" class="form-control">
								<option value="">Create new contacts</option>
								<option value="">Create new and update existing contacts (without overwrite)</option>
								<option value="">Create new and update existing contacts (with overwrite)</option>
							</select>
						</div>
					</div>
					<div class="col-md-12">
						<div class="form-group">
							<input type="checkbox" id="Skip">
							<label for="Skip">Skip duplicates automatically by matching <span>Primary email <i
										class="fa fa-caret-down"></i></span></label>
						</div>
					</div>
					<div class="col-md-12">
						<div class="form-group"> <a href="javascript:void(0)" class="show_more1">Manage email subscriptions <i
									class="fa fa-caret-down"></i></a> <span class="more_checkbox1">
								<div class="form-group">
									<input type="checkbox" id="Subscribe">
									<label for="Subscribe">Subscribe contacts to all types of emails</label>
								</div>
							</span> </div>
					</div>
					<div class="col-md-12">
						<div class="form-group"> <a href="javascript:void(0)" class="show_more2">Manage sales owner <i
									class="fa fa-caret-down"></i></a> <span class="more_checkbox2">
								<div class="form-group">
									<select id="single3" class="js-states form-control">
										<option>Sales Owner</option>
										<option>Sales Owner1</option>
										<option>Sales Owner2</option>
										<option>Sales Owner3</option>
									</select>
								</div>
							</span> </div>
					</div>
				</form>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-creat " data-dismiss="modal">Close</button>
				<button type="button" class="btn btn-save" data-dismiss="modal" data-toggle="modal"
					data-target="#ImportsModal1">Next</button>
			</div>
		</div>
	</div>
</div>

<!-- Modal -->
<div class="modal fade" id="ImportsModal1" tabindex="-1" role="dialog" aria-labelledby="">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
						aria-hidden="true">&times;</span></button>
				<h4 class="modal-title" id="">IMPORT CONTACTS <span class="step_btn btn">Step 2 of 2</span></h4>
			</div>
			<div class="modal-body">
				<form action="" class="row">
					<div class="col-md-12">
						<p>Map columns in your file to fields in Freshsales. </p>
						<hr>
					</div>
					<div class="col-md-6">
						<label><i class="fa fa-file-text-o"></i> FILE COLUMN </label>
					</div>
					<div class="col-md-6">
						<label>FRESHSALES FIELD</label>
					</div>
					<div class="col-md-12">
						<hr>
					</div>
					<div class="col-md-6">
						<p>dfsfsf</p>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<div class="form-group">
								<select id="single4" class="js-states form-control">
									<option>Choose a value</option>
									<option>Choose a value1</option>
									<option>Choose a value2</option>
									<option>Choose a value3</option>
								</select>
							</div>
						</div>
					</div>
				</form>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-creat " data-dismiss="modal" data-toggle="modal"
					data-target="#ImportsModal">Back</button>
				<button type="button" class="btn btn-save">Import</button>
			</div>
		</div>
	</div>
</div>
<!-- footer section -->

<!-- Modal -->
<div class="modal fade" id="stage1" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">SEND EMAIL</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" id="lead-mail">
       
        <div class="form_panel_stage">
        <div class="">
        	<label>TO : </label>
            <input type="email" id="mail-to" placeholder="to" required/>
        </div>
        <div class="">
        	<label>CC : </label>
            <input type="email" id="mail-cc" placeholder="cc"/>
        </div>
         <div class="">
        	<label>Subject : </label>
            <input type="text" id="mail-subject" placeholder="subject type here.."/>
        </div>
        <div class="">
        	<label>Mail Body : </label>
            <textarea name="mail-body" placeholder="body.." id="mail-body" style="width: 100%;height: 200px; border:#ccc solid 1px;;"></textarea>
        </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="close_stage" data-dismiss="modal"><i class="fa fa-times-circle" aria-hidden="true"></i> &nbsp; Close</button>
        <button type="button" class="save_stage" id="btn-send-mail"><i class="fa fa-floppy-o" aria-hidden="true"></i>  &nbsp;  Send</button>
      </div>
    </div>
  </div>
</div> 

<!-- Task Modal -->
<div class="modal fade" id="stage01" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">ADD TASK</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        
        <div class="form_panel_stage">
        <div class="pd-b-20">
        	<label>Title <span class="reg">*</span></label>
            <input type="text" id="task-title" placeholder="" required/>
        </div>
        <br>
        <div class="pd-b-20">
        	<label>Description <span class="reg">*</span></label>
            <textarea id="task-description" required style="width: 100%;height: 100px; border:#ccc solid 1px;"></textarea>
        </div>
        <br>
        <div class="row">
        	<div class="col-md-4 col-sm-12 col-xs-12">
        		<div class="pd-b-20">
					<label>Task type </label>
					<select name="task-type" id="task-type" required>
						<option value="">--Select a type--</option>
						<option value="follow-up">Follow Up</option>
						<option value="call-reminder">Call reminder</option>
					</select>
				</div>
        	</div>
        	<div class="col-md-4 col-sm-12 col-xs-12">
        		<div class="pd-b-20">
					<label>Due date <span class="reg">*</span></label>
					<div class="input-group date" data-provide="datepicker">
						<input type="text" class="form-control datepicker" id="task-date" required>
						<div class="input-group-addon">
							<span class="glyphicon glyphicon-th"></span>
						</div>
					</div>
				</div>
        		
        	</div>
        	<div class="col-md-4 col-sm-12 col-xs-12">
        		<div class="pd-b-20">
					<label>Time</label>
					<input type="text" id="timepicker" class="timepicker" placeholder="00:00" />
				</div>
        	</div>
        	<div class="clrearfix"></div>        	
        </div>
        
        <br>
        <div class="pd-b-20">
        	<label>Outcome <span class="reg">*</span></label>
            <select name="outcome" id="outcome" required>
				<option value="">--Select an outcome--</option>
				<option value="interrested">Interrested</option>
				<option value="left-message">Left Message</option>
				<option value="no-response">No response</option>
				<option value="no-ableto-reach">Not ableto reach</option>
			</select>
        </div>
        <br>
        <!-- <div class="pd-b-20">
        	<label><input type="checkbox"/> &nbsp; Mark as completed</label>
        </div> -->
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="close_stage" data-dismiss="modal"><i class="fa fa-times-circle" aria-hidden="true"></i> &nbsp; Close</button>
        <button type="button" class="save_stage" id="btn-save-task"><i class="fa fa-floppy-o" aria-hidden="true"></i>  &nbsp;  Save</button>
      </div>
    </div>
  </div>
</div> 

<!-- Modal -->
<div class="modal fade" id="stage02" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">ADD FILES</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
	  	<form id="frm-task-files" enctype="multipart/form-data">
        	<div class="form_panel_stage">
				<div class="pd-b-20">
					<label>Upload a file from your computer </label>
					<div class="fileupload_text">
							<p><i class="fa fa-info-circle" aria-hidden="true"></i> Maximum file size is 20 MB. <a href="#">Files attached</a> can be accessed by any user viewing this Contact.</p>
					</div>
					<div class="inputuploadfile">
					<div class="input-file-container">  
						<input class="input-file" name="file" id="my-file" type="file">
						<label tabindex="0" for="my-file" class="input-file-trigger"><b>Upload you file here</b> <span>Drag your file</span></label>
					</div>
					<p class="file-return"></p>
				</div>
				</div>
				<br>
				<div class="pd-b-20">
					<label>File Name <span class="reg">*</span></label>
					<input type="text" name="file_name" id="file-name" placeholder="Enter a display name for the file"/>
				</div>
				<br>
				<div class="pd-b-20">
					<label><input type="checkbox"/> &nbsp; Share file with everyone</label>            
				</div>
			</div>
		</form>
      </div>
      <div class="modal-footer">
        <button type="button" class="close_stage" data-dismiss="modal"><i class="fa fa-times-circle" aria-hidden="true"></i> &nbsp; Close</button>
        <button type="button" class="save_stage" id="btn-save-file"><i class="fa fa-floppy-o" aria-hidden="true"></i>  &nbsp;  Save</button>
      </div>
    </div>
  </div>
</div> 

<!-- Deal Modal -->
<?php
	$this->load->view('admin/deals/deal_modal');
?>

<!-- Add leade modal -->
<?php
	$this->load->view('admin/leads/lead_modal');
?>
<!-- Script -->
<style>
.fa.fa-pencil{
  cursor: pointer;
}
.custom-text{
    border: 1px solid #2196f3 !important;
    background: #fff !important;
}
  </style>
<script type="text/javascript" src="<?=base_url('public/admin/')?>js/theme.js"></script>
<script src="https://cdn.ckeditor.com/4.15.1/standard/ckeditor.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/timepicker/1.3.5/jquery.timepicker.min.js"></script>
<script>
  $(document).ready(function(){
	//written in custom js
	CKEDITOR.replace( 'mail-body' );

	companyList(source = 'MOB');
	getUserList(new Array(4, 5));
    /*
      ** enable and disabled empty fields
      ** Chayan
    */
    $('#show-empty').on('click', function(){
      let isChecked = $(this). prop("checked");
      $('input.form-control').each(function(key, val){
        if($(this).val()==""){
          if(isChecked == true){
            let x = $(this).parents('.form-group'); //.show();
            x.parent('.col-md-6.col-sm-6').show();
          }else{
            let x= $(this).parents('.form-group'); //.hide();
            x.parent('.col-md-6.col-sm-6').hide();
          }
        }        
      })      
    })
    // End


    $('.lead-stage').on('click', function(){
      console.log($(this).parent('li').hasClass('active'));
      if($(this).parent('li').hasClass('active')){
        swalAlert('You are already confirmed this stage', 'warning');
        return false;
      }
      let stage = $(this).data('val');

      Swal.fire({
				html: '<img src="'+logo_url+'public/admin/images/logo.png" alt="no-image">',
				title: "Are you sure to update lead stage ?",
				type: "warning",
				showCancelButton: true, // true or false  
				confirmButtonColor: "#dd6b55",
				cancelButtonColor: "#48cab2",
				confirmButtonText: "Yes !!!", 
			}).then((result) => {
				if (result.value) {
					$.ajax({
						type: "POST",
						url: base_url+'leads/update-status',
						data: {
							id: "<?=$project[0]['lead_id']?>",
              status: $(this).data('val'),
              'column': 'stage'
						},
						success: function(response) {
							if(response.status.error_code == 0){
								//populate all required fields
                swalAlert(response.status.message, 'success');
                location.reload();
							}else{
								swalAlert(response.status.message, 'warning');
							}
						},
						error: function(response){
							swalAlert('Something wrong, try again', 'warning');
						} 
					});
				}
			});	
    })

    /**
     * Update details column value
     */
    $('.edit').on('click', function(){
      $(this).parent('.col-md-6').find('.fa-pencil').hide();
      $(this).parent('.col-md-6').find('.fa-check').show();

      $(this).parent('.col-md-6').find('input').addClass('custom-text');
      //$(this).closest('.update').show();
    })
    $('.fa.fa-check').on('click', function(){
      let xx = $(this);
      if($('#'+$(this).data('id')).val().trim() == ""){
        return false;
      }
      $.ajax({
						type: "POST",
						url: base_url+'leads/update-lead-details',
						data: {
							id: "<?=$project[0]['lead_id']?>",
              status: $(this).data('val'),
              'column': $(this).data('column'),
              'value': $('#'+$(this).data('id')).val()
						},
						success: function(response) {
							if(response.status.error_code == 0){
                xx.parent('.edit').find('.fa-check').hide();
                xx.parent('.edit').find('.fa-pencil').show();
                xx.parents('.col-md-6').find('input').removeClass('custom-text');
							}else{
								//swalAlert(response.status.message, 'warning');
							}
						},
						error: function(response){
							swalAlert('Something wrong, try again', 'warning');
						} 
					});
    })
  })
	$('.right_panel').slimscroll({
		height: '544px',
		color: '#e12f36',
		size: '5px'

	});

/**Lead details right side menues */	
$(document).ready(function(){
	$('#btn-add-note').on('click', function(){
		let note= $('#lead-notes-text').val().trim();
		if(note == ""){
			$('#lead-notes-text'),focus();
			return false;
		}
		$.ajax({
				type: "POST",
				url: base_url+'leads/saveLeadNote',
				data: {
					lead_id: "<?=$project[0]['lead_id']?>",
					lead_note_id: lead_note_id,
        	    	note: note,
						},
				success: function(response) {
					if(response.status.error_code == 0){
						$('#lead-notes-text').val('');
						swalAlert(response.status.message);
						if(lead_note_id!= ""){
							$('#lead-note-txt-'+lead_note_id).html(note);
						}else{
							$('#sec-lead-notes')
							.append('<div class="trying_to_conact_l"> <svg width="12px" height="12px" viewBox="0 0 18 18" xmlns="http://www.w3.org/2000/svg"><g stroke="#000" fill="none" fill-rule="evenodd"><path d="M10.921.52H4.113c-.94 0-1.702.761-1.702 1.701v13.616c0 .94.762 1.702 1.702 1.702h10.212c.94 0 1.702-.762 1.702-1.702V5.625L10.921.52z"></path><path d="M10.921.52v4.105a1 1 0 0 0 1 1h4.106"></path><path d="M12.623 9.88H5.815M12.623 13.284H5.815M7.517 6.476H5.815" stroke-linecap="round" stroke-linejoin="round"></path></g></svg></div><div class="trying_to_conact_r"> <span>'+note+'</span> <b><svg width="14" height="14" viewBox="0 0 14 14" xmlns="http://www.w3.org/2000/svg" class="svg-sm"><g fill-rule="nonzero" fill="none"><path fill-opacity=".01" fill="#FFF" d="M0 0h14v14H0z"></path><g transform="translate(1 1)" stroke="#2C5CC5"><rect x=".068" y="9.5" width="12" height="3" rx="1"></rect><path d="M1.044 9.451h10.054a.1.1 0 0 0 .098-.08l.874-4.433a.1.1 0 0 0-.128-.114l-3.48 1.09a.1.1 0 0 1-.114-.04L6.154 2.56a.1.1 0 0 0-.166 0L3.789 5.874a.1.1 0 0 1-.113.04L.194 4.825a.1.1 0 0 0-.128.115l.88 4.431a.1.1 0 0 0 .098.081z"></path><circle stroke-width="1.2" cx="6.068" cy=".5" r="1"></circle></g></g></svg> &nbsp; '+"<?=$admin['name']?>"+'</b> <i>Now</i><div class="clearfix"></div></div>');
						}
					}else{
						swalAlert(response.status.message);
					}
				}
		})
	})

	//send email for lead
	$('#btn-send-mail').on('click', function(){
		let to = $('#mail-to').val().trim();
		let cc = $('#mail-cc').val().trim();
		let subject = $('#mail-subject').val().trim();
		//let body = CKEDITOR.instances.mail-body.getData();
		let body = CKEDITOR.instances['mail-body'].getData();

		if(to == ""){
			swalAlert('To is required to send mail');
			return false;
		}
		if(subject == ""){
			swalAlert('Subject is required to send mail');
			return false;
		}
		if(body == ""){
			swalAlert('Body is required to send mail');
			return false;
		}

		$.ajax({
				type: "POST",
				url: base_url+'leads/sendEmail',
				data: {
					lead_id: "<?=$project[0]['lead_id']?>",
					to: to,
					cc: cc,
					subject: subject,
					body: body,
					user_id: "<?=$admin['id']?>",
						},
				success: function(response) {
					if(response.status.error_code == 0){
						swalAlert(response.status.message);
					}
				}
			})
	})

	//send email for lead
	$('#btn-save-task').on('click', function(){
		let title = $('#task-title').val().trim();
		let description = $('#task-description').val().trim();
		let type = $('#task-type').val().trim();
		//let body = CKEDITOR.instances.mail-body.getData();
		let date = $('#task-date').val().trim();
		let time = $('#timepicker').val().trim();
		let outcome = $('#outcome').val().trim();

		if(title == ""){
			swalAlert('Title is required to send mail');
			return false;
		}
		if(description == ""){
			swalAlert('Description is required to send mail');
			return false;
		}
		if(type == ""){
			swalAlert('Type is required to send mail');
			return false;
		}
		if(date == ""){
			swalAlert('Date is required to send mail');
			return false;
		}
		if(outcome == ""){
			swalAlert('Outcome is required to send mail');
			return false;
		}
		let t = $(this);
		$.ajax({
				type: "POST",
				url: base_url+'leads/saveTask',
				data: {
					lead_id: "<?=$project[0]['lead_id']?>",
					title: title,
					description: description,
					type: type,
					date: date,
					time: time,
					outcome: outcome,
					user_id: "<?=$admin['id']?>",
					lead_task_id: lead_task_id
						},
				success: function(response) {
					if(response.status.error_code == 0){
						if(lead_task_id !=""){
							t.parent('h3').html(title);
						}else{
							$('#sec-lead-task')
							.append('<div class="taskbox"><div class="tak_top"><h3>'+title+'<span> <a href=""><i class="fa fa-pencil" aria-hidden="true"></i></a> <a href=""><i class="fa fa-trash-o" aria-hidden="true"></i></a></span></h3></div><div class="tak_mid"> <b><svg width="14" height="14" viewBox="0 0 14 14" xmlns="http://www.w3.org/2000/svg" class="svg-sm"><g fill-rule="nonzero" fill="none"><path fill-opacity=".01" fill="#FFF" d="M0 0h14v14H0z"></path><g transform="translate(1 1)" stroke="#2C5CC5"><rect x=".068" y="9.5" width="12" height="3" rx="1"></rect><path d="M1.044 9.451h10.054a.1.1 0 0 0 .098-.08l.874-4.433a.1.1 0 0 0-.128-.114l-3.48 1.09a.1.1 0 0 1-.114-.04L6.154 2.56a.1.1 0 0 0-.166 0L3.789 5.874a.1.1 0 0 1-.113.04L.194 4.825a.1.1 0 0 0-.128.115l.88 4.431a.1.1 0 0 0 .098.081z"></path><circle stroke-width="1.2" cx="6.068" cy=".5" r="1"></circle></g></g></svg> &nbsp; '+"<?=$admin['name']?>"+'</b> <i>Due date: Now</i></div><div class="clearfix"></div></div>');
						}
						swalAlert(response.status.message);
						
					}else{
						swalAlert(response.status.message);
					}
				}
			})
	})
	//save files for lead
	$('#btn-save-file').on('click', function(){
		let name = $('#file-name').val().trim();

		if(name == ""){
			swalAlert('Name is required to send mail');
			return false;
		}
		var formData = new FormData(document.querySelector('#frm-task-files'));
		formData.append('lead_id', "<?=$project[0]['lead_id']?>");
		$.ajax({
				type: "POST",
				url: base_url+'leads/saveFiles',
				data: formData,
                cache: false,
                contentType: false,
                processData: false,
				success: function(response) {
					console.log(response);
					if(response.status.error_code == 0){
						swalAlert(response.status.message);
						$('#sec-lead-file')
						.append('<div class="taskbox"><div class="tak_top_l"> <i class="fa fa-file-text-o" aria-hidden="true"></i></div><div class="tak_top_r"><div class="tak_top"><h3 style="color: #2196F3"><a href="'+response.result.data.file+'" target="_blank">'+response.result.data.file_name+'</a><span> <a href=""><i class="fa fa-pencil" aria-hidden="true"></i></a> <a href=""><i class="fa fa-trash-o" aria-hidden="true"></i></a></span></h3></div><div class="tak_mid"> <b><svg width="14" height="14" viewBox="0 0 14 14" xmlns="http://www.w3.org/2000/svg" class="svg-sm"><g fill-rule="nonzero" fill="none"><path fill-opacity=".01" fill="#FFF" d="M0 0h14v14H0z"></path><g transform="translate(1 1)" stroke="#2C5CC5"><rect x=".068" y="9.5" width="12" height="3" rx="1"></rect><path d="M1.044 9.451h10.054a.1.1 0 0 0 .098-.08l.874-4.433a.1.1 0 0 0-.128-.114l-3.48 1.09a.1.1 0 0 1-.114-.04L6.154 2.56a.1.1 0 0 0-.166 0L3.789 5.874a.1.1 0 0 1-.113.04L.194 4.825a.1.1 0 0 0-.128.115l.88 4.431a.1.1 0 0 0 .098.081z"></path><circle stroke-width="1.2" cx="6.068" cy=".5" r="1"></circle></g></g></svg> &nbsp; '+"<?=$admin['name']?>"+'</b> <i>Due date: -</i></div></div><div class="clearfix"></div></div>');
					}else{
						swalAlert(response.status.message);
					}
				}
			})
	})

	//update life cycle stage
	$('.update-lifecycle').on('click', function(){
		let lifycycle_id = $(this).data('parent');
		let stage = $(this).data('val');
		
		$('#edit.action').click();
		setTimeout(function(){
			$('#lifecycle_stage option[value="'+lifycycle_id+'"]').attr("selected", "selected");
		
			getLifecycleData(lifycycle_id, select = stage);
		}, 2000);
			
	})


})

</script>
<script>
	$('.app_cal_body').slimscroll({
		height: '300px',
		color: '#e12f36',
		size: '5px'

	});

	$('.user_detail_sec').slimscroll({
		height: '600px',
		color: '#e12f36',
		size: '5px'

	});

</script>
<script>
	$(document).ready(function () {
		$('#leads_table').DataTable({
			"paging": false,
			"searching": false
		});
	});

</script>

<script>
$('.datepicker').datepicker({
    format: 'mm/dd/yyyy',
    startDate: '-3d'
});

$('.timepicker').timepicker({
    // timeFormat: 'h:mm p',
    // interval: 60,
    // minTime: '10',
    // maxTime: '6:00pm',
    // defaultTime: '11',
    // startTime: '10:00',
    // dynamic: false,
    // dropdown: true,
    // scrollbar: true
});
</script>

<script>
document.querySelector("html").classList.add('js');

var fileInput  = document.querySelector( ".input-file" ),  
    button     = document.querySelector( ".input-file-trigger" ),
    the_return = document.querySelector(".file-return");
      
button.addEventListener( "keydown", function( event ) {  
    if ( event.keyCode == 13 || event.keyCode == 32 ) {  
        fileInput.focus();  
    }  
});
button.addEventListener( "click", function( event ) {
   fileInput.focus();
   return false;
});  
fileInput.addEventListener( "change", function( event ) {  
    the_return.innerHTML = this.value;  
});  
</script>

