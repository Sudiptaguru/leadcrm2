<?php $admin=$this->session->userdata('admin'); ?>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/js/bootstrap-datepicker.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/css/bootstrap-datepicker3.css"/>
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>

<link href="https://cdn.datatables.net/rowreorder/1.2.5/css/rowReorder.dataTables.min.css" rel="stylesheet" />
<link href="https://cdn.datatables.net/responsive/2.2.3/css/responsive.dataTables.min.css" rel="stylesheet" />
<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
          <h3>
            Leads settings
            
          </h3>
          <!--<ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Dashboard</li>
          </ol>-->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header with-border">
			        <?php if($this->session->flashdata('error_msg')){?>
							<div class="alert alert-warning alert-dismissible hite">
								<button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
								<h4><i class="icon fa fa-warning"></i><?php echo $this->session->flashdata('error_msg'); ?></h4>
							</div>
						  <?php }?>
						  <?php if($this->session->flashdata('success_msg')){?>
							<div class="alert alert-success alert-dismissible hite">
								<button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
								<h4><i class="icon fa fa-warning"></i><?php echo $this->session->flashdata('success_msg'); ?></h4>
							</div>
						  <?php }?>
              <div class="row" >
                <div class='col-sm-2'>
                  <div class="form-group">
                   <label>From Date</label>
                    <div class='input-group date'>
                      <input type='text' class="form-control" placeholder="Start Date" value="" id="start_date"/>
                      <span class="input-group-addon">
                        <span class="glyphicon glyphicon-calendar"></span>
                      </span>
                    </div>
                  </div>
                </div>
                <div class='col-sm-2'>
                  <div class="form-group">
                   <label>To Date</label>
                    <div class='input-group date'>
                      <input type='text' class="form-control" placeholder="End Date" value="" id="end_date"/>
                      <span class="input-group-addon">
                        <span class="glyphicon glyphicon-calendar"></span>
                      </span>
                    </div>
                  </div>
                </div>
                <div class='col-sm-2'>
                  <div class="form-group">
                    <label></label>
                    <button class="form-control btn-primary" id="btn_filter">Search</button>
                  </div>
                </div>                
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table display nowrap table-bordered table-striped">
                <thead>
                <tr>
                  <th>Sl no</th>
                  <th>Client Name</th>
                  <th>Email Id</th>
                  <th>Phone No</th>
                  <th>Company</th>
                  <th>Campaign</th>
                  <th>State</th>
                  <!--<th>From Time</th>-->
                  <!--<th>To Time</th>-->
                  <!--<th>Timezone</th>-->
                  <!--<th>Schedule For Contact</th>-->
                  <th>Project Status</th>
                  <!--<th>Quotation Price</th>-->
                  <!--<th>Closing Price</th>-->
                  <th>Post Date</th>
                  <th>Assign Status</th>
                  <?php //if ($admin['role_id'] == 2) { ?>
                  <th class="no-sort">Assign To</th>
                  <?php //} ?>

                  <th class="no-sort">Action</th>				  
                </thead>
                <tbody>
                </tbody>
                <tfoot>
                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- Modal -->
	  <div class="modal" id='myModal'>
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">×</span></button>
                <h4 class="modal-title">Message</h4>
              </div>
              <div class="modal-body" id='modalContent' title="">
               <!-- <p>Would you like to continue ?</p>-->
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary" data-dismiss="modal" id="cdel">Ok</button>
              </div>
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>
	  <!-- Modal -->
<script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url()?>public/admin_assets/plugins/datatables/dataTables.bootstrap.min.js"></script>
<script src="https://cdn.datatables.net/rowreorder/1.2.5/js/dataTables.rowReorder.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.2.3/js/dataTables.responsive.min.js"></script>
<script>
$(document).ready(function() { 
  var now = new Date();
  var date = now.getFullYear() + "-" + now.getMonth() + "-" + now.getDate();
	table = $('#example1').DataTable({ 
      
        "processing": true, //Feature control the processing indicator.
        "serverSide": true, //Feature control DataTables' server-side processing mode.
        "order": [], //Initial no order.
 
        // Load data for the table's content from an Ajax source
        "ajax": {
            "url": "<?php echo site_url('admin/leads/all_content_list')?>",
            "type": "POST",
            "data": function(args){
              args.start_date = $('#start_date').val(),
              args.end_date = $('#end_date').val()
            }
        },
 
        //Set column definition initialisation properties.
        "columnDefs": [
        { 
            "targets": 'no-sort', 
            "orderable": false, //set not orderable
        },
        ],
        rowReorder: {
            selector: 'td:nth-child(2)'
        },
        //responsive: true,
        scrollX: true,
        dom:'Bfrtip',
        buttons:[{ 
            extend: 'excel',                        
            filename: 'leads_list_' + date,
            className: "btn btn-round_small btn-img",
            text: '<i class="fa fa-file-excel-o" aria-hidden="true"></i> Export',
            tag:  'span',
            exportOptions: { columns: [0,1,2,3,4,5,6,7] }  
        }     
        //'excel'
        ]
    });
  $('#btn_filter').click(function(){
    table.draw();
  });
	$(document).on( "click",'#delete.cstm_view',function() {
		$('#modalContent').html('<p>Would you like to continue ?</p>');
		var id=$(this).prop('title');
		$('#modalContent').attr('title',id);
		$('#myModal').modal('show');
	});
	$(document).on('click','#cdel',function(){
	var id=$('#modalContent').prop('title');
	$.ajax({
	  type: "POST",
	  url: '<?php echo base_url('admin/leads/delete_content')?>',
	  data: 'id='+id,
	  dataType:'json',
	  success: function(response){
		$('#modalContent').html(response.message);  
		$('#myModal').modal('show');
		setTimeout(function(){
			$('#myModal').modal('hide')
		},400);
		window.location.reload('<?php echo base_url('admin/leads'); ?>');
		
	  },
	  error:function(response){
		$('#modalContent').html(response.message);  
		$('#myModal').modal('show');
		setTimeout(function(){
			$('#myModal').modal('hide')
		},400);
	  }
	});
});
  $('#start_date').datepicker({
    maxDate: '0',
    format: 'yyyy-mm-dd',
    setDate: new Date()
  });
  
  $('#end_date').datepicker({
    maxDate: '0',
    format: 'yyyy-mm-dd',
    setDate: new Date()
  });

  $('.js-example-basic-single').select2({
  });
});
$(document).on("change",".assign_to",function(){
  var user_id = $('option:selected', this).val();
  var project_id = $('option:selected', this).data('project_id');

  //alert(project_id);
  if (user_id == "") {
    alert("Please select a person to assign");
  } else{
    $.ajax({
      type: "POST",
      url: '<?php echo base_url('admin/leads/assign_project')?>',
      data: 'user_id='+user_id+"&project_id="+project_id,
      dataType:'json',
      success: function(response){
        //console.log(response);return false;
        window.location.reload('<?php echo base_url('admin/leads'); ?>');
      },
      error:function(response){
        alert("Please try again");
      }
    });
  };
})
</script>
  