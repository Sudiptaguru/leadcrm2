    
    
<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h3>
          Comment List
        </h3>
    </section>
    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header with-border">
            <a href="<?php echo base_url('admin/leads/message'); ?>/<?php echo $lead_id; ?>" class="btn btn-sm btn-primary" style="float:right">Add Comment</a>
              <?php if($this->session->flashdata('error_msg')){?>
              <div class="alert alert-warning alert-dismissible hite">
                <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
                <h4><i class="icon fa fa-warning"></i><?php echo $this->session->flashdata('error_msg'); ?></h4>
              </div>
              <?php }?>
              <?php if($this->session->flashdata('success_msg')){?>
              <div class="alert alert-success alert-dismissible hite">
                <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
                <h4><i class="icon fa fa-warning"></i><?php echo $this->session->flashdata('success_msg'); ?></h4>
              </div>
              <?php }?>
            </div>
              
              <table class="table table-striped table-bordered export_btn_dt c_table_style">
                <thead>
                  <tr>
                    <th>Sl no</th>
                    <th>Lead Name</th>
                    <th>Comment</th>
                    <th>Commented By</th>
                    <th>Posted On</th>
                  </tr>
                </thead>
                <tbody>
              		  <?php //foreach ($client_query->result_array() as $row): ?>
              		  <?php 
                    $i=1;
                    if(!empty($messageList)) { 
                    foreach($messageList as $row):  ?>
                        <tr>
                            <td><?php echo $i; ?></td>
                            <td><?php echo $project_name;?></td>
                            <td><?php echo $row['message']; ?></td>
                            <td><?php echo $row['name']; ?></td>
                            <td><?php echo date("d M Y H:i",strtotime($row['post_date'])); ?></td>
                            <!-- <td> 
                                <a class="application_delete" href="<?php echo base_url(); ?>admin/leads/delete_message/?id=<?php echo $row['idd']; ?>&m_id=<?php echo $client_id; ?>" data-id="<?php echo $row['id']; ?>"  data-table="lead_message" data-function="faqTable">
                                    <i class="glyphicon glyphicon-remove"></i>
                                </a>
              				  <a class="cstm_view" href="<?php echo base_url(); ?>admin/leads/edit_message/?id=<?php echo $row['idd']; ?>&m_id=<?php echo $client_id; ?>" title="Edit"><i class="glyphicon glyphicon-edit"></i></a>
                            </td> -->
                        </tr>
              		  <?php 
                    $i++;
                  endforeach; 
                }
                else
                {
                ?>
                <tr><td class="no_data_container">No comment available</td></tr>
                <?php
                }
                ?>
                </tbody>
                <tfoot>
                </tfoot>
              </table>
             

            <!--</div>-->
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  
 
<script type="text/javascript">
    adminPage = 'Companylist';
$(document).on("click",".application_delete", function() {
        Swal.fire({
            title: "Are you sure want to delete?",
            type: "warning",
            showCancelButton: true, // true or false
            confirmButtonColor: "#dd6b55",
            cancelButtonColor: "#48cab2",
            confirmButtonText: "Yes !!!"
        }).then(result => {
            if (result.value) {
                let id = $(this).attr("data-id");
                let table = $(this).attr("data-table");
                if (id && table) {
                    $.ajax({
                        type: "POST",
                        url: base_url + "Leads/delete1",
                        data: {
                            id: id,
                            table: table
                        },
                        dataType: "json",
                        success: function(response) {
                        //alert(response.status);
                            if (response.status == 1) {
                                alert("Successful");
                                location.reload();
                            } else {
                                alert("Error");
                            }
                        }
                    });
                }
            }
        });

    });    
</script>
  
