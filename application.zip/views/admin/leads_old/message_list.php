    
    
<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h3>
          Comment List
        </h3>
    </section>
    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header with-border">
            <a href="<?php echo base_url('admin/leads/message'); ?>/<?php echo $lead_id; ?>" class="btn btn-sm btn-primary" style="float:right">Add Comment</a>
              <?php if($this->session->flashdata('error_msg')){?>
              <div class="alert alert-warning alert-dismissible hite">
                <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
                <h4><i class="icon fa fa-warning"></i><?php echo $this->session->flashdata('error_msg'); ?></h4>
              </div>
              <?php }?>
              <?php if($this->session->flashdata('success_msg')){?>
              <div class="alert alert-success alert-dismissible hite">
                <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
                <h4><i class="icon fa fa-warning"></i><?php echo $this->session->flashdata('success_msg'); ?></h4>
              </div>
              <?php }?>
            </div>
              <div class="comment_sec">
              		<ul class="comment_list">
              		    <?php
              		    if(!empty($messageList)) { 
                            foreach($messageList as $row):  ?>
              			<li>
              				<div class="date_sec"><?php echo date("d M Y",strtotime($row['post_date'])); ?></div>
              				<h3><?php echo $project_name;?></h3>
              				<!--<h4>Geschaftsfohrerin eines Web-Studios</h4>-->
              				<h4><strong><?php echo $row['name']; ?></strong></h4>
              				<p><?php echo $row['message']; ?></p>
              			</li>
              			<?php 
              			  endforeach; 
                        }
                        ?>
              			
              			
              			<!--<li>-->
              			<!--	<div class="date_sec">April 2020</div>-->
              				
              			<!--</li>-->
              			
              		</ul>
              </div>

             

            <!--</div>-->
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  
 
<script type="text/javascript">
    adminPage = 'Companylist';
$(document).on("click",".application_delete", function() {
        Swal.fire({
            title: "Are you sure want to delete?",
            type: "warning",
            showCancelButton: true, // true or false
            confirmButtonColor: "#dd6b55",
            cancelButtonColor: "#48cab2",
            confirmButtonText: "Yes !!!"
        }).then(result => {
            if (result.value) {
                let id = $(this).attr("data-id");
                let table = $(this).attr("data-table");
                if (id && table) {
                    $.ajax({
                        type: "POST",
                        url: base_url + "Leads/delete1",
                        data: {
                            id: id,
                            table: table
                        },
                        dataType: "json",
                        success: function(response) {
                        //alert(response.status);
                            if (response.status == 1) {
                                alert("Successful");
                                location.reload();
                            } else {
                                alert("Error");
                            }
                        }
                    });
                }
            }
        });

    });    
</script>
  
