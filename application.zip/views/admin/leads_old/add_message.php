<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
<!-- Content Wrapper. Contains page content -->
       <?php $client_id=$this->uri->segment(4); ?>
	   <?php   
	   //$client_query = $this->db->query("SELECT * FROM new_project where id='$client_id'");
	   ?>
	   
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h3>
            Add Comment
          </h3>
          <!--<ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Dashboard</li>
          </ol>-->
        </section>

        <!-- Main content -->
		<?php //foreach ($client_query->result_array() as $row): ?>
        <section class="content"> 
			<div class="row">
				<!-- general form elements -->
				<div class="col-md-12">
					  <div class="box box-primary">
						<div class="box-header with-border">
						  <h3 class="box-title"></h3>
						  <?php if($this->session->flashdata('error_msg')){?>
							<div class="alert alert-warning alert-dismissible hite">
								<button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
								<h4><i class="icon fa fa-warning"></i><?php echo $this->session->flashdata('error_msg'); ?></h4>
							</div>
						  <?php }?>
						  <?php if($this->session->flashdata('success_msg')){?>
							<div class="alert alert-success alert-dismissible hite">
								<button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
								<h4><i class="icon fa fa-warning"></i><?php echo $this->session->flashdata('success_msg'); ?></h4>
							</div>
						  <?php }?>
						</div>
						<!-- /.box-header -->
						<!-- form start -->
						<form role="form" class="mtbresize" method="post" action="<?php echo base_url('admin/leads/add_message');?>" enctype="multipart/form-data">
						  <div class="box-body">
                             <?php if($this->session->flashdata('client_msg')) { ?>
							 <p class="alert alert-success"><?php echo $this->session->flashdata('client_msg'); ?></p>
							 <?php } ?>                    
						  	<div class="form-group">
							  <label for="name">Lead Name</label>
							  <input type="hidden" name="client_id" value="<?php echo $lead_id; ?>">
							  <div><?php echo $project_name; ?>
							  
							</div>
					

							<div class="form-group">
							  <label for="project_description">Comment</label>
							  <textarea class="form-control" id="project_description" name="msg" required=""></textarea>
							  <?php echo form_error('project_description','<span class="error">', '</span>'); ?>
							  
							</div>
							

							<!--<div class="form-group">
							  <label>Currency</label>
							  <select class="form-control" name="currency" id="currency">
								<option value="aud" <?php if($project['currency']=="aud"){?>selected="selected"<?php }?>>AUD</option>
								<option value="euro" <?php if($project['currency']=="euro"){?>selected="selected"<?php }?>>EURO</option>
								<option value="usd" <?php if($project['currency']=="usd"){?>selected="selected"<?php }?>>USD</option>
								<option value="nzd" <?php if($project['currency']=="nzd"){?>selected="selected"<?php }?>>NZD</option>
								<option value="gbp" <?php if($project['currency']=="gbp"){?>selected="selected"<?php }?>>GBP</option>
							  </select>
							</div>-->
							
						  </div>
						  <!-- /.box-body -->
						  <div class="box-footer">
						  	
						  	<button type="button" style="background-color:black;color:white" onclick="window.history.back()" class="btn btn-sm btn-round">Back</button>
                            <button type="submit" class="btn btn-sm btn-primary">Submit</button>				
                          </div>
						</form>
					  </div>
				</div>
          <!-- /.box -->
          </div><!-- /.row -->	
        </section><!-- /.content -->
		<?php //endforeach; ?>
      </div><!-- /.content-wrapper -->
<script type="text/javascript">
	$('.js-example-basic-single').select2({
  });
</script>