<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
<!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h3>
            Leads settings
            
          </h3>
          <!--<ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Dashboard</li>
          </ol>-->
        </section>

        <!-- Main content -->
        <section class="content"> 
			<div class="row">
				<!-- general form elements -->
				<div class="col-md-12">
					  <div class="box box-primary">
						<div class="box-header with-border">
						  <h3 class="box-title"></h3>
						  <?php if($this->session->flashdata('error_msg')){?>
							<div class="alert alert-warning alert-dismissible hite">
								<button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
								<h4><i class="icon fa fa-warning"></i><?php echo $this->session->flashdata('error_msg'); ?></h4>
							</div>
						  <?php }?>
						  <?php if($this->session->flashdata('success_msg')){?>
							<div class="alert alert-success alert-dismissible hite">
								<button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
								<h4><i class="icon fa fa-warning"></i><?php echo $this->session->flashdata('success_msg'); ?></h4>
							</div>
						  <?php }?>
						</div>
						<!-- /.box-header -->
						<!-- form start -->
						<form role="form" class="mtbresize" method="post" action="<?php echo base_url('admin/leads/update');?>" enctype="multipart/form-data">
						  <div class="box-body">
						  	<div class="form-group">
							  <label for="name">Client Name</label>
							  <input type="text" class="form-control" id="name" value="<?php echo $project['title'].' '.$project['name'].' '.$project['lname'];?>" placeholder="first name" readonly>
							  <?php echo form_error('name','<span class="error">', '</span>'); ?>
							</div>
							
							<div class="form-group">
							  <label for="email">Client Email</label>
							  <input type="email" class="form-control" id="email" value="<?php echo $project['email_id'];?>" placeholder="email" readonly>
							  <?php echo form_error('email','<span class="error">', '</span>'); ?>
							</div>
							<div class="form-group">
							  <label for="phone">Client Phone</label>
							  <input type="phone" class="form-control" id="phone" value="<?php echo $project['phone'];?>" placeholder="phone" readonly>
							  <?php echo form_error('phone','<span class="error">', '</span>'); ?>
							</div>
							<div class="form-group">
							  <label for="name">State</label>
							  <input type="text" class="form-control" id="state" value="<?php echo $project['state'];?>" placeholder="State" readonly>
							  <?php echo form_error('name','<span class="error">', '</span>'); ?>
							</div>
							<div class="form-group">
							  <label for="name">Source</label>
							  <input type="text" class="form-control" id="source" value="<?php echo $project['source'];?>" placeholder="Source" readonly>
							  <?php echo form_error('name','<span class="error">', '</span>'); ?>
							</div>
							<div class="form-group">
							  <label for="domain_website">Domain Website</label>source
							  <input type="text" class="form-control" id="domain_website" value="<?php echo $project['domain_website'];?>" readonly>
							  <?php echo form_error('domain_website','<span class="error">', '</span>'); ?>
							</div>
							<div class="form-group">
							  <label for="requirement">Requirement</label>
							  <textarea class="form-control" id="requirement" readonly><?php echo $project['requirement'];?></textarea>
							  <?php echo form_error('requirement','<span class="error">', '</span>'); ?>
							</div>
							<!--<div class="form-group">
							  <label for="schedule">Schedule For Contact</label>
							  <input type="schedule" class="form-control" id="schedule" value="<?php //echo date( 'd-M-Y h:ia', strtotime( $project['schedule_for_contact'] ) );?>" placeholder="schedule" readonly>
							  <?php //echo form_error('schedule','<span class="error">', '</span>'); ?>
							</div>-->
							<div class="form-group">
							  <label for="message">Message</label>
							  <textarea class="form-control" id="message" readonly><?php echo $project['message'];?></textarea>
							  <?php echo form_error('message','<span class="error">', '</span>'); ?>
							</div>
							<div class="form-group">
							  <label for="project_name">Project Name</label>
							  <input type="project_name" class="form-control" id="project_name" name="project_name" value="<?php echo $project['project_name'];?>" placeholder="Project Name">
							  <?php echo form_error('project_name','<span class="error">', '</span>'); ?>
							</div>
							<div class="form-group">
							  <label for="project_description">Project Description</label>
							  <textarea class="form-control" id="project_description" name="project_description"><?php echo $project['project_description'];?></textarea>
							  <?php echo form_error('project_description','<span class="error">', '</span>'); ?>
							</div>
							<div class="form-group">
							  <label>Currency</label>
							  <select class="form-control" name="currency" id="currency">
								<option value="aud" <?php if($project['currency']=="aud"){?>selected="selected"<?php }?>>AUD</option>
								<option value="euro" <?php if($project['currency']=="euro"){?>selected="selected"<?php }?>>EURO</option>
								<option value="usd" <?php if($project['currency']=="usd"){?>selected="selected"<?php }?>>USD</option>
								<option value="nzd" <?php if($project['currency']=="nzd"){?>selected="selected"<?php }?>>NZD</option>
								<option value="gbp" <?php if($project['currency']=="gbp"){?>selected="selected"<?php }?>>GBP</option>
							  </select>
							</div>
							<div class="form-group">
							  <label for="quotation_price">Quotation Price</label>
							  <input type="number" step="0.01" min="0" class="form-control" id="quotation_price" name="quotation_price" value="<?php echo $project['quotation_price'];?>" placeholder="Quotation Price" >
							  <?php echo form_error('quotation_price','<span class="error">', '</span>'); ?>
							</div>
							<div class="form-group">
							  <label for="closing_price">Closing Price</label>
							  <input type="number" step="0.01" min="0" class="form-control" id="closing_price" name="closing_price" value="<?php echo $project['closing_price'];?>" placeholder="Closing Price" >
							  <?php echo form_error('closing_price','<span class="error">', '</span>'); ?>
							</div>
							<div class="form-group">
							  <label for="commission_price">Commission Price</label>
							  <input type="number" step="0.01" min="0" class="form-control" id="commission_price" name="commission_price" value="<?php echo $project['commission'];?>" placeholder="Commission Price" >
							  <?php echo form_error('commission_price','<span class="error">', '</span>'); ?>
							</div>
							<div class="form-group">
							  <label>Assign To</label>
							  <?php
							  $assigned_user_id="";
							  if(!empty($assigned_data))
							  {
							    $assigned_user_id=  $assigned_data['user_id'];
							  }
							  ?>
							  <select class="form-control js-example-basic-single" name="user" id="user" >
							      <option value="">Select</option>
							  	<?php foreach ($users as $user) { ?>
							  		<option value="<?=$user['id']?>" <?php if($assigned_user_id!=""&&$assigned_user_id==$user['id']){ echo "selected"; } ?>><?=$user['name']?></option>
							  	<?php } ?>
							  </select>
							</div>
							<div class="form-group">
							  <label>Project Status</label>
							  <select class="form-control" name="status" id="status">
								<option value="open" <?php if($project['status']=="open"){?>selected="selected"<?php }?>>Open</option>
								<option value="awarded" <?php if($project['status']=="awarded"){?>selected="selected"<?php }?>>Awarded</option>
								<option value="innegotiation" <?php if($project['status']=="innegotiation"){?>selected="selected"<?php }?>>In-negotiation</option>
								<option value="lost" <?php if($project['status']=="lost"){?>selected="selected"<?php }?>>Lost</option>
							  </select>
							</div>
						  </div>
						  <!-- /.box-body -->
						  <div class="box-footer">
						  	<input type="hidden" name="project_id" value="<?php echo $project['id'];?>">
						  	<button type="button" style="background-color:black;color:white" onclick="window.history.back()" class="btn btn-sm btn-round">Back</button>
                            <button type="submit" class="btn btn-sm btn-primary">Submit</button>						  </div>
						</form>
					  </div>
				</div>
          <!-- /.box -->
          </div><!-- /.row -->	
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
<script type="text/javascript">
	$('.js-example-basic-single').select2({
  });
</script>