<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
<!-- Content Wrapper. Contains page content -->
       <?php //echo $client_id=$this->uri->segment(4); ?>
	   <?php   
	   //$client_query = $this->db->query("SELECT * FROM new_project where id='$client_id'");
	   ?>
	   <?php  
	   $message_id=$this->input->get('id');
	   $lead_id=$this->input->get('m_id');
	   ?>
	   <?php 
       $sql="SELECT new_project.title,new_project.name,new_project.lname,new_project.id as id,lead_message.id as idd,lead_message.message,lead_message.post_date from new_project LEFT JOIN lead_message ON lead_message.lead_id = new_project.id where lead_message.id='$message_id'";	   
	   $client_query = $this->db->query($sql);
	   ?>
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h3>
            Edit Message
          </h3>
        </section>

        <!-- Main content -->
		<?php //foreach ($client_query->result_array() as $row): ?>
        <section class="content"> 
			<div class="row">
				<!-- general form elements -->
				<div class="col-md-12">
					  <div class="box box-primary">
						<div class="box-header with-border">
						  <h3 class="box-title"></h3>
						  <?php if($this->session->flashdata('error_msg')){?>
							<div class="alert alert-warning alert-dismissible hite">
								<button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
								<h4><i class="icon fa fa-warning"></i><?php echo $this->session->flashdata('error_msg'); ?></h4>
							</div>
						  <?php }?>
						  <?php if($this->session->flashdata('success_msg')){?>
							<div class="alert alert-success alert-dismissible hite">
								<button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
								<h4><i class="icon fa fa-warning"></i><?php echo $this->session->flashdata('success_msg'); ?></h4>
							</div>
						  <?php }?>
						</div>
						<!-- /.box-header -->
						<!-- form start -->
						<?php foreach ($client_query->result_array() as $row1){ ?>
						<form role="form" class="mtbresize" method="post" action="<?php echo base_url('admin/leads/update_message');?>" enctype="multipart/form-data">
						  
						  <div class="box-body">
                             <?php if($this->session->flashdata('client_msg')) { ?>
							 <p class="alert alert-success"><?php echo $this->session->flashdata('client_msg'); ?></p>
							 <?php } ?>
							 
						  	<div class="form-group">
							  <label for="name">Client Name</label>
							  <?php echo form_error('name','<span class="error">', '</span>'); ?>
							  <select class="form-control" name="ooclient_id" id="role"">
								<option value="<?php echo $row1['id']; ?>"><?php echo $row1['title'].' '.$row1['name'].' '.$row1['lname'];?></option>
							  </select>
							</div>
							  <input type="hidden" name="client_id" value="<?php echo $row1['id']; ?>">
					          <input type="hidden" name="message_id" value="<?php echo $row1['idd']; ?>">
                              
							<div class="form-group">
							  <label for="project_description">Message</label>
							  <textarea class="form-control" id="project_description" name="msg" required=""><?php echo $row1['message']; ?></textarea>
							  <?php echo form_error('project_description','<span class="error">', '</span>'); ?>
							</div>
													
						  </div>
						  <!-- /.box-body -->
						  <div class="box-footer">
						  	<input type="hidden" name="project_id" value="<?php //echo $project['id'];?>">
						  	<button type="button" style="background-color:black;color:white" onclick="window.history.back()" class="btn btn-sm btn-round">Back</button>
                            <button type="submit" class="btn btn-sm btn-primary">Submit</button>				
                          </div>
						</form>
						<?php } ?>
					  </div>
				</div>
          <!-- /.box -->
          </div><!-- /.row -->	
        </section><!-- /.content -->
		<?php //endforeach; ?>
      </div><!-- /.content-wrapper -->
<script type="text/javascript">
	$('.js-example-basic-single').select2({
  });
</script>