<div class="modal fade" id="dealModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">ADD Deals</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
	  <form id="frm-deal" method="post" action="" class="">
      <div class="modal-body">
	  <input type="hidden" name="lead_id" value="<?=$project[0]['lead_id']?>">
	  <input type="hidden" name="lead_deal_id" value="">
	  <?php
			/*---------Create dynamic lead form------------------------*/
			$join[] = ['table' => 'deal_form_elements df', 'on' => 'df.deal_form_element_id = ccf.deal_form_element_id', 'type' => 'left'];
			$saved_data = $this->common_model->select('company_deal_form_elements ccf', ['df.status'=>1, 'ccf.user_id', $admin['id'], 'ccf.quick_add'=> 1], 'ccf.*, df.*', 'df.rank', 'ASC', $join);

			if(!empty($saved_data)){
				foreach ($saved_data as $key => $value) {
					?>
						<div class="col-md-12">
							<div class="form-group">
								<label><?=$value->form_element ?></label>
								<?php
									if($value->element_type == 'text'){
										?>
										<input type="text" class="form-control" name="<?=$value->form_element_name?>" id="<?=$value->form_element_name?>" placeholder="<?=$value->form_element?>" <?=$value->is_required==1?'required':''?>>
										<?php
									}
									else if($value->element_type == 'datepicker'){
										?>
										<input type="text" class="form-control datepicker" name="<?=$value->form_element_name?>" id="<?=$value->form_element_name?>" placeholder="<?=$value->form_element?>" <?=$value->is_required==1?'required':''?>>
										<?php
									}
									else{
										?>
											<select name="<?=$value->form_element_name?>" id="<?=$value->form_element_name?>" class="js-states form-control <?=$value->form_element_name?>" <?=$value->is_required==1?'required':''?>>
												<option value=""> --<?=$value->form_element?>-- </option>
											</select>
										<?php
									}
								?>
								
							</div>
						</div>
					<?php
				}
			}
		?>
		<div class="clearfix"></div>
      </div>
      <div class="modal-footer">
        <button type="button" class="close_stage" data-dismiss="modal"><i class="fa fa-times-circle" aria-hidden="true"></i> &nbsp; Close</button>
        <button type="submit" class="save_stage" id="btn-save-deal"><i class="fa fa-floppy-o" aria-hidden="true"></i>  &nbsp;  Save</button>
      </div>
	  </form>
    </div>
  </div>
</div>

<script>
    $(document).ready(function(){
		//get all lead lifecycle
		getDealPipeline();
		$('#deal_pipeline').on('change', function(){
			if($(this).val() == ""){
				return false;
			}
			getPipelineStage($(this).val());
		})

		/*-----------------------------------*/
		// validate signup form on keyup and submit
		$("#frm-deal").submit(function(e){
			e.preventDefault();
			$.ajax({
					url: base_url+'deals/store',
					type: 'POST',
					data: $(this).serialize(),
					beforeSend: function() {
						$("#btn-save-deal").hide();
					},
					success: function(response) {
						if(response.status.error_code == 0){
							swalAlert(response.status.message, 'success');
							//draw table with updated rows
							//table.draw();
						}else{
							swalAlert(response.status.message, 'warning');
						}
					},
					error: function(response){						
						$("#btn-add-lead").show();
						swalAlert('Something wrong, try again', 'warning');
					}           
				});
		})
    })// end on ready
    function getDealPipeline(){
        $('#deal_pipeline').append('<option value="1" selected>Default</option>');
		getPipelineStage("1");
    }
	function getPipelineStage(deals_pipeline_id){
		$.ajax({
				type: "POST",
				url: "<?php echo base_url('admin/settings/getPipelineStage')?>",
				data: {
					deals_pipeline_id:deals_pipeline_id
				},
				success: function (result) {
					$('#deal_stage').html('');
					$('#deal_stage').append(result);
				},
				error: function (response) {
				}
			});
	}
</script>