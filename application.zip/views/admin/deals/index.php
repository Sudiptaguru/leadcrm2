 <!-- Content Wrapper. Contains page content -->
 <div class="content-wrapper">
 	<!-- Content Header (Page header) -->
 	<section class="content-header">

 		<ol class="bread_crumb">
 			<li><a href="#"><img src="images/home_ico.png" alt=""></a></li>
 			<li><a href="#">Deal</a></li>
 			<li class="active">Open Deal</li>
 		</ol>

 		<ol class="breadcrumb setting_btn">
 			<ul class="add_list">
 				<!-- List view -->
				 <li class="dropdown"><a href="" class="dropdown-toggle" type="button" data-toggle="dropdown"
 						aria-haspopup="true" aria-expanded="false">List View <i class="fa fa-caret-down"></i></a>
 					<div class="dropdown-menu">
 						<a class="dropdown-item" href="#" onClick="loadView(0)">Funnel View</a>
 						<a class="dropdown-item" href="#" onClick="loadView(1)">Default View</a>
					</div>
 				</li>
 				<li class=""><a href="javascript:void(0);" class="btn btn-creat" data-toggle="modal"
 						data-target="#ImportsModal">Import Accounts <i class="fa fa-caret-down"></i></a> </li>
 				<li class="dropdown"><a href="" class="dropdown-toggle" type="button" data-toggle="dropdown"
 						aria-haspopup="true" aria-expanded="false">Edit columns <i class="fa fa-caret-down"></i></a>
 					<div class="dropdown-menu">
 						<a class="dropdown-item" href="#">Follow up</a>
 						<a class="dropdown-item" href="#">Call reminder</a>
 						<a class="dropdown-item" href="#">Appointment</a> </div>
 				</li>
 				<li class="dropdown"><a href="" class="dropdown-toggle" type="button" data-toggle="dropdown"
 						aria-haspopup="true" aria-expanded="false"><img src="./images/filter.png" alt=""></a>
 					<div class="dropdown-menu">
 						<a class="dropdown-item" href="#">Follow up</a>
 						<a class="dropdown-item" href="#">Call reminder</a>
 						<a class="dropdown-item" href="#">Appointment</a> </div>
 				</li>
 			</ul>
 		</ol>
 	</section>

 	<!-- Main content -->
 	<section class="content">
 		<!-- Small boxes (Stat box) -->
 		<div class="contactsetting_table">
 			<div class="row" id="deal-funnel-view" >
 				<div class="col-md-12">
 					<div class="opendealbox_main">
 						<?php
							foreach($details as $deal_stage){
								?>
									<div class="opendealbox">
 							<div class="opendealbox_top">
 								<div class="opendealbox_top_l">
 									<h5><?= $deal_stage->pipeline_stage?> (<?=count($deal_stage->deals)?>)</h5>
 									<h6>Forecasted revenue <b>$ 7,000</b></h6>
 								</div>
 								<div class="opendealbox_top_r">
 									<div class="dropdown viewdetails">
 										<button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenu2"
 											data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
 											<a href="">View Details</a>
 										</button>
 										<div class="dropdown-menu" aria-labelledby="dropdownMenu2">
 											<h5>Stage details</h5>
 											<p>Forecasted revenue: <span>$ 7,000</span></p>
 											<p>Total revenue: <span>$ 7,000</span></p>
 											<p>No of Deals: <span>1</span></p>
 										</div>
 									</div>

 								</div>
 								<div class="clearfix"></div>
 							</div>
 							<div class="opendealbox_inner">
							 <?php
								if($deal_stage->deals){
									foreach ($deal_stage->deals as $key => $deal) {
							 ?>
 								<div class="opendealbox_inner_box">
 								<div class="poendeal_edit"><a href="#" class="btn edit" data-toggle="modal"
						data-target="#" id="edit" data-id="<?=$deal->lead_deal_id?>"><i class="fa fa-pencil" aria-hidden="true"></i></a></div>
 									<h4>
 										<?=$deal->name?>
 										<div class="dropdown addtaskdropdown">
 											<button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenu2"
 												data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
 												<i class="fa fa-ellipsis-v" aria-hidden="true"></i>
 											</button>
 											<div class="dropdown-menu" aria-labelledby="dropdownMenu2">
 												<button class="dropdown-item btn-deal-task" type="button" data-id="<?=$deal->lead_deal_id?>"> <i class="fa fa-tasks" aria-hidden="true"></i>
 													&nbsp; Add Task</button>
 											</div>
 										</div>

 									</h4>
 									<h3><?=$deal->deal_value?> &nbsp; 
									 <!-- <i style="font-weight:normal;font-style:normal; color:#b9b9b9; font-size:10px;"> Not
 											Available 
									</i> -->
									</h3>
 									<h6><?=timeDuration($deal->created_at, date('Y-m-d H:i'))?> ago</h6>
 								</div>
							<?php
								}
							}
							?>
 							</div>
 						</div>
								<?php
							}
						 ?>
 						

 						<!-- <div class="opendealbox">
 							<div class="opendealbox_top">
 								<div class="opendealbox_top_l">
 									<h5>Follow-up (0)</h5>
 									<h6>Forecasted revenue <b>$ 0</b></h6>
 								</div>
 								<div class="opendealbox_top_r">
 									<a href=""></a>
 								</div>
 								<div class="clearfix"></div>
 							</div>
 							<div class="opendealbox_inner">
 								<div class="opendealbox_inner_box">
 									<div class="poendeal_edit"><a href=""><i class="fa fa-pencil" aria-hidden="true"></i></a></div>
 									<h4>
 										Gold Plan

 										<div class="dropdown addtaskdropdown">
 											<button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenu2"
 												data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
 												<i class="fa fa-ellipsis-v" aria-hidden="true"></i>
 											</button>
 											<div class="dropdown-menu" aria-labelledby="dropdownMenu2">
 												<button class="dropdown-item" type="button"> <i class="fa fa-tasks" aria-hidden="true"></i>
 													&nbsp; Add Task</button>
 											</div>
 										</div>

 									</h4>
 									<h3>7,000 &nbsp; <i style="font-weight:normal;font-style:normal; color:#b9b9b9; font-size:10px;"> Not
 											Available </i></h3>
 									<h6>18 hours ago</h6>
 								</div>
 							</div>
 						</div>

 						<div class="opendealbox">
 							<div class="opendealbox_top">
 								<div class="opendealbox_top_l">
 									<h5>Under review (0)</h5>
 									<h6>Forecasted revenue <b>$ 0</b></h6>
 								</div>
 								<div class="opendealbox_top_r">
 									<a href=""></a>
 								</div>
 								<div class="clearfix"></div>
 							</div>
 							<div class="opendealbox_inner">
 								<div class="opendealbox_inner_box">
 									<div class="poendeal_edit"><a href=""><i class="fa fa-pencil" aria-hidden="true"></i></a></div>
 									<h4>
 										Gold Plan

 										<div class="dropdown addtaskdropdown">
 											<button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenu2"
 												data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
 												<i class="fa fa-ellipsis-v" aria-hidden="true"></i>
 											</button>
 											<div class="dropdown-menu" aria-labelledby="dropdownMenu2">
 												<button class="dropdown-item" type="button"> <i class="fa fa-tasks" aria-hidden="true"></i>
 													&nbsp; Add Task</button>
 											</div>
 										</div>

 									</h4>
 									<h3>7,000 &nbsp; <i style="font-weight:normal;font-style:normal; color:#b9b9b9; font-size:10px;"> Not
 											Available </i></h3>
 									<h6>18 hours ago</h6>
 								</div>
 							</div>
 						</div>

 						<div class="opendealbox">
 							<div class="opendealbox_top">
 								<div class="opendealbox_top_l">
 									<h5>Demo (0)</h5>
 									<h6>Forecasted revenue <b>$ 7,000</b></h6>
 								</div>
 								<div class="opendealbox_top_r">
 									<a href=""></a>
 								</div>
 								<div class="clearfix"></div>
 							</div>
 							<div class="opendealbox_inner">
 								<div class="opendealbox_inner_box">
 									<div class="poendeal_edit"><a href=""><i class="fa fa-pencil" aria-hidden="true"></i></a></div>
 									<h4>
 										Gold Plan

 										<div class="dropdown addtaskdropdown">
 											<button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenu2"
 												data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
 												<i class="fa fa-ellipsis-v" aria-hidden="true"></i>
 											</button>
 											<div class="dropdown-menu" aria-labelledby="dropdownMenu2">
 												<button class="dropdown-item" type="button"> <i class="fa fa-tasks" aria-hidden="true"></i>
 													&nbsp; Add Task</button>
 											</div>
 										</div>

 									</h4>
 									<h3>7,000 &nbsp; <i style="font-weight:normal;font-style:normal; color:#b9b9b9; font-size:10px;"> Not
 											Available </i></h3>
 									<h6>18 hours ago</h6>
 								</div>
 							</div>
 						</div>

 						<div class="opendealbox">
 							<div class="opendealbox_top">
 								<div class="opendealbox_top_l">
 									<h5>Negotiation (0)</h5>
 									<h6>Forecasted revenue <b>$ 0</b></h6>
 								</div>
 								<div class="opendealbox_top_r">
 									<a href=""></a>
 								</div>
 								<div class="clearfix"></div>
 							</div>
 							<div class="opendealbox_inner">
 								<div class="opendealbox_inner_box">
 									<div class="poendeal_edit"><a href=""><i class="fa fa-pencil" aria-hidden="true"></i></a></div>
 									<h4>
 										Gold Plan

 										<div class="dropdown addtaskdropdown">
 											<button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenu2"
 												data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
 												<i class="fa fa-ellipsis-v" aria-hidden="true"></i>
 											</button>
 											<div class="dropdown-menu" aria-labelledby="dropdownMenu2">
 												<button class="dropdown-item" type="button"> <i class="fa fa-tasks" aria-hidden="true"></i>
 													&nbsp; Add Task</button>
 											</div>
 										</div>

 									</h4>
 									<h3>7,000 &nbsp; <i style="font-weight:normal;font-style:normal; color:#b9b9b9; font-size:10px;"> Not
 											Available </i></h3>
 									<h6>18 hours ago</h6>
 								</div>
 							</div>
 						</div> -->
 					</div>

 				</div>
 			</div>
			 <div class="row" id="deal-default-view" style="display:none">
			 <div class="col-md-12">
				<div class="table-responsive">
					<table width="100%" border="0" cellspacing="0" cellpadding="0" class="table display nowrap table-bordered table-striped" id="deal_table">
						<thead>
							<tr>
								<th><input type="checkbox"></th>
								<th>Name</th>
								<th>Deal Value</th>
								<th>Lead stage</th>
								<th>Expected close</th>
								<th>Sales owner</th>
								<th>Account Name</th>
							</tr>
						</thead>
						<tbody>
						</tbody>
					</table>
				</div>
			</div>
 			</div>
 		</div>

 	</section>
 	<!-- /.content -->
 </div>
 <!-- /.content-wrapper -->

 <!-- Modal -->
<div class="modal fade" id="ceartModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
						aria-hidden="true">&times;</span></button>
				<h4 class="modal-title" id="myModalLabel">Add Deal</h4>
			</div>
			<form id="frm-lead" method="post" action="" class="">
				<div class="modal-body">
					<div class="col-md-12">
						<div class="form-group">
							<label>Lead</label>
							<?php
								$this->db->where('status', 1);
								$lead = $this->db->get('leads')->result();
							?>
							<select id="lead_id" name="lead_id" class="js-states form-control" required>
								<?php
									foreach($lead as $value){
										echo '<option value="'.$value->lead_id.'">'.$value->name.' '.$value->lname.'</option>';
									}
								?>
							</select>
						</div>
					</div>
					<div class="col-md-12">
						<div class="form-group">
							<label>Deal Name</label>
							<input type="text" class="form-control" name="full_name" id="full_name" placeholder="Deal Name" required>
						</div>
					</div>
					<div class="col-md-12">
						<div class="form-group">
							<label>Deal Value</label>
							<input type="number" min="1" step=".01" class="form-control" name="deal_value" id="deal_value" placeholder="Amount" required>
						</div>
					</div>
					<div class="col-md-12">
						<div class="form-group">
							<label>Account Name</label>
							<input type="text" class="form-control" name="account_name" id="account_name" placeholder="Account Name" required>
						</div>
					</div>
					<div class="col-md-12">
						<div class="form-group">
							<label>Pileline</label>
							<?php
								$this->db->where('status', 1);
								$pipeline = $this->db->get('deals_pipelines')->result();
							?>
							<select id="deal_pipeline" name="deal_pipeline" class="js-states form-control" required>
								<?php
									foreach($pipeline as $value){
										echo '<option value="'.$value->deals_pipeline_id.'">'.$value->pipeline_stage.'</option>';
									}
								?>
							</select>
						</div>
					</div>
					<div class="col-md-12">
						<div class="form-group">
							<label>Deal Stage</label>
							<input type="text" class="form-control" name="deal_stage" id="deal_stage" placeholder="Deal Stage" required>
						</div>
					</div>
					<div class="col-md-12">
						<div class="form-group">
							<label>Close Date</label>
							<input type="date" class="form-control" name="closed_date" id="closed_date" placeholder="Close Date" required>
						</div>
					</div>
					<div class="col-md-12">
						<div class="form-group">
							<label>Sales Owner</label>
							<?php
								$this->db->where('status', 1);
								$salesOwner = $this->db->get('users')->result();
							?>
							<select id="sales_owner" name="sales_owner" class="js-states form-control" required>
								<?php
									foreach($salesOwner as $value){
										echo '<option value="'.$value->id.'">'.$value->name.'</option>';
									}
								?>
							</select>
						</div>
					</div>
					<div class="clearfix"></div>
				</div>
				<div class="modal-footer">
					<div class="col-md-12">
						<div class="form-group">
							<input type="text" id="lead_deal_id" name="lead_deal_id" value="">
							<!-- <input type="text" id="cloneStatus" name="cloneStatus" value=""> -->
							<!-- <button type="button" class="btn btn-creat pull-left"><i class="fa fa-pencil"></i> Customize fields</button> -->
							<button type="button" class="btn btn-creat " id="btn-close-lead" data-dismiss="modal">Close</button>
							<button type="submit" class="btn btn-save" id="btn-add-lead">Save 			
							</button>
							<button class="buttonload" style="display: none">
								<i class="fa fa-refresh fa-spin"></i> Loading
							</button>
						</div>
					</div>
				</div>			
			</form>
		</div>
	</div>
</div>
 <script>
 $(document).ready(function(){
	table = $('#deal_table').DataTable({
		"processing": true, //Feature control the processing indicator.
		"serverSide": true, //Feature control DataTables' server-side processing mode.
		"order": [], //Initial no order.

		// Load data for the table's content from an Ajax source
		"ajax": {
			"url": "<?php echo site_url('admin/deals/getDealList')?>",
			"type": "POST",
			"data": {},
		},
		//Set column definition initialisation properties.
		"columnDefs": [{
			"targets": 'no-sort',
			"orderable": false, //set not orderable
		}, ],
		rowReorder: {
			selector: 'td:nth-child(2)'
		},
		//responsive: true,
		scrollX: true,
		dom: 'Bfrtip',
		buttons: [{
				extend: 'excel',
				filename: 'deal_list',
				className: "btn btn-round_small btn-img",
				text: '<i class="fa fa-file-excel-o" aria-hidden="true"></i> Export',
				tag: 'span',
				exportOptions: {
					columns: [0, 1, 2, 3, 4, 5, 6, 7]
				}
			}
			//'excel'
		]
	});
 })

 function loadView(v){
	 if(v == 0){
		$('#deal-default-view').hide();
		$('#deal-funnel-view').show();
	 }else{
		$('#deal-funnel-view').hide();
		$('#deal-default-view').show();
	 }
 }
 </script>





<div class="modal fade" id="stage01" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">ADD TASK</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        
        <div class="form_panel_stage">
        <div class="pd-b-20">
        	<label>Title <span class="reg">*</span></label>
            <input type="text" id="task-title" placeholder="" required/>
        </div>
        <br>
        <div class="pd-b-20">
        	<label>Description <span class="reg">*</span></label>
            <textarea id="task-description" required style="width: 100%;height: 100px; border:#ccc solid 1px;"></textarea>
        </div>
        <br>
        <div class="row">
        	<div class="col-md-4 col-sm-12 col-xs-12">
        		<div class="pd-b-20">
					<label>Task type </label>
					<select name="task-type" id="task-type" required>
						<option value="">--Select a type--</option>
						<option value="follow-up">Follow Up</option>
						<option value="call-reminder">Call reminder</option>
					</select>
				</div>
        	</div>
        	<div class="col-md-4 col-sm-12 col-xs-12">
        		<div class="pd-b-20">
					<label>Due date <span class="reg">*</span></label>
					<div class="input-group date" data-provide="datepicker">
						<input type="text" class="form-control datepicker" id="task-date" required>
						<div class="input-group-addon">
							<span class="glyphicon glyphicon-th"></span>
						</div>
					</div>
				</div>
        		
        	</div>
        	<div class="col-md-4 col-sm-12 col-xs-12">
        		<div class="pd-b-20">
					<label>Time</label>
					<input type="text" id="timepicker" class="timepicker" placeholder="00:00" />
				</div>
        	</div>
        	<div class="clrearfix"></div>        	
        </div>
        
        <br>
        <div class="pd-b-20">
        	<label>Outcome <span class="reg">*</span></label>
            <select name="outcome" id="outcome" required>
				<option value="">--Select an outcome--</option>
				<option value="interrested">Interrested</option>
				<option value="left-message">Left Message</option>
				<option value="no-response">No response</option>
				<option value="no-ableto-reach">Not ableto reach</option>
			</select>
        </div>
        <br>
        <!-- <div class="pd-b-20">
        	<label><input type="checkbox"/> &nbsp; Mark as completed</label>
        </div> -->
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="close_stage" data-dismiss="modal"><i class="fa fa-times-circle" aria-hidden="true"></i> &nbsp; Close</button>
        <button type="button" class="save_stage" id="btn-save-task"><i class="fa fa-floppy-o" aria-hidden="true"></i>  &nbsp;  Save</button>
      </div>
    </div>
  </div>
</div> 

<style>
.fa.fa-pencil{
  cursor: pointer;
}
.custom-text{
    border: 1px solid #2196f3 !important;
    background: #fff !important;
}
  </style>
<script type="text/javascript" src="<?=base_url('public/admin/')?>js/theme.js"></script>
<script src="https://cdn.ckeditor.com/4.15.1/standard/ckeditor.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/timepicker/1.3.5/jquery.timepicker.min.js"></script>
<script>
	var _deal_id = '';
	//$(document).ready(function(){
		$('.btn-deal-task').on('click', function(){
			console.log('test');
			_deal_id = $(this).data('id');
			// data-toggle="modal" data-target="#stage01"
			$('#stage01').modal();
			console.log(_deal_id, 'call');
		})
	//})

	//send email for lead
	$('#btn-save-task').on('click', function(){
		let title = $('#task-title').val().trim();
		let description = $('#task-description').val().trim();
		let type = $('#task-type').val().trim();
		//let body = CKEDITOR.instances.mail-body.getData();
		let date = $('#task-date').val().trim();
		let time = $('#timepicker').val().trim();
		let outcome = $('#outcome').val().trim();

		if(title == ""){
			swalAlert('Title is required');
			return false;
		}
		if(description == ""){
			swalAlert('Description is required');
			return false;
		}
		if(type == ""){
			swalAlert('Type is required');
			return false;
		}
		if(date == ""){
			swalAlert('Date is required');
			return false;
		}
		if(outcome == ""){
			swalAlert('Outcome is required');
			return false;
		}
		let t = $(this);
		$.ajax({
				type: "POST",
				url: base_url+'Deals/saveTask',
				data: {
					deal_id: _deal_id,
					title: title,
					description: description,
					type: type,
					date: date,
					time: time,
					outcome: outcome,
					user_id: "<?=$admin['id']?>"
						},
				success: function(response) {
					console.log(response);
					if(response.status.error_code == 0){
						// if(deal_task_id !=""){
						// 	t.parent('h3').html(title);
						// }else{
						// 	$('#sec-deal-task')
						// 	.append('<div class="taskbox"><div class="tak_top"><h3>'+title+'<span> <a href=""><i class="fa fa-pencil" aria-hidden="true"></i></a> <a href=""><i class="fa fa-trash-o" aria-hidden="true"></i></a></span></h3></div><div class="tak_mid"> <b><svg width="14" height="14" viewBox="0 0 14 14" xmlns="http://www.w3.org/2000/svg" class="svg-sm"><g fill-rule="nonzero" fill="none"><path fill-opacity=".01" fill="#FFF" d="M0 0h14v14H0z"></path><g transform="translate(1 1)" stroke="#2C5CC5"><rect x=".068" y="9.5" width="12" height="3" rx="1"></rect><path d="M1.044 9.451h10.054a.1.1 0 0 0 .098-.08l.874-4.433a.1.1 0 0 0-.128-.114l-3.48 1.09a.1.1 0 0 1-.114-.04L6.154 2.56a.1.1 0 0 0-.166 0L3.789 5.874a.1.1 0 0 1-.113.04L.194 4.825a.1.1 0 0 0-.128.115l.88 4.431a.1.1 0 0 0 .098.081z"></path><circle stroke-width="1.2" cx="6.068" cy=".5" r="1"></circle></g></g></svg> &nbsp; '+"<?=$admin['name']?>"+'</b> <i>Due date: Now</i></div><div class="clearfix"></div></div>');
						// }
						swalAlert(response.status.message);
						
					}else{
						swalAlert(response.status.message);
					}
				}
			})
	})
	
</script>

<script>
$('.datepicker').datepicker({
    format: 'mm/dd/yyyy',
    startDate: '-3d'
});

$('.timepicker').timepicker({
    // timeFormat: 'h:mm p',
    // interval: 60,
    // minTime: '10',
    // maxTime: '6:00pm',
    // defaultTime: '11',
    // startTime: '10:00',
    // dynamic: false,
    // dropdown: true,
    // scrollbar: true
});
</script>

