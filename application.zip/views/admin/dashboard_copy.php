
<!-- Content Wrapper. Contains page content -->
<?php $admin=$this->session->userdata('admin'); ?>
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Dashboard Panel
        <!--<small>Version 2.0</small>-->
      </h1>
     <!-- <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>-->
    </section>

    <!-- Main content -->
    <section class="content" id="top">
        <div class="row">
          <div class="col-md-2 col-sm-6 col-xs-12">
             <a href="<?php echo base_url();?>admin/leads">
              <div class="info-box">
                <!-- <span class="info-box-icon bg-aqua"><i class="fa fa-file-text-o"></i></span> -->
                <div class="">
                  <h2><?php echo $leads;?> <span> <i class="fa fa-caret-up" aria-hidden="true" style="color:green;font-size:20px"></i> <?php echo $leads_pct.'%'; ?>   </span> </h2>
                  <h3 class="info-box-text">Leads (30 days)</h3>
                            
                </div>                
                <!-- /.info-box-content -->
              </div>
              <!-- /.info-box -->
               </a>
            </div>
       
        
          <div class="col-md-2 col-sm-6 col-xs-12">
             <a href="<?php echo base_url();?>admin/leads">
              <div class="info-box">
                <!-- <span class="info-box-icon bg-aqua"><i class="fa fa-file-text-o"></i></span> -->
                <div class="">
                  <h2><?php echo $MQL;?> <span><i class="fa fa-caret-up" aria-hidden="true" style="color:green;font-size:20px"></i> <?php echo $MQL_pct.'%'; ?></span></h2>
                  <h3 class="info-box-text">MQL (30 days)</h3> 
                                  
                </div>
                <!-- /.info-box-content -->
              </div>
              <!-- /.info-box -->
              </a>
            </div>
        
        
          <div class="col-md-2 col-sm-6 col-xs-12">
             <a href="<?php echo base_url();?>admin/leads">
              <div class="info-box">
                <!-- <span class="info-box-icon bg-aqua"><i class="fa fa-file-text-o"></i></span> -->
                <div class="">
                  <h2><?php echo $SAL;?> <span><i class="fa fa-caret-up" aria-hidden="true" style="color:green;font-size:20px"></i> <?php echo $SAL_pct.'%'; ?> </span></h2>
                  <h3 class="info-box-text">SAL (30 days)</h3>
                                 
                </div>
                
                <!-- /.info-box-content -->
              </div>
              <!-- /.info-box -->
              </a>
            </div>
        
       
          <div class="col-md-2 col-sm-6 col-xs-12">
              <a href="<?php echo base_url();?>admin/leads">
              <div class="info-box">
                <!-- <span class="info-box-icon bg-aqua"><i class="fa fa-file-text-o"></i></span> -->
                <div class="">
                  <h2><?php echo $conversion;?> <span> <i class="fa fa-caret-up" aria-hidden="true" style="color:green;font-size:20px"></i> <?php echo $conversion_pct.'%'; ?></span></h2>
                  <h3 class="info-box-text">Conversion (30 days)</h3>
                                 
                </div>
                <!-- /.info-box-content -->
              </div>
              <!-- /.info-box -->
              </a>
            </div>
        
        
          <div class="col-md-4 col-sm-6 col-xs-12">
             <a href="<?php echo base_url();?>admin/leads">
              <div class="info-box">
                <!-- <span class="info-box-icon bg-aqua"><i class="fa fa-file-text-o"></i></span> -->

                <div class="">
                  <h2>$ <?php echo $ARR_amt;?></h2>
                  <h3 class="info-box-text">Total New ARR</h3>
                  
                </div>
                <!-- /.info-box-content -->
              </div>
              <!-- /.info-box -->
               </a>
            </div>
       </div>
    
        
         	<div class="grid-box" style="min-height: auto;">
          <form action="<?php echo base_url();?>admin/dashboard/filter" method="post" >
           <div class="row">
            <div class="col-md-2">
              <label>From Date</label>              
              <input type="text" class="form-control datepicker" id="frm_dt" name="frm_dt" value="<?php echo date('d-m-Y', strtotime('-30 days'));?>" placeholder="DD-MM-YYYY">
            </div>
            <div class="col-md-2">
              <label>To Date</label>
              <input type="text" class="form-control datepicker" id="to_dt" name="to_dt" value="<?php echo date('d-m-Y');?>" placeholder="DD-MM-YYYY">
            </div>
            <div class="col-md-3">
              <label>Lead Source</label>
              <select class="form-control" name="lead_source" id="lead_source"> 
                  <option value="">All Source</option>
                  <option value="ppc" <?php if(!empty($lead_source) && $lead_source == 'ppc'){echo 'selected';} ?>>PPC</option>
                  <option value="fb"  <?php if(!empty($lead_source) && $lead_source == 'fb'){echo 'selected';} ?>>FB</option>
              </select>
            </div>
            <div class="col-md-3">
              <label>Lead Status</label>
              <select class="form-control" name="lead_status" id="lead_status">  
                  <option value="">All Status</option>
                  <option value="open" <?php if(!empty($lead_status) && $lead_status == 'open'){echo 'selected';} ?>>Open</option>
                  
                  <option value="awarded" <?php if(!empty($lead_status) && $lead_status == 'awarded'){echo 'selected';} ?>>Awarded</option>
                  <option value="innegotiation" <?php if(!empty($lead_status) && $lead_status == 'innegotiation'){echo 'selected';} ?>>In-negotiation</option>
                  <option value="lost" <?php if(!empty($lead_status) && $lead_status == 'lost'){echo 'selected';} ?>>Lost</option>
              </select>
            </div>
            <div class="col-md-2" style="margin-top:25px">
              <button class="btn btn-success" type="submit" style="width:30%;">Go</button>
              <a class="btn" id="clear_btn" style="background-color:black;color:white" >Clear</a>
            </div>
            </div>
          </form>
            
        </div>
        <div class="row">
       		<div class="col-md-5">	
         		<div class="grid-box">
         			<div id="canvas-holder" >
            			<canvas id="chart-area"></canvas>
          			</div>
         		</div>
        	</div>
        	<div class="col-md-7">	
         		<div class="grid-box">
         			<div id="canvas-holder">
            			<canvas id="bar_canvas"></canvas>
          			</div>
         		</div>
        	</div>
         </div>
         <div class="row">
       		<div class="col-md-7">	
         		<div class="grid-box">
         			<div id="chartContainer"></div>
         		</div>
        	</div>
        	<div class="col-md-5">	
         		<div class="grid-box">
         			<div id="canvas-holder">
            			<canvas id="line_canvas"></canvas>
          			</div>
         		</div>
        	</div>
         </div>
          
        
    </section>
    <!-- /.content -->	
  </div>
 <div>   
 </div>
 <div>
   <input

 </div>
  <!-- /.content-wrapper -->
<?php
 
$dataPoints = array( 
  array("label"=>"MQL", "y"=>$MQL_cnt),
  array("label"=>"SQL", "y"=>$SQL),
  array("label"=>"SAL", "y"=>$SAL_funnel_cnt),
)
 
?>
<link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<!-- <link rel="stylesheet" href="https://code.jquery.com/resources/demos/style.css"> -->
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<link rel="stylesheet" href="<?php echo base_url();?>public/chart/Chart.css">
<script src="<?php echo base_url();?>public/Chart_js_master/samples/utils.js"></script>  
<script type="text/javascript" src="<?php echo base_url();?>public/chart/Chart.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>public/chart/Chart.min.js"></script>
<script src="<?php echo base_url();?>public/Chart_js_master/samples/charts/area/analyser.js"></script>
<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
<script type="text/javascript">
$( function() {
  $( ".datepicker" ).datepicker({ dateFormat: 'dd-mm-yy' });
} );
  window.onload = function() {
      
      var config = {
        type: 'pie',
        data: {
          datasets: [{
            data: [
              <?php echo $open;?>,
              <?php echo $close;?>,
              <?php echo $innegotiation;?>,
              <?php echo $lost;?>,
            ],
            backgroundColor: [
              window.chartColors.red,
              window.chartColors.orange,
              window.chartColors.yellow,
              window.chartColors.green,
            ],
            label: 'Dataset 1'
          }],
          labels: [
            '<?php echo $open;?> - Open',
            '<?php echo $close?> - Awarded',
            '<?php echo $innegotiation;?> - Innegotiation',
            '<?php echo $lost;?> - Lost'
          ]
        },
        options: {
          responsive: true,
          title: {
            display: true,
            text: 'Leads status'
          }
        }
      };
      var config2 = {
        type: 'line',
        data: {
          labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'Aug', 'Sep', 'Oct', 'Nov','Dec'],
          datasets: [{
            label: 'Leads',
            fill: false,
            backgroundColor: window.chartColors.blue,
            borderColor: window.chartColors.blue,
          //   data: [
          //     7,
          //     13,
          //     23,
          //     23.4,
          //     27.9,
          //     12.76,
          //     37.34,
          //     46.23
          //   ],
            data: [
                <?php echo $leads_data_cnt; ?>
              ],
           }]  
        }, 
        options: {
          responsive: true,
          title: {
            display: true,
            text: 'Leads Trend'
          },
          tooltips: {
            mode: 'index',
            intersect: false,
          },
          hover: {
            mode: 'nearest',
            intersect: true
          },
          scales: {
            x: {
              display: true,
              scaleLabel: {
                display: true,
                labelString: 'Month'
              }
            },
            y: {
              display: true,
              scaleLabel: {
                display: true,
                labelString: 'Value'
              }
            }
          }
        }
      };
      //var MONTHS = ['Open', 'Close', 'Innegotiation', 'Lost'];
      var color = Chart.helpers.color;
      var horizontalBarChartData = {
        labels: ['Open', 'Awarded', 'Innegotiation', 'Lost'],
        datasets: [{
          label: 'PPC',
          backgroundColor: color(window.chartColors.red).alpha(0.5).rgbString(),
          borderColor: window.chartColors.red,
          borderWidth: 1,
          data: [
            <?php echo $open_ppc;?>,
            <?php echo $close_ppc;?>,
            <?php echo $innegotiation_ppc;?>,
            <?php echo $lost_ppc ;?>
          ]
        }, {
          label: 'FB',
          backgroundColor: color(window.chartColors.blue).alpha(0.5).rgbString(),
          borderColor: window.chartColors.blue,
          data: [
            <?php echo $open_fb; ?>,
            <?php echo $close_fb;?>,
            <?php echo $innegotiation_fb;?>,
            <?php echo $lost_fb;?>
          ]
        }]

      };
      var ctx = document.getElementById('chart-area').getContext('2d');
      window.myPie = new Chart(ctx,config);
      var ctxh = document.getElementById('bar_canvas').getContext('2d');
      window.myHorizontalBar = new Chart(ctxh, {
        type: 'horizontalBar',
        data: horizontalBarChartData,
        options: {
          // Elements options apply to all of the options unless overridden in a dataset
          // In this case, we are setting the border of each horizontal bar to be 2px wide
          elements: {
            rectangle: {
              borderWidth: 2,
            }
          },
          responsive: true,
          legend: {
            position: 'right',
          },
          title: {
            display: true,
            text: 'Leads source by status'
          }
        }
      });
      var ctxl = document.getElementById('line_canvas').getContext('2d');
      window.myLine = new Chart(ctxl, config2);
      var chart = new CanvasJS.Chart("chartContainer", {
        theme: "",
        animationEnabled: true,
        title: {
          text: "Sales Funnel"
        },
        data: [{
          type: "funnel",
          indexLabel: "{label} - {y}",
          yValueFormatString: "#,##0",
          showInLegend: true,
          legendText: "{label}",
          dataPoints: <?php echo json_encode($dataPoints, JSON_NUMERIC_CHECK); ?>
        }]
      });
      chart.render();
  }
 $(document).on('click','#clear_btn',function(){
  //alert("dhjgdhkj");
    window.location.href= base_url + "dashboard";
 })
</script> 