<div class="content-wrapper">
	<section class="content-header">

		<ol class="bread_crumb">
			<li><a href="#"><img src="images/home_ico.png" alt=""></a></li>
			<!--<li><a href="#">Accounts</a></li>-->
			<li class="active">Admin Settings</li>

		</ol>

		<ol class="breadcrumb setting_btn">
			<ul class="add_list">

				<li class=""><a href="javascript:void(0);" class="btn btn-creat" data-toggle="modal"
						data-target="#ImportsModal">Import Accounts <i class="fa fa-caret-down"></i></a>

				</li>
				<li class="dropdown"><a href="" class="dropdown-toggle" type="button" data-toggle="dropdown"
						aria-haspopup="true" aria-expanded="false">Edit columns <i class="fa fa-caret-down"></i></a>
					<div class="dropdown-menu">
						<a class="dropdown-item" href="#">Follow up</a>
						<a class="dropdown-item" href="#">Call reminder</a>
						<a class="dropdown-item" href="#">Appointment</a>
					</div>
				</li>
				<li class="dropdown"><a href="" class="dropdown-toggle" type="button" data-toggle="dropdown"
						aria-haspopup="true" aria-expanded="false"><img src="./images/filter.png" alt=""></a>
					<div class="dropdown-menu">
						<a class="dropdown-item" href="#">Follow up</a>
						<a class="dropdown-item" href="#">Call reminder</a>
						<a class="dropdown-item" href="#">Appointment</a>
					</div>
				</li>
			</ul>
		</ol>
	</section>
	<!-- Main content -->
	<section class="content">
		<!-- Small boxes (Stat box) -->
		<div class="wrapper_box graph_sec">
			<div class="adminsetting_box_panel">
				<h3>Sales Force Automation (SFA)</h3>
				<span>All your sales-specific settings related to contacts, accounts, pipelines, sales activities and
					more</span>
				<h5>Modules and Fields</h5>
				<div class="clearfix"></div>
				<div class="row">
					<div class="col-md-4 col-sm-12 col-xs-12">
						<div class="adminsetting_box_panel_box">
							<a href="<?=base_url('admin/settings/contacts/form')?>">
								<div class="adminsetting_box_panel_box_icon">
									<svg width="32" height="32" viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg"
										class="svg-modules valign-middle">
										<g fill="none" fill-rule="evenodd">
											<path fill-opacity=".2" fill="#FFF" opacity=".01" d="M0 0h32v32H0z"></path>
											<g transform="translate(.5 .5)" stroke="#12344D" stroke-linecap="round"
												stroke-linejoin="round">
												<circle fill="#FFF" cx="15.5" cy="15.5" r="15.5"></circle>
												<path
													d="M24.8 27.63V24.8a4.65 4.65 0 0 0-4.65-4.65h-9.3A4.65 4.65 0 0 0 6.2 24.8v2.83">
												</path>
												<circle fill="#BBDCFE" cx="15.5" cy="10.85" r="4.65"></circle>
											</g>
										</g>
									</svg>
								</div>
								<div class="adminsetting_box_panel_box_text">
									<b>Contacts (Contacts)</b>
									<p>Manage all the fields you need for adding and updating contacts</p>
								</div>
							</a>
						</div>
					</div>

					<div class="col-md-4 col-sm-12 col-xs-12">
						<div class="adminsetting_box_panel_box">
							<a href="<?=base_url('admin/settings/accounts/form')?>">
								<div class="adminsetting_box_panel_box_icon">
									<svg width="32" height="32" viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg"
										class="svg-modules valign-middle">
										<g fill="none" fill-rule="evenodd">
											<path fill-opacity=".2" fill="#FFF" opacity=".01" d="M0 0h32v32H0z"></path>
											<g stroke="#12344D" stroke-linecap="round" stroke-linejoin="round">
												<path fill="#FFF" d="M.5.5H16v31H.5z"></path>
												<path
													d="M5.827 21.167h4.71c.11 0 .2.09.2.2V31.5h-5.11V21.367c0-.11.09-.2.2-.2z"
													fill="#BBDCFE"></path>
												<path fill="#FFF" d="M16 10.833h15.5V31.5H16z"></path>
												<path
													d="M4.929 14.524h6.642M20.429 24.857h6.642M4.929 7.881h6.642M20.429 18.214h6.642">
												</path>
											</g>
										</g>
									</svg>
								</div>
								<div class="adminsetting_box_panel_box_text">
									<b>Accounts (Accounts)</b>
									<p>Manage all the fields you need for adding and updating accounts</p>
								</div>
							</a>
						</div>
					</div>

					<div class="col-md-4 col-sm-12 col-xs-12">
						<div class="adminsetting_box_panel_box">
							<a href="<?=base_url('admin/settings/deals/form')?>">
								<div class="adminsetting_box_panel_box_icon">
									<svg width="32" height="32" viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg"
										class="svg-modules valign-middle">
										<g fill="none" fill-rule="evenodd">
											<path fill-opacity=".2" fill="#FFF" opacity=".01" d="M0 0h32v32H0z"></path>
											<g transform="translate(.5 .5)" stroke="#12344D" stroke-linecap="round"
												stroke-linejoin="round">
												<circle fill="#BBDCFE" cx="15.5" cy="15.5" r="15.5"></circle>
												<circle fill="#FFF" cx="15.5" cy="15.5" r="11.5"></circle>
												<path
													d="M19.499 10.24h-6.535a2.464 2.464 0 0 0 0 4.93h4.923a2.47 2.47 0 1 1 0 4.94h-6.528M15.429 8v14.347">
												</path>
											</g>
										</g>
									</svg>
								</div>
								<div class="adminsetting_box_panel_box_text">
									<b>Deals (Deals)</b>
									<p>Manage all the fields you need for adding and updating deals</p>
								</div>
							</a>
						</div>
					</div>

					<div class="col-md-4 col-sm-12 col-xs-12">
						<div class="adminsetting_box_panel_box">
							<a href="">
								<div class="adminsetting_box_panel_box_icon">
									<svg width="32" height="32" viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg"
										class="svg-modules valign-middle">
										<g fill="none" fill-rule="evenodd">
											<path fill-opacity=".2" fill="#FFF" opacity=".01" d="M0 0h32v32H0z"></path>
											<g transform="translate(3 2)" stroke="#12344D" stroke-linecap="round"
												stroke-linejoin="round">
												<rect fill="#FFF" y="1.55" width="20.667" height="23.25" rx="1.6">
												</rect>
												<path fill="#BBDCFE" d="M5.235 0h10.174v3.1H5.235z"></path>
												<path d="M4.493 7.763h11.965M4.493 12.763h7.965M4.493 17.763h5.965">
												</path>
												<path fill="#BBDCFE"
													d="M20.7 25.75l-4.408 2.318.842-4.91-3.567-3.476 4.929-.716L20.7 14.5l2.204 4.466 4.929.716-3.567 3.477.842 4.909z">
												</path>
											</g>
										</g>
									</svg>
								</div>
								<div class="adminsetting_box_panel_box_text">
									<b>Sales Activities</b>
									<p>Create sales activities that are relevant to your business</p>
								</div>
							</a>
						</div>
					</div>

					<div class="col-md-4 col-sm-12 col-xs-12">
						<div class="adminsetting_box_panel_box">
							<a href="<?=base_url('admin/settings/contacts/lifecycle')?>">
								<div class="adminsetting_box_panel_box_icon">
									<svg width="32" height="32" viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg"
										class="svg-modules valign-middle">
										<g fill="none" fill-rule="nonzero">
											<path fill-opacity=".2" fill="#FFF" opacity=".01" d="M0 0h32v32H0z"></path>
											<g transform="translate(.5 .5)" stroke="#12344D">
												<circle fill="#FFF" cx="15.5" cy="15.5" r="15.5"></circle>
												<path fill="#BBDCFE" stroke-linecap="round" stroke-linejoin="round"
													d="M18.783 22.204H7.143l5.074-6.566L7.143 9.07h11.64l5.074 6.567z">
												</path>
											</g>
										</g>
									</svg>
								</div>
								<div class="adminsetting_box_panel_box_text">
									<b>Contact Lifecycle Stages</b>
									<p>Create stages and statuses to capture the lifecycle of your contacts</p>
								</div>
							</a>
						</div>
					</div>
				</div>
				<h5>Modules and Fields</h5>
                <div class="row">
                   <div class="col-md-4 col-sm-12 col-xs-12">
                        <div class="adminsetting_box_panel_box">
                        	<a href="<?=base_url('admin/settings/deals/pipeline')?>">
                        	<div class="adminsetting_box_panel_box_icon">
                            <svg width="32" height="32" viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg" class="svg-modules valign-middle"><g fill="none" fill-rule="evenodd"><path fill-opacity=".2" fill="#FFF" opacity=".01" d="M0 0h32v32H0z"></path><path fill-opacity=".2" fill="#FFF" opacity=".01" d="M0 0h32v32H0z"></path><g stroke="#12344D" stroke-linecap="round" stroke-linejoin="round"><path fill="#FFF" d="M3 11h11.5v19H3z"></path><path fill="#BBDCFE" d="M28.2 8H18l1.846-2.67L18 3h10.2L30 5.5zM13.2 8H3l1.846-2.67L3 3h10.2L15 5.5z"></path><path fill="#FFF" d="M18 11h11.5v19H18z"></path></g></g></svg>
                            </div>
                            <div class="adminsetting_box_panel_box_text">
                            <b>Deal Pipelines</b>
                            <p>Create up to 10 pipelines to suit your sales process</p>
                            </div>
                            </a>
                        </div>
                    </div>
               </div>
			</div>
		</div>
	</section>
	<!-- /.content -->
</div>
