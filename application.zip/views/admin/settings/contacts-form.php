  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
  	<!-- Content Header (Page header) -->
  	<section class="content-header">

  		<ol class="bread_crumb">
  			<li><a href="<?=base_url('admin/settings')?>"><img src="images/home_ico.png" alt=""></a></li>
  			<!--<li><a href="#">Accounts</a></li>-->
  			<li class="active"><a href="<?=base_url('admin/settings')?>">Admin Settings</a></li>

  		</ol>

  		<ol class="breadcrumb setting_btn">
  			<ul class="add_list">

  				<li class=""><a href="javascript:void(0);" class="btn btn-creat" data-toggle="modal"
  						data-target="#ImportsModal">Import Accounts <i class="fa fa-caret-down"></i></a> </li>
  				<li class="dropdown"><a href="" class="dropdown-toggle" type="button" data-toggle="dropdown"
  						aria-haspopup="true" aria-expanded="false">Edit columns <i class="fa fa-caret-down"></i></a>
  					<div class="dropdown-menu">
  						<a class="dropdown-item" href="#">Follow up</a>
  						<a class="dropdown-item" href="#">Call reminder</a>
  						<a class="dropdown-item" href="#">Appointment</a> </div>
  				</li>
  				<li class="dropdown"><a href="" class="dropdown-toggle" type="button" data-toggle="dropdown"
  						aria-haspopup="true" aria-expanded="false"><img src="./images/filter.png" alt=""></a>
  					<div class="dropdown-menu">
  						<a class="dropdown-item" href="#">Follow up</a>
  						<a class="dropdown-item" href="#">Call reminder</a>
  						<a class="dropdown-item" href="#">Appointment</a> </div>
  				</li>
  			</ul>
  		</ol>
  	</section>

  	<!-- Main content -->
  	<section class="content">
  		<!-- Small boxes (Stat box) -->
  		<div class="wrapper_box">
  			<div class="adminsetting_box_panel">
  				<div class="row">
  					<div class="col-md-9 col-sm-12 col-xs-12">
  						<div class="contact_box_panel_l">
  							<h3><i><svg width="32" height="32" viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg"
  										class="svg-modules">
  										<g fill="none" fill-rule="evenodd">
  											<path fill-opacity=".2" fill="#FFF" opacity=".01" d="M0 0h32v32H0z">
  											</path>
  											<g transform="translate(.5 .5)" stroke="#12344D" stroke-linecap="round"
  												stroke-linejoin="round">
  												<circle fill="#FFF" cx="15.5" cy="15.5" r="15.5"></circle>
  												<path
  													d="M24.8 27.63V24.8a4.65 4.65 0 0 0-4.65-4.65h-9.3A4.65 4.65 0 0 0 6.2 24.8v2.83">
  												</path>
  												<circle fill="#BBDCFE" cx="15.5" cy="10.85" r="4.65"></circle>
  											</g>
  										</g>
  									</svg></i>Contacts</h3>
  							<p>Add contacts faster with just the fields you need. Use default fields or add custom
  								fields, and organize them into groups.</p>
  							<a href=""><i><svg width="14" height="14" viewBox="0 0 14 14"
  										xmlns="http://www.w3.org/2000/svg" class="mg-t-2 valign-middle">
  										<g fill="none" fill-rule="evenodd">
  											<path fill-opacity=".2" fill="#FFF" opacity=".01" d="M0 0h14v14H0z">
  											</path>
  											<path
  												d="M3.08 3.625v6.229h2.708M5.653 3.49H.5h5.153zm.135 7.718h7.583V8.229H5.788v2.979zm0-6.229h7.583V2H5.788v2.979z"
  												stroke="#000" stroke-linecap="round" stroke-linejoin="round"></path>
  										</g>
  									</svg></i> Define field dependencies</a>
  							<div><a class="learnmore" href="">
  									<i><svg width="14" height="14" viewBox="0 0 14 14"
  											xmlns="http://www.w3.org/2000/svg" class="svg-md mg-l-10 valign-middle">
  											<g fill="none" fill-rule="evenodd">
  												<path fill-opacity=".2" fill="#FFF" opacity=".01" d="M0 0h14v14H0z">
  												</path>
  												<g>
  													<path fill-opacity=".01" fill="#FFF" opacity=".01"
  														d="M0 0h14v14H0z"></path>
  													<path
  														d="M6.556 10.578c0-.227.186-.411.416-.411.23 0 .417.184.417.41v.012a.414.414 0 0 1-.417.411.414.414 0 0 1-.416-.411v-.011z"
  														fill="#2C5CC5" fill-rule="nonzero"></path>
  													<path
  														d="M4.7 5.87c0-1.203 1.04-2.225 2.323-2.225s2.324.954 2.324 2.157c0 1.204-1.12 2.019-2.403 2.019v1.37"
  														stroke="#2C5CC5" stroke-linecap="round"
  														stroke-linejoin="round"></path>
  													<circle stroke="#2C5CC5" cx="7" cy="7" r="6.5"></circle>
  												</g>
  											</g>
  										</svg></i> Learn more
  								</a></div>

  						</div>
  					</div>
  					<!-- <div class="col-md-3 col-sm-12 col-xs-12">
  						<div class="contact_box_panel_r">
  							<a class="renamemodule" href="">
  								<i><svg class="svg-sm valign-middle custom-button-svg" width="14" height="14"
  										viewBox="0 0 14 14" xmlns="http://www.w3.org/2000/svg">
  										<g fill="none" fill-rule="evenodd">
  											<path fill-opacity=".01" fill="#FFF" opacity=".01" d="M0 0h14v14H0z">
  											</path>
  											<g stroke="#000" stroke-linejoin="round">
  												<path d="M4.377 12.209L.5 13.349l1.14-3.877L8.482 2.63l2.737 2.737z">
  												</path>
  												<path
  													d="M8.482 2.63L10.346.766a.915.915 0 0 1 1.29 0l1.447 1.447a.915.915 0 0 1 0 1.29l-1.864 1.864"
  													stroke-linecap="round"></path>
  											</g>
  										</g>
  									</svg> </i>
  								Rename module
  							</a>

  							<a class="renamemodule" href="">
  								<i class="fa fa-eye" aria-hidden="true"></i>
  								Preview
  							</a>
  						</div>
  					</div> -->
  				</div>
  			</div>
  		</div>
  		<div class="adminsetting_box_panel">
  			<h4><i><svg width="30" height="30" viewBox="0 0 30 30" xmlns="http://www.w3.org/2000/svg" class="mg-r-5">
  						<g fill="none" fill-rule="evenodd">
  							<path fill="#FFF" opacity=".01" d="M0 0h30v30H0z"></path>
  							<path
  								d="M12.91 8L11 5H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h18.444a2 2 0 0 0 2-2V10a2 2 0 0 0-2-2H12.91z"
  								fill="#ffe278" stroke="#f3c83c" stroke-linecap="round" stroke-linejoin="round"></path>
  						</g>
  					</svg></i>Basic information</h4>
  		</div>
        <form name="contact-settings" id="contact-settings">
        <?php
        foreach ($element_list as $key => $value) {
            $saved_data = $this->common_model->select('company_contact_form_elements', ['user_id', $admin['id'], 'contact_form_element_id'=> $value->contact_form_element_id], '*', 'contact_form_element_id', 'ASC');
            $is_required = '';
            $quick_add = 'checked';
            $is_readonly = '';
            if(!empty($saved_data)){
                $d = $saved_data[0];
                if($d->is_required == 1){
                    $is_required = 'checked';
                }
                if($d->quick_add == 1){
                    $quick_add = 'checked';
                }else{
                    $quick_add = '';
                }
            }
            $id = $value->contact_form_element_id;
            $required_array = [1, 2, 4, 5, 8, 11];
            if(in_array($id, $required_array)){
                $is_required = 'checked';
                $quick_add = 'checked';
                $is_readonly = 'disabled';
            }
            if($value->element_type == 'text'){
                $icon = '<svg width="30" height="30" viewBox="0 0 30 30" xmlns="http://www.w3.org/2000/svg"
                class="icon-form-text">
                <g fill="none" fill-rule="evenodd">
                    <path fill="#FFF" opacity=".01" d="M0 0h30v30H0z"></path>
                    <path fill="#000"
                        d="M15.361 5.707h-3.507v12.306l2.142.525V19H7.759v-.462l2.142-.525V5.707H6.394L5.386 8.563H4.84V4.93h12.075v3.633h-.546z">
                    </path>
                    <g stroke="#000" stroke-linecap="square">
                        <path
                            d="M19 11l3.332 1.5L25.65 11M19 25.5l3.332-1.5 3.319 1.5M22.325 12.5V24M19.325 20.5h6">
                        </path>
                    </g>
                </g>
            </svg>';
            }else{
                $icon = '<svg width="30" height="30" viewBox="0 0 30 30" xmlns="http://www.w3.org/2000/svg" class="icon-form-dropdown"><g fill="none" fill-rule="evenodd"><path fill="#FFF" opacity=".01" d="M0 0h30v30H0z"></path><path d="M18 9h9a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1h-9V9z" fill="#000" stroke="#000"></path><path fill="#FFF" d="M23.106 17.227L20 13.5h6.212z"></path><path d="M3 9h15v12H3a1 1 0 0 1-1-1V10a1 1 0 0 1 1-1z" stroke="#000"></path></g></svg>';
            }
            ?>
                <div class="contactsetting_table">
                    <div class="row">
                        <div class="col-md-1">
                            <div class="adminsetting_box_panelcheckbox"><i class="fa fa-bars" aria-hidden="true"></i></div>
                        </div>
                        <div class="col-md-2">
                            <div class="adminsetting_box_panel">
                                <i><?=$icon?></i>
                                <?=$value->form_element?>
                                <input type="hidden" name="form_element[]" value="<?=$value->contact_form_element_id?>">
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="adminsetting_box_panelcheckbox">
                                <input type="checkbox" name="is_required[]" value="<?=$value->contact_form_element_id?>" <?=$is_required?> <?=$is_readonly?>/> Required
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="adminsetting_box_panelcheckbox">
                                <input type="checkbox" name="quick_add[]" value="<?=$value->contact_form_element_id?>" <?=$quick_add?> <?=$is_readonly?>/> Quick-add
                            </div>
                        </div>
                        <!-- <div class="col-md-2">
                            <div class="adminsetting_box_panelcheckbox">
                                <input type="checkbox" /> Read only
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="adminsetting_box_panelcheckbox">
                                <input type="checkbox" /> Unique
                            </div>
                        </div> -->
                    </div>
                </div>
            <?php
        }
        ?>
        <div class="row">
            <div class="col-md-12 text-center">
                <button type="submit" class="btn=btn-primary">Save</button>
            </div>
        </form>
  	</section>
  	<!-- /.content -->
  </div>

  <!-- Script> -->
<script>
    $(document).ready(function(){
        $('#contact-settings').submit(function(e){
            e.preventDefault();
            var formData = new FormData(this);
            console.log(formData);
            $.ajax({
                type: "POST",
                url: "<?=base_url('admin/settings/saveContactForm')?>",   //contact === lead
                // data: JSON.stringify(Object.assign({}, dataJson)),
                data: formData,
                cache: false,
                contentType: false,
                processData: false,
                beforeSend: function() {
                    
                },
                success: function(res) {
                    if(res == "Success"){
                        swalAlert('Form elements saved successfully');
                    }else{
                        swalAlert('Unable to saved form elements');
                    }
                },
            });
        })
    })
</script>
