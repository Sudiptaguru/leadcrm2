<div class="content-wrapper">
	<!-- Content Header (Page header) -->
	<section class="content-header">

		<ol class="bread_crumb">
			<li><a href="javascript:void(0)"><img src="images/home_ico.png" alt=""></a></li>
			<li><a href="<?=base_url('admin/settings')?>">Admin Settings</a></li>
			<li class="active">Deal Pipeline</li>
		</ol>
		<ol class="breadcrumb setting_btn">
			<ul class="add_list">
				<li class=""><a href="javascript:void(0);" class="btn btn-creat" data-toggle="modal"
						data-target="#ImportsModal">Import Accounts <i class="fa fa-caret-down"></i></a> </li>
				<li class="dropdown"><a href="" class="dropdown-toggle" type="button" data-toggle="dropdown"
						aria-haspopup="true" aria-expanded="false">Edit columns <i class="fa fa-caret-down"></i></a>
					<div class="dropdown-menu">
						<a class="dropdown-item" href="#">Follow up</a>
						<a class="dropdown-item" href="#">Call reminder</a>
						<a class="dropdown-item" href="#">Appointment</a> </div>
				</li>
				<li class="dropdown"><a href="" class="dropdown-toggle" type="button" data-toggle="dropdown"
						aria-haspopup="true" aria-expanded="false"><img src="./images/filter.png" alt=""></a>
					<div class="dropdown-menu">
						<a class="dropdown-item" href="#">Follow up</a>
						<a class="dropdown-item" href="#">Call reminder</a>
						<a class="dropdown-item" href="#">Appointment</a> </div>
				</li>
			</ul>
		</ol>
	</section>

	<!-- Main content -->
	<section class="content">
		<!-- Small boxes (Stat box) -->
		<div class="wrapper_box">
			<div class="freamcrm_text">
				<h4>What’s special about pipelines in Freshworks CRM?</h4>
				<ul>
					<li>If you have different sales processes, with unique deal journeys, you can create multiple pipelines to
						accurately capture each sales process.</li>
					<li>If you’re bulk importing deals from another CRM, and you need one pipeline to store all these deals, you
						can mark the pipeline as “default”.</li>
				</ul>
			</div>

			<div class="configer_pipe">
				<h3>Configure Pipeline</h3>
				<p>Define up to 10 custom pipelines with different deal stages, their associated probabilities and rotten deal
					timelines to suit each sales process in your business.<a href=""> Learn more</a></p>
			</div>

			<div class="configer_pipe_bottom">
				<div class="row">
					<div class="col-md-4 col-sm-12 col-xs-12">
						<div class="configer_pipe_bottom_l">
							<div class="configer_pipe_bottom_l_headinbg">
								<h4>Default Pipeline</h4>
								<ul class="add_list">
									<li class="">
										<a href="#" data-toggle="modal" data-target="#pipelineModal"
											class="btn btn-creat"><i class="fa fa-pencil" aria-hidden="true"></i></a>
									</li>
									<!-- <li class="dropdown"><a href="" type="button"><i class="fa fa-trash-o" aria-hidden="true"></i></a></li> -->
								</ul>
							</div>
							<div class="default_pipeline">
								<input type="checkbox"> Marked as default pipeline
							</div>

							<div class="configer_pipe_bottom_l_list">
								<?php
                $pipeline = $this->common_model->select('deals_company_pipelines', ['user_id'=> $this->admin['id']], '*', 'rank', 'ASC');
                if(empty($pipeline)){
                    $pipeline = $this->common_model->select('deals_pipelines', ['status'=>1], '*', 'rank', 'ASC');
                }
                if($pipeline){
                  foreach ($pipeline as $key => $value) {
                    $clr = "";
                    if(strtolower($value->pipeline_stage) == "won"){
                      $clr = "text-green";
                    }else if(strtolower($value->pipeline_stage) == "lost"){
                      $clr = "text-red";
                    }
                    ?>
					<div class="configer_pipe_bottom_l_list_box">
						<span class="<?=$clr?>"><?=$value->pipeline_stage?></span>
						<b>Probability : <?=$value->probability?>%</b>
					</div>
					<?php
                  }
                }
                  ?>
							</div>
						</div>
					</div>
					<div class="col-md-4 col-sm-12 col-xs-12">
						<div class="pipedeal_r">
							<!-- <a href="javascript:void(0);" data-toggle="modal" data-target="#stage1">
                            	<i class="fa fa-plus-circle" aria-hidden="true"></i>
                              <span>Create pipeline</span>
                          </a> -->
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- /.content -->
</div>

<!-- Modal pipeline -->
<div class="modal fade left-modal" id="pipelineModal" tabindex="-1" role="dialog"
	aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
	<div class="modal-dialog modal-dialog-centered" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="exampleModalLongTitle">EDIT PIPELINE</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
	  		<form id="frmDealPipeline" enctype="multipart/form-data">
				<input type="hidden" name="lead_deal_pipeline_id" value="1">
				<div class="form_panel_stage">
					<div class="">
						<label>Pipeline name <span class="reg">*</span></label>
						<input type="text" placeholder="" value="Default" readonly/>
					</div>
					<div class="default_pipeline">
						<input type="checkbox" checked readonly> Marked as default pipeline
					</div>

					<!-- <div class="">
						<label>Summarize stage by <span class="reg">*</span></label>
						<input type="text" placeholder="" />
					</div> -->

					<div class="pd-b-30">
						<label>Deals rot after <span class="reg">*</span></label>
						<input type="text" value="30" placeholder="" style="width:200px;" readonly/> <span
							style="color:#999; font-size:12px;">days</span>
					</div>

					<div class="">
						<div class="row">
							<div class="col-md-8 col-sm-12 col-xs-12"><label>Deal stage <span class="reg">*</span></label></div>
							<div class="col-md-4 col-sm-12 col-xs-12"><label>Stage probability <span class="reg">*</span></label>
							</div>
							<div class="clearfix"></div>
            </div>
              <?php
              if($pipeline){
                  foreach ($pipeline as $key => $value) {
                    $clr = "";
                    if($value->is_default == "1"){
                      $clr = "text-green";
                    }
                    if($value->is_default == "0"){
                      $clr = "text-red";
                    }
                    ?>
						<input type="hidden" name="is_default[]" value="<?=$value->is_default?>">
                      <div class="dynamicfield_pipeline">
                        <div class="row">
                          <div class="col-md-1 col-sm-12 col-xs-12">
                            <i class="fa fa-minus-circle <?=$clr?>" aria-hidden="true"></i>
                          </div>
                          <div class="col-md-7 col-sm-12 col-xs-12">
                            <input type="text" name="stage[]" placeholder="new" value="<?=$value->pipeline_stage?>"/>
                          </div>
                          <div class="col-md-4 col-sm-12 col-xs-12">
                            <input type="text" name="probability[]" placeholder="100" style="width:85%;" value="<?=$value->probability?>"/> %
                          </div>
                        </div>
                      </div>
                  <?php
                  }
                }
              ?>
					</div>
        </div>
        </form>
			</div>
			<div class="modal-footer">
				<button type="button" class="close_stage" data-dismiss="modal"><i class="fa fa-times-circle"
						aria-hidden="true"></i> &nbsp; Close</button>
				<button type="button" class="save_stage" data-parent="frmDealPipeline"><i class="fa fa-floppy-o" aria-hidden="true"></i> &nbsp; Save</button>
			</div>
		</div>
	</div>
</div>

<script>
  $(document).ready(function(){
    $('.fa-minus-circle.text-red').on('click', function(){
      $(this).parents('.dynamicfield_pipeline').remove();
    })

  $('.save_stage').on('click', function(){
    let f = $(this).data('parent');
    //var formData = $('#'+f).serialize();
    var formData = new FormData(document.querySelector('#'+f));
            console.log(formData);
            $.ajax({
                type: "POST",
                url: "<?=base_url('admin/settings/saveDealPipelineStage')?>",   //contact === lead
                // data: JSON.stringify(Object.assign({}, dataJson)),
                data: formData,
                cache: false,
                contentType: false,
                processData: false,
                beforeSend: function() {
                    
                },
                success: function(res) {
                    if(res == "Success"){
                        swalAlert('Form elements saved successfully');
                        setTimeout(function(){location.reload();}, 1500);
                    }else{
                        swalAlert('Unable to saved form elements');
                    }
                },
            });
  })
  })
</script>
