<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
     
       <ol class="bread_crumb">
        <li><a href="#"><img src="images/home_ico.png" alt=""></a></li>
        <!--<li><a href="#">Accounts</a></li>-->
        <li class="active"><a href="<?=base_url('admin/settings')?>">Admin Settings</a></li>
        
      </ol>
      
      <ol class="breadcrumb setting_btn">
       <ul class="add_list">
		  			
		  			<li class=""><a href="javascript:void(0);" class="btn btn-creat" data-toggle="modal" data-target="#ImportsModal">Import Accounts <i class="fa fa-caret-down"></i></a>		  			</li>
		  			<li class="dropdown"><a href="" class="dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Edit columns <i class="fa fa-caret-down"></i></a>
		  			<div class="dropdown-menu">
    <a class="dropdown-item" href="#">Follow up</a>
    <a class="dropdown-item" href="#">Call reminder</a>
    <a class="dropdown-item" href="#">Appointment</a>  </div>
		  			</li>
		  			<li class="dropdown"><a href="" class="dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><img src="./images/filter.png" alt=""></a>
		  			<div class="dropdown-menu">
    <a class="dropdown-item" href="#">Follow up</a>
    <a class="dropdown-item" href="#">Call reminder</a>
    <a class="dropdown-item" href="#">Appointment</a>  </div>
		  			</li>
		  		</ul>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      	<div class="wrapper_box">
        	<div class="adminsetting_box_panel">
            	<div class="row"> 
            	<div class="col-md-12 col-sm-12 col-xs-12"> 
                <div class="contact_box_panel_l">    	
               <h3><i><svg width="32" height="32" viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg" class="svg-modules"><g fill="none" fill-rule="nonzero"><path fill-opacity=".2" fill="#FFF" opacity=".01" d="M0 0h32v32H0z"></path><g transform="translate(.5 .5)" stroke="#12344D"><circle fill="#FFF" cx="15.5" cy="15.5" r="15.5"></circle><path fill="#BBDCFE" stroke-linecap="round" stroke-linejoin="round" d="M18.783 22.204H7.143l5.074-6.566L7.143 9.07h11.64l5.074 6.567z"></path></g></g></svg></i>Contact Lifecycle Stages</h3>
               <p>Customize everything about the default lifecycle stages: rename, reorder or disable them. Plus you can add a new stage that reflects your business process, like Evangelist or Marketing Qualified Lead. All statuses within a stage are customizable. If you want Contacts to change stages automatically, use these rules.</p>
               
               <div><a class="learnmore" href="">
               	<i><svg width="14" height="14" viewBox="0 0 14 14" xmlns="http://www.w3.org/2000/svg" class="svg-md mg-l-10 valign-middle"><g fill="none" fill-rule="evenodd"><path fill-opacity=".2" fill="#FFF" opacity=".01" d="M0 0h14v14H0z"></path><g><path fill-opacity=".01" fill="#FFF" opacity=".01" d="M0 0h14v14H0z"></path><path d="M6.556 10.578c0-.227.186-.411.416-.411.23 0 .417.184.417.41v.012a.414.414 0 0 1-.417.411.414.414 0 0 1-.416-.411v-.011z" fill="#2C5CC5" fill-rule="nonzero"></path><path d="M4.7 5.87c0-1.203 1.04-2.225 2.323-2.225s2.324.954 2.324 2.157c0 1.204-1.12 2.019-2.403 2.019v1.37" stroke="#2C5CC5" stroke-linecap="round" stroke-linejoin="round"></path><circle stroke="#2C5CC5" cx="7" cy="7" r="6.5"></circle></g></g></svg></i> Learn more
               </a></div>
               
               </div>
               </div>
               
               </div>
           </div>           
    	</div>
        
        
        <div class="contactsetting_table">
        	<div class="row">
            	<div class="col-md-12">
            		<h4>Active stages</h4>
                	<div class="row">
                        <div class="col-md-4 col-sm-12 col-sm-12">
                            <div class="leadform">
                            	<div class="svgarow_stage">
                                	<svg width="18" height="11" viewBox="0 0 18 11" xmlns="http://www.w3.org/2000/svg"><g fill="none" fill-rule="evenodd"><path fill-opacity=".01" fill="#FFF" opacity=".01" d="M0-3h18v18H0z"></path><g stroke="#000" stroke-linecap="round" stroke-linejoin="round"><path d="M11.491 10.66l5.223-5.222L11.491.214M.643 5.438h16.071"></path></g></g></svg>
                                </div>
                              	<h2><img src="<?= base_url('public/admin/images/doted_line.png')?>" alt="doted_line"/> Lead <a href="" data-toggle="modal" data-target="#stage1"><i class="fa fa-pencil" aria-hidden="true"></i></a></h2> 
                                <?php
                                    //$stage1 = $this->common_model->select('lead_lifecycle_stages', ['status'=>1, 'lead_lifecycle_id'=> 1], '*', 'rank', 'ASC');
                                    $stage1 = $this->common_model->select('lead_company_lifecycle_stages', ['user_id'=> $this->admin['id'], 'lead_lifecycle_id'=> 1], '*', 'rank', 'ASC');
                                  if(empty($stage1)){
                                      $stage1 = $this->common_model->select('lead_lifecycle_stages', ['status'=>1, 'lead_lifecycle_id'=> 1], '*', 'rank', 'ASC');
                                  }
                                    if($stage1){
                                      foreach ($stage1 as $key => $value) {
                                        ?>
                                          <div class="leadform_box">
                                            <span class=""><?=$value->stage?></span>
                                          </div>
                                        <?php
                                      }
                                    }
                                  ?>
                            </div>
                        </div>
                        
                        <div class="col-md-4 col-sm-12 col-sm-12">
                            <div class="leadform">
                           	<div class="svgarow_stage">
                                	<svg width="18" height="11" viewBox="0 0 18 11" xmlns="http://www.w3.org/2000/svg"><g fill="none" fill-rule="evenodd"><path fill-opacity=".01" fill="#FFF" opacity=".01" d="M0-3h18v18H0z"></path><g stroke="#000" stroke-linecap="round" stroke-linejoin="round"><path d="M11.491 10.66l5.223-5.222L11.491.214M.643 5.438h16.071"></path></g></g></svg>
                                </div>
                              	<h2><img src="<?= base_url('public/admin/images/doted_line.png')?>" alt="doted_line"/> Sales Qualified Lead <a href="" data-toggle="modal" data-target="#stage2"><i class="fa fa-pencil" aria-hidden="true"></i></a></h2> 
                                <?php
                                    //$stage1 = $this->common_model->select('lead_lifecycle_stages', ['status'=>1, 'lead_lifecycle_id'=> 2], '*', 'rank', 'ASC');
                                    $stage2 = $this->common_model->select('lead_company_lifecycle_stages', ['user_id'=> $this->admin['id'], 'lead_lifecycle_id'=> 2], '*', 'rank', 'ASC');
                                    if(empty($stage2)){
                                        $stage2 = $this->common_model->select('lead_lifecycle_stages', ['status'=>1, 'lead_lifecycle_id'=> 2], '*', 'rank', 'ASC');
                                    }
                                    if($stage2){
                                      foreach ($stage2 as $key => $value) {
                                        ?>
                                          <div class="leadform_box">
                                            <span class=""><?=$value->stage?></span>
                                          </div>
                                        <?php
                                      }
                                    }
                                  ?>
                            </div>
                        </div>
                        
                        
                        
                        <div class="col-md-4 col-sm-12 col-sm-12">
                            <div class="leadform">
                              	<h2><img src="<?= base_url('public/admin/images/doted_line.png')?>" alt="doted_line"/> Customer <a href="" data-toggle="modal" data-target="#stage3"><i class="fa fa-pencil" aria-hidden="true"></i></a></h2> 
                                <?php
                                    //$stage1 = $this->common_model->select('lead_lifecycle_stages', ['status'=>1, 'lead_lifecycle_id'=> 3], '*', 'rank', 'ASC');
                                    $stage3 = $this->common_model->select('lead_company_lifecycle_stages', ['user_id'=> $this->admin['id'], 'lead_lifecycle_id'=> 3], '*', 'rank', 'ASC');
                                  if(empty($stage3)){
                                      $stage3 = $this->common_model->select('lead_lifecycle_stages', ['status'=>1, 'lead_lifecycle_id'=> 3], '*', 'rank', 'ASC');
                                  }
                                    if($stage3){
                                      foreach ($stage3 as $key => $value) {
                                        ?>
                                          <div class="leadform_box">
                                            <span class=""><?=$value->stage?></span>
                                          </div>
                                        <?php
                                      }
                                    }
                                  ?>
                            </div>
                        </div>
                     </div>
                </div>
            </div>
        </div>
       
    </section>
    <!-- /.content -->
  </div>


  <!-- Modal -->
<div class="modal fade" id="stage1" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">EDIT LIFECYCLE STAGE</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="stagemodalinfo">
        	<span><i class="fa fa-info-circle" aria-hidden="true"></i></span>
        	<p>This is the default Sales Qualified Lead lifecycle stage. When a Contact shows interest in your business and they fit your ideal customer profile, they progress from being just a "lead" to a "sales qualified lead."</p>
        </div>
        <div class="form_panel_stage">
        <div class="pd-b-30">
        	<label>Lifecycle stage name <span class="reg">*</span></label>
            <input type="text" placeholder="Sales Qualified Lead" value="Lead" readonly/>
        </div>
        <div class="pd-b-30">
        	<label>Statuses for this stage  <span class="reg">*</span></label> 
          <form role="form" id="leadStage1">
             <input type="hidden" name="lead_lifecycle_id" value="1">            
                <div class="multi-field-wrapper">
                  <?php
                    //$stage1 = $this->common_model->select('lead_lifecycle_stages', ['status'=>1, 'lead_lifecycle_id'=> 1], '*', 'rank', 'ASC');
                    $stage1 = $this->common_model->select('lead_company_lifecycle_stages', ['user_id'=> $this->admin['id'], 'lead_lifecycle_id'=> 1], '*', 'rank', 'ASC');
                    if(empty($stage1)){
                        $stage1 = $this->common_model->select('lead_lifecycle_stages', ['status'=>1, 'lead_lifecycle_id'=> 1], '*', 'rank', 'ASC');
                    }
                    if($stage1){
                      foreach ($stage1 as $key => $value) {
                        ?>
                          <div class="multi-fields">
                            <div class="multi-field">
                              <button type="button" class="remove-field"><i class="fa fa-minus-circle" aria-hidden="true"></i></button>
                              <input type="text" name="stage[]" value="<?=$value->stage?>">                      
                              <!-- <input type="hidden" name="stage[]" value="<?=$value->lead_lifecycle_stage_id?>">                       -->
                            </div>
                          </div>
                        <?php
                      }
                    }
                  ?>
                <button type="button" class="add-field"><i class="fa fa-plus-circle" aria-hidden="true"></i> &nbsp; Add field</button>
              </div>
            </form>          
        </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="close_stage" data-dismiss="modal"><i class="fa fa-times-circle" aria-hidden="true"></i> &nbsp; Close</button>
        <button type="button" class="save_stage" data-parent="leadStage1"><i class="fa fa-floppy-o" aria-hidden="true"></i>  &nbsp;  Save</button>
      </div>
    </div>
  </div>
</div> 





<!-- Modal -->
<div class="modal fade" id="stage2" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">EDIT LIFECYCLE STAGE</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="stagemodalinfo">
        	<span><i class="fa fa-info-circle" aria-hidden="true"></i></span>
        	<p>This is the default Lead lifecycle stage. A Contact in this stage is considered a potential buyer who needs to be qualified.</p>
        </div>
        <div class="form_panel_stage">
        <div class="pd-b-30">
        	<label>Lifecycle stage name <span class="reg">*</span></label>
            <input type="text" placeholder="Sales Qualified Lead" value="Sales Qualified Lead" readonly/>
        </div>
        <div class="pd-b-30">
        	<label>Statuses for this stage  <span class="reg">*</span></label> 
             <form role="form" id="leadStage2">
             <input type="hidden" name="lead_lifecycle_id" value="2">
                <div class="multi-field-wrapper">
                <?php
                    //$stage2 = $this->common_model->select('lead_lifecycle_stages', ['status'=>1, 'lead_lifecycle_id'=> 2], '*', 'rank', 'ASC');
                    $stage2 = $this->common_model->select('lead_company_lifecycle_stages', ['user_id'=> $this->admin['id'], 'lead_lifecycle_id'=> 2], '*', 'rank', 'ASC');
                    if(empty($stage2)){
                        $stage2 = $this->common_model->select('lead_lifecycle_stages', ['status'=>1, 'lead_lifecycle_id'=> 2], '*', 'rank', 'ASC');
                    }
                    if($stage2){
                      foreach ($stage2 as $key => $value) {
                        ?>
                          <div class="multi-fields">
                            <div class="multi-field">
                              <button type="button" class="remove-field"><i class="fa fa-minus-circle" aria-hidden="true"></i></button>
                              <input type="text" name="stage[]" value="<?=$value->stage?>" >                      
                              <!-- <input type="hidden" name="stage[]" value="<?=$value->lead_lifecycle_stage_id?>">                       -->
                            </div>
                          </div>
                        <?php
                      }
                    }
                  ?>
                <button type="button" class="add-field"><i class="fa fa-plus-circle" aria-hidden="true"></i> &nbsp; Add field</button>
              </div>
            </form>          
        </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="close_stage" data-dismiss="modal"><i class="fa fa-times-circle" aria-hidden="true"></i> &nbsp; Close</button>
        <button type="button" class="save_stage" data-parent="leadStage2"><i class="fa fa-floppy-o" aria-hidden="true"></i>  &nbsp;  Save</button>
      </div>
    </div>
  </div>
</div> 

<!-- Modal -->
<div class="modal fade" id="stage3" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">EDIT LIFECYCLE STAGE</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="stagemodalinfo">
        	<span><i class="fa fa-info-circle" aria-hidden="true"></i></span>
        	<p>This is the default Lead lifecycle stage. A Contact in this stage is considered a potential buyer who needs to be qualified.</p>
        </div>
        <div class="form_panel_stage">
        <div class="pd-b-30">
        	<label>Lifecycle stage name <span class="reg">*</span></label>
            <input type="text" placeholder="Sales Qualified Lead" value="Customer" readonly/>
        </div>
        <div class="pd-b-30">
        	<label>Statuses for this stage  <span class="reg">*</span></label> 
            <form role="form" id="leadStage3">
             <input type="hidden" name="lead_lifecycle_id" value="3">
                <div class="multi-field-wrapper">
                <?php
                    //$stage3 = $this->common_model->select('lead_lifecycle_stages', ['status'=>1, 'lead_lifecycle_id'=> 3], '*', 'rank', 'ASC');
                    $stage3 = $this->common_model->select('lead_company_lifecycle_stages', ['user_id'=> $this->admin['id'], 'lead_lifecycle_id'=> 3], '*', 'rank', 'ASC');
                    if(empty($stage3)){
                        $stage3 = $this->common_model->select('lead_lifecycle_stages', ['status'=>1, 'lead_lifecycle_id'=> 3], '*', 'rank', 'ASC');
                    }
                    if($stage3){
                      foreach ($stage3 as $key => $value) {
                        ?>
                          <div class="multi-fields">
                            <div class="multi-field">
                              <button type="button" class="remove-field"><i class="fa fa-minus-circle" aria-hidden="true"></i></button>
                              <input type="text" name="stage[]" value="<?=$value->stage?>">                      
                              <!-- <input type="hidden" name="" value="<?=$value->lead_lifecycle_stage_id?>">                       -->
                            </div>
                          </div>
                        <?php
                      }
                    }
                  ?>
                <button type="button" class="add-field"><i class="fa fa-plus-circle" aria-hidden="true"></i> &nbsp; Add field</button>
              </div>
            </form>          
        </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="close_stage" data-dismiss="modal"><i class="fa fa-times-circle" aria-hidden="true"></i> &nbsp; Close</button>
        <button type="button" class="save_stage" data-parent="leadStage3"><i class="fa fa-floppy-o" aria-hidden="true"></i>  &nbsp;  Save</button>
      </div>
    </div>
  </div>
</div>

<script>
// 	$('.multi-field-wrapper').each(function() {
//     var $wrapper = $('.multi-fields', this);
//     // $(".add-field", $(this)).click(function(e) {
//     //     $('.multi-field:first-child', $wrapper).clone(true).appendTo($wrapper).find('input').val('').focus();
//     // });
//     $('.multi-field .remove-field', $wrapper).click(function() {
//         if ($('.multi-field', $wrapper).length > 1)
//             $(this).parent('.multi-field').remove();
//     });
// });
//remove buttons
$(document).on('click', '.remove-field', function(){
  $(this).parents('.multi-fields').remove();
})
//add new field
$('.add-field').on('click', function(){
  //$(this).parent('.multi-field-wrapper').append('<div class="multi-fields"><div class="multi-field"> <button type="button" class="remove-field"><i class="fa fa-minus-circle" aria-hidden="true"></i></button> <input type="text" name="stage[]" value=""></div></div>');
  $('<div class="multi-fields"><div class="multi-field"> <button type="button" class="remove-field"><i class="fa fa-minus-circle" aria-hidden="true"></i></button> <input type="text" name="stage[]" value=""></div></div>').insertBefore($(this));
})


$(document).ready(function(){
  $('.save_stage').on('click', function(){
    let f = $(this).data('parent');
    //var formData = $('#'+f).serialize();
    var formData = new FormData(document.querySelector('#'+f));
            console.log(formData);
            $.ajax({
                type: "POST",
                url: "<?=base_url('admin/settings/saveLifecycleStage')?>",   //contact === lead
                // data: JSON.stringify(Object.assign({}, dataJson)),
                data: formData,
                cache: false,
                contentType: false,
                processData: false,
                beforeSend: function() {
                    
                },
                success: function(res) {
                    if(res == "Success"){
                        swalAlert('Form elements saved successfully');
                        setTimeout(function(){location.reload();}, 1500);
                    }else{
                        swalAlert('Unable to saved form elements');
                    }
                },
            });
  })
})
</script>