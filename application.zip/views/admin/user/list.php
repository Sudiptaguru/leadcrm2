<script src="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css"></script>
<link href="https://cdn.datatables.net/rowreorder/1.2.5/css/rowReorder.dataTables.min.css" rel="stylesheet" />
<link href="https://cdn.datatables.net/responsive/2.2.3/css/responsive.dataTables.min.css" rel="stylesheet" />
<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
          <h3>
            User settings
            
          </h3>
          <!--<ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Dashboard</li>
          </ol>-->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header with-border">
				<a href="<?php echo base_url('admin/user/add');?>" class="btn btn-sm btn-primary" style="float:right">Add User</a>
			  <?php if($this->session->flashdata('error_msg')){?>
							<div class="alert alert-warning alert-dismissible hite">
								<button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
								<h4><i class="icon fa fa-warning"></i><?php echo $this->session->flashdata('error_msg'); ?></h4>
							</div>
						  <?php }?>
						  <?php if($this->session->flashdata('success_msg')){?>
							<div class="alert alert-success alert-dismissible hite">
								<button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
								<h4><i class="icon fa fa-warning"></i><?php echo $this->session->flashdata('success_msg'); ?></h4>
							</div>
						  <?php }?>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table display nowrap table-bordered table-striped">
                <thead>
                <tr>
                  <th>Sl no</th>
                  <th>Name</th>
                  <th>Email Id</th>
                  <th>Company</th>
                  <th>Role</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
                </thead>
                <tbody>
                </tbody>
                <tfoot>
                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- Modal -->
	  <div class="modal" id='myModal'>
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">×</span></button>
                <h4 class="modal-title">Message</h4>
              </div>
              <div class="modal-body" id='modalContent' title="">
               <!-- <p>Would you like to continue ?</p>-->
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary" data-dismiss="modal" id="cdel">Ok</button>
              </div>
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>
	  <!-- Modal -->
<script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url()?>public/admin_assets/plugins/datatables/dataTables.bootstrap.min.js"></script>
<script src="https://cdn.datatables.net/rowreorder/1.2.5/js/dataTables.rowReorder.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.2.3/js/dataTables.responsive.min.js"></script>
<script>
$(document).ready(function() { 
  var now = new Date();
  var date = now.getFullYear() + "-" + now.getMonth() + "-" + now.getDate();
	table = $('#example1').DataTable({ 
 
        "processing": true, //Feature control the processing indicator.
        "serverSide": true, //Feature control DataTables' server-side processing mode.
        "order": [], //Initial no order.
 
        // Load data for the table's content from an Ajax source
        "ajax": {
            "url": "<?php echo site_url('admin/user/all_content_list')?>",
            "type": "POST"
        },
 
        //Set column definition initialisation properties.
        "columnDefs": [
        { 
            "targets": [ -1 ], //last column
            "orderable": false, //set not orderable
        },
        ],
        rowReorder: {
            selector: 'td:nth-child(2)'
        },
        responsive: true,
        dom:'Bfrtip',
        buttons:[{ 
            extend: 'excel',                        
            filename: 'users_list_' + date,
            className: "btn btn-round_small btn-img",
            text: '<i class="fa fa-file-excel-o" aria-hidden="true"></i> Export',
            tag:  'span',
            exportOptions: { columns: [0,1,2,3] }  
        }     
        //'excel'
        ]
 
    });
	$(document).on( "click",'#delete.cstm_view',function() {
		$('#modalContent').html('<p>Would you like to continue ?</p>');
		var id=$(this).prop('title');
		$('#modalContent').attr('title',id);
		$('#myModal').modal('show');
	});
	$(document).on('click','#cdel',function(){
	var id=$('#modalContent').prop('title');
	$.ajax({
	  type: "POST",
	  url: '<?php echo base_url('admin/user/delete_content')?>',
	  data: 'id='+id,
	  dataType:'json',
	  success: function(response){
		$('#modalContent').html(response.message);  
		$('#myModal').modal('show');
		setTimeout(function(){
			$('#myModal').modal('hide')
		},400);
		window.location.reload('<?php echo base_url('admin/user'); ?>');
		
	  },
	  error:function(response){
		$('#modalContent').html(response.message);  
		$('#myModal').modal('show');
		setTimeout(function(){
			$('#myModal').modal('hide')
		},400);
	  }
	});
});
});
</script>
  