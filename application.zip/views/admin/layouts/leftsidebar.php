<?php $menu_lists  = $this->menu_list;?>
<!-- Left side column. contains the logo and sidebar -->
<?php $admin=$this->session->userdata('admin'); ?>
<?php //echo "<pre>"; print_r($admin); die;?>
<?php  $company_id=$admin['company_id'];?>
<aside class="main-sidebar">
  <!-- sidebar: style can be found in sidebar.less -->
  <section class="sidebar">
    <!-- Sidebar user panel -->
    <div class="user-panel">
      <div class="pull-left image">
        <?php if(!empty($admin['profile_image'])) {?>
        <img src="<?php echo base_url()?>public/admin_assets/images/profilepics/<?php echo $admin['profile_image'];?>" class="img-circle" alt="User Image">
        <?php }else{?>
        <img src="<?php echo base_url()?>public/admin_assets/images/profilepics/Dummy.jpg" class="img-circle" alt="User Image">
        <?php }?>
      </div>
      <div class="pull-left info">
        <p>Hello <?php echo $admin['name'];?></p>
        <!--<a href="#"><i class="fa fa-circle text-success"></i> Online</a>-->
      </div>
    </div>


    <ul class="sidebar-menu">
      <li class="">
        <a href="<?php echo base_url('admin/dashboard');?>">
        <i class="fa fa-th"></i> <span>Dashboard</span>
        <span class="pull-right-container">
        </span>
        </a>
      </li>      
      <?php if ($admin['role_id'] == 2) { ?>
        <li class="treeview">
          <a href="#">
          <i class="fa fa-user"></i>
          <span>User</span>
          <span class="pull-right-container">
          <i class="fa fa-angle-left pull-right"></i>
          </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo base_url('admin/user');?>"><i class="fa fa-circle-o"></i>Manage Users</a></li>
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
          <i class="fa fa-user"></i>
          <span>Role</span>
          <span class="pull-right-container">
          <i class="fa fa-angle-left pull-right"></i>
          </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo base_url('admin/role/list');?>"><i class="fa fa-circle-o"></i>List</a></li>
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
          <i class="fa fa-file-text-o"></i>
          <span>All Leads</span>
          <span class="pull-right-container">
          <i class="fa fa-angle-left pull-right"></i>
          </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo base_url('admin/leads');?>"><i class="fa fa-circle-o"></i>Manage Leads</a></li>
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
          <i class="fa fa-usd" aria-hidden="true"></i>
          <span>User Commission</span>
          <span class="pull-right-container">
          <i class="fa fa-angle-left pull-right"></i>
          </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo base_url('admin/commission');?>"><i class="fa fa-circle-o"></i>Users Commission List</a></li>
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
          <i class="fa fa-briefcase" aria-hidden="true"></i>
          <span>Company</span>
          <span class="pull-right-container">
          <i class="fa fa-angle-left pull-right"></i>
          </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo base_url('admin/company');?>"><i class="fa fa-circle-o"></i>List</a></li>
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
          <i class="fa fa-line-chart" aria-hidden="true"></i>
          <span>Campain</span>
          <span class="pull-right-container">
          <i class="fa fa-angle-left pull-right"></i>
          </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo base_url('admin/campaign');?>"><i class="fa fa-circle-o"></i>List</a></li>
          </ul>
        </li>
        <?php } else{ ?>
        <?php if(!empty($menu_lists)){ ?>
        <?php if(in_array('user',$menu_lists)){ ?>
          <li class="treeview">
            <a href="#">
            <i class="fa fa-user"></i>
            <span>User Management</span>
            <span class="pull-right-container">
            <i class="fa fa-angle-left pull-right"></i>
            </span>
            </a>
            <ul class="treeview-menu">
              <li><a href="<?php echo base_url('admin/user');?>"><i class="fa fa-circle-o"></i>Manage Users</a></li>
            </ul>
          </li>
        <?php } ?>
        <?php if(in_array('role',$menu_lists)){ ?>
          <li class="treeview">
            <a href="#">
            <i class="fa fa-user"></i>
            <span>Role Management</span>
            <span class="pull-right-container">
            <i class="fa fa-angle-left pull-right"></i>
            </span>
            </a>
            <ul class="treeview-menu">
              <li><a href="<?php echo base_url('admin/role/list');?>"><i class="fa fa-circle-o"></i>List</a></li>
            </ul>
          </li>
        <?php } ?>
        <?php if(in_array('leads',$menu_lists)){ ?>
          <li class="treeview">
            <a href="#">
            <i class="fa fa-file-text-o"></i>
            <span>All Leads</span>
            <span class="pull-right-container">
            <i class="fa fa-angle-left pull-right"></i>
            </span>
            </a>
            <ul class="treeview-menu">
              <li><a href="<?php echo base_url('admin/leads');?>"><i class="fa fa-circle-o"></i>Manage Leads</a></li>
            </ul>
          </li>
        <?php } ?>
        <?php if(in_array('assignedproject',$menu_lists)){ ?>
          <li class="treeview">
            <a href="#">
            <i class="fa fa-file-text-o"></i>
            <span>Assigned project</span>
            <span class="pull-right-container">
            <i class="fa fa-angle-left pull-right"></i>
            </span>
            </a>
            <ul class="treeview-menu">
              <li><a href="<?php echo base_url('admin/assignedproject');?>"><i class="fa fa-circle-o"></i>Assigned Project List</a></li>
            </ul>
          </li>                
    <?php   } 
          if(in_array('commission',$menu_lists)){ ?>
            <li class="treeview">
              <a href="#">
              <i class="fa fa-usd" aria-hidden="true"></i>
              <span>User Commission</span>
              <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
              </span>
              </a>
              <ul class="treeview-menu">
                <li><a href="<?php echo base_url('admin/commission');?>"><i class="fa fa-circle-o"></i>Users Commission List</a></li>
              </ul>
            </li>
          <?php } 
            if(in_array('company',$menu_lists)){ ?>
                <li class="treeview">
                  <a href="<?=base_url('admin/company/edit/' . $company_id) ?>"> 
                  <i class="fa fa-briefcase" aria-hidden="true"></i>
                  <span>Company Info</span>
                  <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                  </span>
                  </a>
                 <!--  <ul class="treeview-menu">
                    <li><a href="<?php echo base_url('admin/company');?>"><i class="fa fa-circle-o"></i>List</a></li>
                  </ul> -->
                </li>
          <?php }  
            if(in_array('campaign',$menu_lists)){ ?>
                <li class="treeview">
                  <a href="#">
                  <i class="fa fa-line-chart" aria-hidden="true"></i>
                  <span>Campaign</span>
                  <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                  </span>
                  </a>
                  <ul class="treeview-menu">
                    <li><a href="<?php echo base_url('admin/campaign');?>"><i class="fa fa-circle-o"></i>List</a></li>
                  </ul>
                </li> 
          <?php }    
        }
    } ?>
    </ul>
  </section>
  <!-- /.sidebar -->
</aside>