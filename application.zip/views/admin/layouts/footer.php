<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 1.0
    </div>
    <strong>Copyright &copy; <?php echo date('Y');?> <!--<a href="http://almsaeedstudio.com">Almsaeed Studio</a>-->.</strong> All rights
    reserved.
  </footer>
    <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>

</div>
<!-- Bootstrap 3.3.6 -->
<script src="<?php echo base_url()?>/public/admin_assets/bootstrap/js/bootstrap.min.js"></script>
<!-- SlimScroll 1.3.0 -->
<script src="<?php echo base_url()?>/public/admin_assets/plugins/slimScroll/jquery.slimscroll.min.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url()?>/public/admin_assets/dist/js/app.min.js"></script>
<script src="<?=base_url('public/admin_assets/vendors/js/datatable/datatables.min.js')?>"></script>
<script src="<?=base_url('public/admin_assets/vendors/js/datatable/dataTables.buttons.min.js')?>"></script>
<script src="<?=base_url('public/admin_assets/vendors/js/datatable/buttons.flash.min.js')?>"></script>
<script src="<?=base_url('public/admin_assets/vendors/js/datatable/jszip.min.js')?>"></script>
<script src="<?=base_url('public/admin_assets/vendors/js/datatable/pdfmake.min.js')?>"></script>
<script src="<?=base_url('public/admin_assets/vendors/js/datatable/vfs_fonts.js')?>"></script>
<script src="<?=base_url('public/admin_assets/vendors/js/datatable/buttons.html5.min.js')?>"></script>
<script src="<?=base_url('public/admin_assets/vendors/js/datatable/buttons.print.min.js')?>"></script>
<script src="<?php echo base_url()?>public/admin_assets/plugins/datatables/dataTables.bootstrap.min.js"></script>
<script src="https://cdn.datatables.net/rowreorder/1.2.5/js/dataTables.rowReorder.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.2.3/js/dataTables.responsive.min.js"></script>
<script type="text/javascript" src="<?= base_url('public/sweetalert2.all.min.js') ?>"></script>
<script>

$(document).ready(function() { 
    $('a[href="' + location.href + '"]').parents('li,ul').addClass('active');
});
function validateEmail($email) {
      var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
      return emailReg.test( $email );
    }
    $(document).on('click','#subscribe',function(){
        var email = $('#email').val();
        if(email ==""){
            alert('Please put the email id.');
             $('#email').focus();
        }
        else{
            if( !validateEmail(email)) {
                alert('Please put a vaild email id.');
            }
            else{
                $.ajax({
                    type: "POST",
                    url: base_url + "newsletter",
                    data: {
                        email: email
                    },
                    dataType: "JSON",
                    success: function(response) {
                        //alert(response['status']);
                        if (response.status == 1) {
                            alert(response.message);
                            location.reload();
                        } else {
                            alert(response.message);
                        }
                    }
                });
            }
        }
    })
    function nospaces(t){
    if(t.value.match(/\s/g) && t.value.length == 1){
        alert('Sorry, you are not allowed to enter any spaces in the starting.');
        t.value=t.value.replace(/\s/g,'');
    }

}
</script>
</body>
</html>