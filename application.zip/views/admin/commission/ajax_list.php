<table class="table table-striped table-bordered export_btn_dt c_table_style" id="tablecommission">
  <thead>
    <tr>
      <th>Sl no</th>
      <th>User Name</th>
      <th>Commission Ratio</th>      
    </tr>
  </thead>
  <tbody>
  <?php if(!empty($details)){ 
          foreach($details as $key => $list){
  ?>
          <tr>
              <td><?php echo $key+1; ?></td>
              <td><?php echo $list->name; ?></td>
              <td><?php echo $list->total_commission_ratio; ?></td>
          </tr>
  <?php   } } else{ ?>
          <tr><h3>No record found</h3></tr>
  <?php } ?>
  </tbody>
  <tfoot>
  </tfoot>
</table>