<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
<!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h3>
            Leads settings
            
          </h3>
          <!--<ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Dashboard</li>
          </ol>-->
        </section>

        <!-- Main content -->
        <section class="content"> 
			<div class="row">
				<!-- general form elements -->
				<div class="col-md-12">
					  <div class="box box-primary">
						<div class="box-header with-border">
						  <h3 class="box-title"></h3>
						  <?php if($this->session->flashdata('error_msg')){?>
							<div class="alert alert-warning alert-dismissible hite">
								<button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
								<h4><i class="icon fa fa-warning"></i><?php echo $this->session->flashdata('error_msg'); ?></h4>
							</div>
						  <?php }?>
						  <?php if($this->session->flashdata('success_msg')){?>
							<div class="alert alert-success alert-dismissible hite">
								<button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
								<h4><i class="icon fa fa-warning"></i><?php echo $this->session->flashdata('success_msg'); ?></h4>
							</div>
						  <?php }?>
						</div>
						<!-- /.box-header -->
						<!-- form start -->
						<form role="form" class="mtbresize" method="post" action="<?php echo base_url('admin/assignedproject/update');?>" enctype="multipart/form-data">
						  <div class="box-body">
						  	<div class="form-group">
							  <label for="name">Client Name</label>
							  <input type="text" class="form-control" id="name" value="<?php echo $assignedproject['name'];?>" placeholder="name" readonly>
							  <?php echo form_error('name','<span class="error">', '</span>'); ?>
							</div>
							<div class="form-group">
							  <label for="email">Client Email</label>
							  <input type="email" class="form-control" id="email" value="<?php echo $assignedproject['email_id'];?>" placeholder="email" readonly>
							  <?php echo form_error('email','<span class="error">', '</span>'); ?>
							</div>
							<div class="form-group">
							  <label for="phone">Client Phone</label>
							  <input type="phone" class="form-control" id="phone" value="<?php echo $assignedproject['phone'];?>" placeholder="phone" readonly>
							  <?php echo form_error('phone','<span class="error">', '</span>'); ?>
							</div>
							<!--<div class="form-group">
							  <label for="schedule">Schedule For Contact</label>
							  <input type="schedule" class="form-control" id="schedule" value="<?php //echo date( 'd-M-Y h:ia', strtotime( $assignedproject['schedule_for_contact'] ) );?>" placeholder="schedule" readonly>
							  <?php //echo form_error('schedule','<span class="error">', '</span>'); ?>
							</div>-->
							<div class="form-group">
							  <label for="message">Message</label>
							  <textarea class="form-control" id="message" readonly><?php echo $assignedproject['message'];?></textarea>
							  <?php echo form_error('message','<span class="error">', '</span>'); ?>
							</div>
							<div class="form-group">
							  <label for="project_name">Project Name</label>
							  <input type="project_name" class="form-control" id="project_name" name="project_name" value="<?php echo $assignedproject['project_name'];?>" placeholder="Project Name">
							  <?php echo form_error('project_name','<span class="error">', '</span>'); ?>
							</div>
							<div class="form-group">
							  <label for="project_description">Project Description</label>
							  <textarea class="form-control" id="project_description" name="project_description"><?php echo $assignedproject['project_description'];?></textarea>
							  <?php echo form_error('project_description','<span class="error">', '</span>'); ?>
							</div>
							<div class="form-group">
							  <label>Currency</label>
							  <select class="form-control" name="currency" id="currency">
								<option value="aud" <?php if($assignedproject['currency']=="aud"){?>selected="selected"<?php }?>>AUD</option>
								<option value="euro" <?php if($assignedproject['currency']=="euro"){?>selected="selected"<?php }?>>EURO</option>
								<option value="usd" <?php if($assignedproject['currency']=="usd"){?>selected="selected"<?php }?>>USD</option>
								<option value="nzd" <?php if($assignedproject['currency']=="nzd"){?>selected="selected"<?php }?>>NZD</option>
								<option value="gbp" <?php if($assignedproject['currency']=="gbp"){?>selected="selected"<?php }?>>GBP</option>
							  </select>
							</div>
							<div class="form-group">
							  <label for="quotation_price">Quotation Price</label>
							  <input type="number" step="0.01" min="0" class="form-control" id="quotation_price" name="quotation_price" value="<?php echo $assignedproject['quotation_price'];?>" placeholder="Quotation Price" required>
							  <?php echo form_error('quotation_price','<span class="error">', '</span>'); ?>
							</div>
							<div class="form-group">
							  <label for="closing_price">Closing Price</label>
							  <input type="number" step="0.01" min="0" class="form-control" id="closing_price" name="closing_price" value="<?php echo $assignedproject['closing_price'];?>" placeholder="Closing Price" required>
							  <?php echo form_error('closing_price','<span class="error">', '</span>'); ?>
							</div>
							<?php // echo $assignedproject['status'];exit; ?>
							<div class="form-group">
							  <label>Project Status</label>
							  <select class="form-control" name="status" id="status">
								<option value="open" <?php if($assignedproject['status'] == "open"){ echo "selected"; }?>>Open</option>
								<option value="close" <?php if($assignedproject['status'] == "close"){ echo "selected"; }?>>Close</option>
								<option value="innegotiation" <?php if($assignedproject['status'] == "innegotiation"){ echo "selected"; }?>>Innegotiation</option>
								<option value="lost" <?php if($assignedproject['status'] == "lost"){ echo "selected"; }?>>Lost</option>
							  </select>
							</div>
						  </div>
						  <!-- /.box-body -->
						  <div class="box-footer">
						  	<input type="hidden" name="project_id" value="<?php echo $assignedproject['id'];?>">
						  	<button type="button" style="background-color:black;color:white" onclick="window.history.back()" class="btn btn-sm btn-round">Back</button>
                            <button type="submit" class="btn btn-sm btn-primary">Submit</button>
						  </div>
						</form>
					  </div>
				</div>
          <!-- /.box -->
          </div><!-- /.row -->	
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
<script type="text/javascript">
	$('.js-example-basic-single').select2({
  });
</script>