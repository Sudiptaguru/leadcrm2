<style>
.login-bg {
	/*background: url("http://dev.fitser.com:3794/fitsercampaign/public/admin_assets/dist/img/login-bg.jpg");*/
	background: #000;
	background-position: center;
	background-size: cover;
	height: 100vh;
}
	.login-box, .register-box {
	width: 468px;
	margin: 0 auto;
	position: absolute;
	left: 50%;
	top: 50%;
	transform: translate(-50%,-50%);
}
.login-box-body, .register-box-body {
	    background: #212121;
    padding: 20px;
    border-top: 0;
    color: #fff;
    min-height: 400px;
    /* border: 2px solid #3c8dbcb8; */
    border-radius: 0;
}
label{
      color: #fff;
    font-size: 14px;font-weight: 400;
}
.form-control{
   height: 50px;
    border-radius: 0;
    font-size: 18px;
    border: aliceblue;
    background: #000;
    border: #545454 solid 1px;
}
.login_btn{
    padding: 13px 13px;
    border: #16364d 1px solid;
    display: inline-block;
    font-size: 16px;
    color: #fff;
    background: #16364d;
    margin-top: 10px;
    border-radius: 3px;
    width: 100%;
}
	@media (min-width:320px) and (max-width:479px) {
	
		.login-box, .register-box {
	width: 90% !important;
}
	@media (min-width:480px) and (max-width:767px) {
	
		.login-box, .register-box {
	width: 70% !important;
}
}
	
	
</style>
<div class="login-bg">
 <div class="login-box">
  
  <!-- /.login-logo -->
  <div class="login-box-body">
   <div class="login-logo">
    <img src="https://devfitser.com/leadcrm2/public/admin/images/logo.png" style="">
    <!-- <a href="<?php echo base_url('admin');?>"><b>Admin</b>LTE</a> -->
  </div>
    <p class="login-box-msg">
	<?php if($this->session->flashdata('error_msg') && $this->session->flashdata('error_msg')!=''){ ?>
			<span style='color:red'><?php echo $this->session->flashdata('error_msg');?></span>
		<?php }else{?>
			Sign in to start your session
		<?php }?>
	</p>

    <form action="<?php echo base_url('admin/index');?>" method="post">
      <div class="form-group has-feedback">
        <label for="email">Email</label>
        <input type="email" class="form-control" placeholder="Email" name="email" id="email">
        <?php echo form_error('email','<span class="error">', '</span>'); ?>
      </div>
      <div class="form-group has-feedback">
        <label for="password">Password</label>
        <input type="password" class="form-control" placeholder="Password" name="password" id="password">
        <?php echo form_error('password','<span class="error">', '</span>'); ?>
      </div>
      <div class="row">
        <div class="col-xs-12">
          <button type="submit" class="login_btn">Sign In</button>
        </div>
        <!-- /.col -->
      </div>
    </form>

    <!--<div class="social-auth-links text-center">
      <p>- OR -</p>
      <a href="#" class="btn btn-block btn-social btn-facebook btn-flat"><i class="fa fa-facebook"></i> Sign in using
        Facebook</a>
      <a href="#" class="btn btn-block btn-social btn-google btn-flat"><i class="fa fa-google-plus"></i> Sign in using
        Google+</a>
    </div>-->
    <!-- /.social-auth-links -->

    <!-- <a href="#">I forgot my password</a><br> -->
    <!-- <a href="register.html" class="text-center">Register a new membership</a> -->

  </div>
  <!-- /.login-box-body -->
</div>
<!-- /.login-box -->
</div>