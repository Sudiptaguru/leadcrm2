<!-- Content Wrapper. Contains page content -->
<?php $admin=$this->session->userdata('admin'); ?>
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Super Admin Dashboard Panel
        <!--<small>Version 2.0</small>-->
      </h1>
     <!-- <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>-->
    </section>

    <!-- Main content -->
    <section class="content" id="top">
        <div class="row">
        <!-- general form elements -->
          <div class="col-md-12">
              <select  <?php if(isset($campaign)){ echo "disabled";}elseif($admin['role_id'] != 2) { echo "disabled"; } ?> name="company_id" id="company_id" required class="form-control">
                <option value="">Select Company</option>
                <?php if(!empty($company)){ 
                    foreach($company as $list){ ?>
                      <option value="<?php echo $list->company_id; ?>"><?php echo $list->name; ?></option>
                <?php } }?>$admin['role_id']
              </select>
          </div>
        </div>
    </section>
    
    <!-- /.content -->	
  </div>
 <div>   
 </div> 
  <!-- /.content-wrapper -->
<script>
  $(document).on('change','#company_id',function(){
    var company_id = $(this).val();
    if(company_id !=''){
      window.location.href = base_url + "company-dashboard/" + company_id;
    }
    else{
      alert("Please select company first.");
    }
  })
</script>
