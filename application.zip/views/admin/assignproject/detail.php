<!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h3>
            Project settings
            
          </h3>
          <!--<ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Dashboard</li>
          </ol>-->
        </section>

        <!-- Main content -->
        <section class="content"> 
			<div class="row">
				<!-- general form elements -->
				<div class="col-md-12">
					  <div class="box box-primary">
						<div class="box-header with-border">
						  <h3 class="box-title"></h3>
						  <?php if($this->session->flashdata('error_msg')){?>
							<div class="alert alert-warning alert-dismissible hite">
								<button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
								<h4><i class="icon fa fa-warning"></i><?php echo $this->session->flashdata('error_msg'); ?></h4>
							</div>
						  <?php }?>
						  <?php if($this->session->flashdata('success_msg')){?>
							<div class="alert alert-success alert-dismissible hite">
								<button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
								<h4><i class="icon fa fa-warning"></i><?php echo $this->session->flashdata('success_msg'); ?></h4>
							</div>
						  <?php }?>
						</div>
						<!-- /.box-header -->
						<!-- form start -->
						<form role="form" class="mtbresize" method="post" action="<?php echo base_url('admin/project/update');?>" enctype="multipart/form-data">
						  <div class="box-body">
						  	<div class="form-group">
							  <label for="name">Client Name</label>
							  <input type="text" class="form-control" id="name" value="<?php echo $project['name'];?>" placeholder="name" readonly>
							  <?php echo form_error('name','<span class="error">', '</span>'); ?>
							</div>
							<div class="form-group">
							  <label for="email">Client Email</label>
							  <input type="email" class="form-control" id="email" value="<?php echo $project['email_id'];?>" placeholder="email" readonly>
							  <?php echo form_error('email','<span class="error">', '</span>'); ?>
							</div>
							<div class="form-group">
							  <label for="phone">Client Phone</label>
							  <input type="phone" class="form-control" id="phone" value="<?php echo $project['phone'];?>" placeholder="phone" readonly>
							  <?php echo form_error('phone','<span class="error">', '</span>'); ?>
							</div>
							<div class="form-group">
							  <label for="schedule">Schedule For Contact</label>
							  <input type="schedule" class="form-control" id="schedule" value="<?php echo date( 'd-M-Y h:ia', strtotime( $project['schedule_for_contact'] ) );?>" placeholder="schedule" readonly>
							  <?php echo form_error('schedule','<span class="error">', '</span>'); ?>
							</div>
							<div class="form-group">
							  <label for="message">Message</label>
							  <textarea class="form-control" id="message" readonly><?php echo $project['message'];?></textarea>
							  <?php echo form_error('message','<span class="error">', '</span>'); ?>
							</div>
							<div class="form-group">
							  <label for="project_name">Project Name</label>
							  <input type="project_name" class="form-control" id="project_name" name="project_name" value="<?php echo $project['project_name'];?>" placeholder="Project Name">
							  <?php echo form_error('project_name','<span class="error">', '</span>'); ?>
							</div>
							<div class="form-group">
							  <label for="project_description">Project Description</label>
							  <textarea class="form-control" id="project_description" name="project_description"><?php echo $project['project_description'];?></textarea>
							  <?php echo form_error('project_description','<span class="error">', '</span>'); ?>
							</div>
							<div class="form-group">
							  <label for="quotation_price">Quotation Price</label>
							  <input type="quotation_price" class="form-control" id="quotation_price" name="quotation_price" value="<?php echo $project['quotation_price'];?>" placeholder="Quotation Price" required>
							  <?php echo form_error('quotation_price','<span class="error">', '</span>'); ?>
							</div>
							<div class="form-group">
							  <label for="closing_price">Closing Price</label>
							  <input type="closing_price" class="form-control" id="closing_price" name="closing_price" value="<?php echo $project['closing_price'];?>" placeholder="Closing Price" required>
							  <?php echo form_error('closing_price','<span class="error">', '</span>'); ?>
							</div>
							<div class="form-group">
							  <label>Assign To</label>
							  <select class="form-control" name="user" id="user" required>
							  	<?php foreach ($users as $user) { ?>
							  		<option value="<?=$user['id']?>"><?=$user['name']?></option>
							  	<?php } ?>
							  </select>
							</div>
							<div class="form-group">
							  <label>Project Status</label>
							  <select class="form-control" name="status" id="status">
								<option value="open" <?php if($project['status']=="open"){?>selected="selected"<?php }?>>Open</option>
								<option value="close" <?php if($project['status']=="close"){?>selected="selected"<?php }?>>Close</option>
							  </select>
							</div>
						  </div>
						  <!-- /.box-body -->
						  <div class="box-footer">
						  	<input type="hidden" name="project_id" value="<?php echo $project['id'];?>">
						  	<button type="button" style="background-color:black;color:white" onclick="window.history.back()" class="btn btn-sm btn-round">Back</button>
                            <button type="submit" class="btn btn-sm btn-primary">Submit</button>
						  </div>
						</form>
					  </div>
				</div>
          <!-- /.box -->
          </div><!-- /.row -->	
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
<script src="https://cdn.ckeditor.com/4.5.7/standard/ckeditor.js"></script>
<script>
function readURL(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('#blah').attr('src', e.target.result);
        }

        reader.readAsDataURL(input.files[0]);
    }
}

$("#imgInp").change(function(){
    readURL(this);
});
CKEDITOR.replace('description');
CKEDITOR.replace('content');
</script>