<!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h3>
            User settings
          </h3>
          <!--<ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Dashboard</li>
          </ol>-->
        </section>

        <!-- Main content -->
        <section class="content"> 
			<div class="row">
				<!-- general form elements -->
				<div class="col-md-12">
					  <div class="box box-primary">
						<div class="box-header with-border">
						  <h3 class="box-title"></h3>
						  <?php if($this->session->flashdata('error_msg')){?>
							<div class="alert alert-warning alert-dismissible hite">
								<button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
								<h4><i class="icon fa fa-warning"></i><?php echo $this->session->flashdata('error_msg'); ?></h4>
							</div>
						  <?php }?>
						  <?php if($this->session->flashdata('success_msg')){?>
							<div class="alert alert-success alert-dismissible hite">
								<button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
								<h4><i class="icon fa fa-warning"></i><?php echo $this->session->flashdata('success_msg'); ?></h4>
							</div>
						  <?php }?>
						</div>
						<!-- /.box-header -->
						<!-- form start -->
						<form role="form" class="mtbresize" method="post" action="<?php echo base_url('admin/user/add_content');?>" enctype="multipart/form-data">
						  <div class="box-body">
							<div class="form-group">
							  <label for="name">Name</label>
							  <input type="text" class="form-control" id="name" name="name" value="<?php echo set_value('name');?>" placeholder="name" required>
							  <?php echo form_error('name','<span class="error">', '</span>'); ?>
							</div>
							<div class="form-group">
							  <label for="email">Email</label>
							  <input type="email" class="form-control" id="email" name="email" value="<?php echo set_value('email');?>" placeholder="email" required>
							  <?php echo form_error('email','<span class="error">', '</span>'); ?>
							</div>
							<div class="form-group">
							  <label for="password">Password</label>
							  <input type="password" class="form-control" id="password" name="password" value="<?php echo set_value('password');?>" placeholder="password" required>
							  <?php echo form_error('password','<span class="error">', '</span>'); ?>
							</div>
							<div class="form-group">
							  <label>Role</label>
							  <select class="form-control" name="role" id="role" required>
							  	<?php foreach ($roles as $role) { ?>
							  		<option value="<?=$role['role_id']?>"><?=$role['role_name']?></option>
							  	<?php } ?>
							  </select>
							</div>
							<div class="form-group">
							  <label>Status</label>
							  <select class="form-control" name="status" id="status">
								<option value="1">Active</option>
								<option value="0">Inactive</option>
							  </select>
							</div>
						  </div>
						  <!-- /.box-body -->
						  <div class="box-footer">
						  	<button type="button" style="background-color:black;color:white" onclick="window.history.back()" class="btn btn-sm btn-round">Back</button>
                            <button type="submit" class="btn btn-sm btn-primary">Submit</button>
						  </div>
						</form>
					  </div>
				</div>
          <!-- /.box -->
          </div><!-- /.row -->	
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
<script src="https://cdn.ckeditor.com/4.5.7/standard/ckeditor.js"></script>
<script>
function readURL(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('#blah').attr('src', e.target.result);
        }

        reader.readAsDataURL(input.files[0]);
    }
}

$("#imgInp").change(function(){
    readURL(this);
});
CKEDITOR.replace('description');
CKEDITOR.replace('content');
</script>