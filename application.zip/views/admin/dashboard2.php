<!-- include header -->
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
        <h4>
         Activities Dashboard


       </h4>


       <ol class="breadcrumb setting_btn">
         <!-- <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
          <li class="active">Dashboard</li>-->
          <li><a href="" class="btn btn-setting"><img src="<?=base_url('public/admin/')?>images/Settings_ico1.png" alt=""> Configure widgets</a></li>
        </ol>
      </section>

      <!-- Main content -->
      <section class="content">
        <!-- Small boxes (Stat box) -->
        <div class="row">
        	<div class="col-md-8" style="padding-top: 8px">
            <div class="wrapper_box">
             <div class="wrapper_head">
              <h3>Hey <strong>User!</strong></h3>
              <ul class="add_list">
               <li><a href="">Add task</a></li>
               <li><a href="">Add appointment</a></li>
               <li class="dropdown"><a href="" class="dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
                 <div class="dropdown-menu" >
                  <a class="dropdown-item" href="#">Follow up</a>
                  <a class="dropdown-item" href="#">Call reminder</a>
                  <a class="dropdown-item" href="#">Appointment</a>
                </div>
              </li>
            </ul>
          </div>
          <div class="wrapper_body">
            <div class="col-md-12">
             <div class="row">
              <ul class="showing_list">
               <li class="dropdown">Showing <a href="" class="dropdown-toggle" type="button"  data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">All activities <i class="fa fa-caret-down"></i></a>
                <div class="dropdown-menu">
                  <a class="dropdown-item" href="#">Follow up</a>
                  <a class="dropdown-item" href="#">Call reminder</a>
                  <a class="dropdown-item" href="#">Appointment</a>
                </div>
              </li>
              <li class="dropdown">for <a href="" class="dropdown-toggle" type="button"  data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Today (Sep 01) <i class="fa fa-caret-down"></i> </a>
               <div class="dropdown-menu">
                <a class="dropdown-item" href="#">Follow up</a>
                <a class="dropdown-item" href="#">Call reminder</a>
                <a class="dropdown-item" href="#">Appointment</a>
              </div>
            </li>

          </ul>
        </div>
      </div>

      <div class="col-md-12">
       <div class="row">
        <ul class="select_list">
         <li><input type="checkbox"> Select all</li>
         <li><input type="checkbox"> Open</li>
         <li><input type="checkbox"> Overdue</li>
         <li><input type="checkbox"> Completed</li>
         <li><a href="">All tasks and appointments</a></li>

       </ul>
     </div>
   </div>
   <div class="col-md-12">
     <div class="row">
      <div class="appointments_area">
       <h3>Find your upcoming tasks, appointments and reminders here.
       </h3>
       <div class="col-md-6">
        <div class="appointments_sec">
         <h4>Bring your emails into the CRM
         </h4>
         <p>Select your email provider

         </p>
         <ul class="app_list">
           <li><a href=""><img src="<?=base_url('public/admin/')?>images/gmail_ico.png" alt=""> Gmail</a></li>
           <li><a href=""><img src="<?=base_url('public/admin/')?>images/office_ico.png" alt=""> office 365</a></li>
           <li><a href=""><img src="images/other_ico.png" alt=""> Other</a></li>
         </ul>


       </div>
     </div>
     <div class="col-md-6">
      <div class="appointments_sec">
       <h4>Sync your calendar with the CRM
       </h4>
       <p>Select your calendar

       </p>
       <ul class="app_list">
         <li><a href=""><img src="<?=base_url('public/admin/')?>images/g_cal_ico.png" alt=""> Google Calendar</a></li>
         <li><a href=""><img src="<?=base_url('public/admin/')?>images/office_ico.png" alt=""> office 365</a></li>

       </ul>


     </div>
   </div>
   <div class="clearfix"></div>
  </div>
  </div>
  </div>


  <div class="clearfix"></div>
  </div>
  </div>
  </div>
  <div class="col-md-4">
   <div class="right_panel">
    <div class="wrapper_box">
     <div class="wrapper_head">
      <h3>Appointments</h3>

    </div>
    <div class="app_cal_sec">
     <div class="app_cal_head">
      <p><smal>Today</smal></p>
      <h4><strong>01 Sep</strong> <a href=""><img src="<?=base_url('public/admin/')?>images/arrow_L.png" alt=""></a> <a href=""><img src="<?=base_url('public/admin/')?>images/arrow_R.png" alt=""></a>
        <span><a href="">Show today</a></span>
      </h4> 
    </div>
    <div class="app_cal_body">
      <ul class="app_cal_list">
       <li><a href=""><span>00:00</span> </a></li>
       <li><a href=""><span>01:00</span> </a></li>
       <li><a href=""><span>02:00</span> </a></li>
       <li><a href=""><span>03:00</span> </a></li>
       <li><a href=""><span>04:00</span> </a></li>
       <li><a href=""><span>05:00</span> </a></li>
       <li><a href=""><span>06:00</span> </a></li>
       <li><a href=""><span>07:00</span> </a></li>
       <li><a href=""><span>08:00</span> </a></li>
       <li><a href=""><span>09:00</span> </a></li>
       <li><a href=""><span>10:00</span> </a></li>
     </ul>
   </div>

  </div>



  <div class="clearfix"></div>
  </div>
  <div class="wrapper_box">
   <div class="wrapper_head border_bottom">
    <h3>Quick Links</h3>
    <ul class="add_list no-border">

     <li class="dropdown"><a href=""><img src="<?=base_url('public/admin/')?>images/Settings_ico1.png" alt=""></a>

     </li>
   </ul>
  </div>
  <br>

  <div class="appointments_sec">

   <p>You don't have any links.</p>
   <p><a href="">Add link</a></p>


  </div>

  <div class="clearfix"></div>
  </div>

  <div class="wrapper_box">
   <div class="wrapper_head border_bottom">
    <h3>Today's summary</h3>
    <ul class="add_list no-border">

     <li class="dropdown"><a href=""><img src="<?=base_url('public/admin/')?>images/Settings_ico1.png" alt=""></a>

     </li>
   </ul>
  </div>
  <br>
  <div class="summary_table table-responsive">
    <table width="100%" border="0" cellspacing="0" cellpadding="0" class="table table-bordered">
     <thead>
      <tr>
       <th>TYPE</th>
       <th>OPEN</th>
       <th>COMPLETED</th>
     </tr>
   </thead>
   <tbody>
    <tr>
      <td>Task	</td>
      <td><a href="">0</a></td>
      <td><a href="">0</a></td>
    </tr>
    <tr>
      <td>Follow up	</td>
      <td><a href="">0</a></td>
      <td><a href="">0</a></td>
    </tr>
    <tr>
      <td>Call reminder		</td>
      <td><a href="">0</a></td>
      <td><a href="">0</a></td>
    </tr>
    <tr>
      <td>Email reminder	</td>
      <td><a href="">0</a></td>
      <td><a href="">0</a></td>
    </tr>
    <tr>
      <td>Appointment	</td>
      <td><a href="">0</a></td>
      <td><a href="">0</a></td>
    </tr>
    <tr>
      <td>Task	</td>
      <td><a href="">0</a></td>
      <td><a href="">0</a></td>
    </tr>
    <tr>
      <td>Task	</td>
      <td><a href="">0</a></td>
      <td><a href="">0</a></td>
    </tr>

  </tbody>
  </table>

  </div>


  <div class="clearfix"></div>
  </div>
  </div>


  </div>
  </div>
  </section>
  <!-- /.content -->
  </div>
  