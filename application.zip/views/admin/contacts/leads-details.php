<!-- load header -->
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper detail_page">
	<!-- Content Header (Page header) -->
	<div class="row">
		<div class="col-md-8 pad2R">
			<section class="content-header">
				<ol class="bread_crumb">
					<li><a href="#"><img src="<?=base_url('public/admin/')?>images/home_ico.png" alt=""></a></li>
          <li><a href="<?=base_url('admin/leads')?>">Leads</a></li>
          
					<li class="active"><?=$projectEmail->email?$projectEmail->email:''?></li>
				</ol>
				<ol class="breadcrumb setting_btn">
					<ul class="add_list">
						<li class=""><a href="" class="btn btn-creat"><i class="fa fa-envelope-o"></i> Email</a></li>
						<li class=""><a href="" class="btn btn-creat"><i class="fa fa-pencil"></i> Edit</a> </li>
						<li class="dropdown"><a href="" class="dropdown-toggle" type="button" data-toggle="dropdown"
								aria-haspopup="true" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
							<div class="dropdown-menu"> <a class="dropdown-item" href="#">Follow up</a> <a class="dropdown-item"
									href="#">Call reminder</a> <a class="dropdown-item" href="#">Appointment</a> </div>
						</li>
						<li class="dropdown"><a href=""><img src="<?=base_url('public/admin/')?>images/Settings_ico1.png" alt=""></a> </li>
					</ul>
				</ol>
			</section>
			<!-- Main content -->
			<section class="content leads_page">
				<!-- Small boxes (Stat box) -->
				<div class="row">
					<div class="col-md-12">
						<div class="user_detail_sec">
							<div class="user_head">
								<div class="profile_img_sec">
									<div class="profile_img"> 
                    <!-- <img src="<?=base_url('public/admin/')?>images/user2-160x160.jpg" alt=""> -->
                    <span style="font-size: 50px; margin-left: 20px; font-weight: 700; color: #3c9ad2;">
                      <?=$projectEmail->email?strtoupper(substr($projectEmail->email, 0, 1)):''?>
                    </span>
                  </div>
									<div class="badge">0</div>
                </div>
								<div class="profile_txt">
									<h3><?=$projectEmail->email?$projectEmail->email:''?> <span><img src="<?=base_url('public/admin/')?>images/fb_ico.png" alt=""></span><span><img src="<?=base_url('public/admin/')?>images/tw_ico.png"
												alt=""></span><span><img src="<?=base_url('public/admin/')?>images/in_ico.png" alt=""></span> <a href=""><i
												class="fa fa-pencil"></i></a></h3>
									<h4><?=$project[0]['company_name']?> <a href=""><i class="fa fa-pencil"></i></a></h4>
									<p><i class="fa fa-map-marker"></i> Click to add location <a href=""><i class="fa fa-pencil"></i></a>
									</p>
									<div class="tag_area"> <img src="<?=base_url('public/admin/')?>images/tag.png" alt=""> <a href="" class="btn btn-save">Cold Lead
										</a> <span>Click to add tags</span> <a href=""><i class="fa fa-pencil"></i></a> </div>
								</div>
							</div>
							<div class="user_ul_sec">
								<ul class="user_fields_list">
									<li>
										<label class="switch">
											<input type="checkbox" id="show-empty" checked>
											<span class="slider round"></span> </label>
									</li>
									<li>Hide empty fields</li>
									<li><a href=""><i class="fa fa-search" aria-hidden="true"></i></a></li>
								</ul>
							</div>
							<div class="slider_area">
								<div id="slider-carousel" class="owl-carousel">
									<div class="item">
										<div class="col-md-12">
											<div class="row">
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Emails</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" value="<?=$projectEmail->email?$projectEmail->email:''?>">
                                <!-- <span class="edit"><i class="fa fa-pencil"></i></span> -->
                               </div>
														</div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Mobile</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" value="<?=$project[0]['mobile']?$project[0]['mobile']:''?>">
                                <span class="edit"><i class="fa fa-pencil"></i></span>
                              </div>
														</div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Work</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" value="<?=$project[0]['work']?$project[0]['work']:''?>">
                                <span class="edit"><i class="fa fa-pencil"></i></span> 
                              </div>
														</div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Sales owner</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" value="<?=$project[0]['sales_user_name']?$project[0]['sales_user_name']:''?>">
                                <!-- <span class="edit"><i class="fa fa-pencil"></i></span> -->
                               </div>
														</div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Unqualified reason</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" placeholder="Not available" value="">
                                <span class="edit"><i class="fa fa-pencil"></i></span> 
                              </div>
														</div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Subscription status</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" placeholder="Not available" value="<?=$project[0]['type_name']?$project[0]['type_name']:''?>">
                                <!-- <span class="edit"><i class="fa fa-pencil"></i></span>  -->
                              </div>
														</div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Territory</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" id="country" placeholder="Not available" value="<?=$projectDetails->country?$projectDetails->country:""?>">
																<span class="edit"><i class="fa fa-pencil"></i> <i style="display: none" class="fa fa-check" data-id="country" data-column="country"></i></span> </div>
														</div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Time zone</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" placeholder="Not available" value="">
																<span class="edit"><i class="fa fa-pencil"></i></span> </div>
														</div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Other phone numbers</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" id="other_phone" placeholder="Not available" value="<?=$projectDetails->other_phone?$projectDetails->other_phone:""?>">
                                <span class="edit"><i class="fa fa-pencil"></i> <i style="display: none" class="fa fa-check" data-id="other_phone" data-column="other_phone"></i></span>
                              </div>
														</div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Address</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" id="address" placeholder="Not available" value="<?=$projectDetails->address?$projectDetails->address:""?>">
                                <span class="edit"><i class="fa fa-pencil"></i> <i style="display: none" class="fa fa-check" data-id="address" data-column="address"></i></span>
                              </div>
														</div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Zipcode</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" id="zip" placeholder="Not available" value="<?=$projectDetails->zip?$projectDetails->zip:""?>">
                                <span class="edit"><i class="fa fa-pencil"></i> <i style="display: none" class="fa fa-check" data-id="zip" data-column="zip"></i></span> </div>
                                </div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Company address</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" id="company_address" placeholder="Not available" value="<?=$projectDetails->company_address?$projectDetails->company_address:""?>">
                                <span class="edit"><i class="fa fa-pencil"></i> <i style="display: none" class="fa fa-check" data-id="company_address" data-column="company_address"></i></span>
                               </div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
									<div class="item">
										<div class="col-md-12">
											<div class="row">
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Company city</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" placeholder="Not available" value="">
																<span class="edit"><i class="fa fa-pencil"></i></span> </div>
														</div>
													</div>
												</div>

												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Company state</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" placeholder="Not available" value="">
																<span class="edit"><i class="fa fa-pencil"></i></span> </div>
														</div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Company zipcode</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" placeholder="Not available" value="">
																<span class="edit"><i class="fa fa-pencil"></i></span> </div>
														</div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Company country</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" placeholder="Not available" value="">
																<span class="edit"><i class="fa fa-pencil"></i></span> </div>
														</div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Number of employees</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" placeholder="Not available" value="">
																<span class="edit"><i class="fa fa-pencil"></i></span> </div>
														</div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Company annual revenue</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" value="$0">
																<span class="edit"><i class="fa fa-pencil"></i></span> </div>
														</div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Company website</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" placeholder="Not available" value="">
																<span class="edit"><i class="fa fa-pencil"></i></span> </div>
														</div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Company phone</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" placeholder="Not available" value="">
																<span class="edit"><i class="fa fa-pencil"></i></span> </div>
														</div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Industry type</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" placeholder="Not available" value="">
																<span class="edit"><i class="fa fa-pencil"></i></span> </div>
														</div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Business type</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" placeholder="Not available" value="">
																<span class="edit"><i class="fa fa-pencil"></i></span> </div>
														</div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Deal name</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" placeholder="Not available" value="">
																<span class="edit"><i class="fa fa-pencil"></i></span> </div>
														</div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Deal Currency</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" value="USD">
																<span class="edit"><i class="fa fa-pencil"></i></span> </div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
									<div class="item">
										<div class="col-md-12">
											<div class="row">
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Deal value</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" value="$0.00">
																<span class="edit"><i class="fa fa-pencil"></i></span> </div>
														</div>
													</div>
												</div>

												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Deal value in Base Currency</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" value="$0.00">
																<span class="edit"><i class="fa fa-pencil"></i></span> </div>
														</div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Deal expected close date
																</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" placeholder="Not available" value="">
																<span class="edit"><i class="fa fa-pencil"></i></span> </div>
														</div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Source</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" placeholder="Not available" value="">
																<span class="edit"><i class="fa fa-pencil"></i></span> </div>
														</div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Campaign
																</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" placeholder="Not available" value="">
																<span class="edit"><i class="fa fa-pencil"></i></span> </div>
														</div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Medium</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" value="$0">
																<span class="edit"><i class="fa fa-pencil"></i></span> </div>
														</div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Keyword</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" placeholder="Not available" value="">
																<span class="edit"><i class="fa fa-pencil"></i></span> </div>
														</div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Last contacted time</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" placeholder="Not available" value="">
																<span class="edit"><i class="fa fa-pencil"></i></span> </div>
														</div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Last contacted mode</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" placeholder="Not available" value="">
																<span class="edit"><i class="fa fa-pencil"></i></span> </div>
														</div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Last activity type
																</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" placeholder="Not available" value="">
																<span class="edit"><i class="fa fa-pencil"></i></span> </div>
														</div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Last activity date
																</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" placeholder="Not available" value="">
																<span class="edit"><i class="fa fa-pencil"></i></span> </div>
														</div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Active sales sequences
																</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" value="USD">
																<span class="edit"><i class="fa fa-pencil"></i></span> </div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
									<div class="item">
										<div class="col-md-12">
											<div class="row">
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Completed sales sequences
																</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" placeholder="Not available" value="" readonly>
															</div>
														</div>
													</div>
												</div>

												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Last seen
																</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" placeholder="Not available" value="" readonly>
															</div>
														</div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Recent note

																</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" placeholder="Not available" value="" readonly>
															</div>
														</div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Created by
																</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" value="User Name" readonly>
															</div>
														</div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Created at
																</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" value="19 hours ago" readonly></div>
														</div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Updated by
																</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" value="User Name" readonly>
															</div>
														</div>
													</div>
												</div>

												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Updated at</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" value="19 hours ago" readonly>
															</div>
														</div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Web forms
																</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" placeholder="Not available" value="" readonly>
															</div>
														</div>
													</div>
												</div>
												<div class="col-md-6 col-sm-6">
													<div class="form-group">
														<div class="row">
															<div class="col-md-6 col-sm-6">
																<label>Last assigned at
																</label>
															</div>
															<div class="col-md-6 col-sm-6">
																<input type="text" class="form-control" value="19 hours ago" readonly>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>

							<div class="Lead_stage_area">
                <p><i class="fa fa-calendar"></i> Lead stage changed: 19 hours ago</p>
                <?php
                  $stages = $this->common_model->select('lead_stages', ['id <='=> 5, 'status'=> 1], 'stage', 'id', 'asc');
                ?>
								<ul class="Lead_stage_list">
                  <?php
                    $stageMatched = false;
                    foreach($stages as $value){                      
                      $class = '';
                      if(!$stageMatched){
                        $class= 'active';
                        if(strtolower($value->stage) == $project[0]['stage']){                          
                          $stageMatched = true;
                        }
                      }
                      ?>
                        <li class="<?=$class?>"><a href="#" class="lead-stage" data-val="<?=strtolower($value->stage)?>"><?=$value->stage?></a></li>
                      <?php
                    }
                  ?>
									<li><a href="#" class="lead-stage" data-val="unqualified"> Unqualified </a></li>
								</ul>

							</div>
							<div class="conversations_area">
								<h4>RECENT CONVERSATIONS</h4>

								<div class="No_conversations">
									<p>No conversations found.</p>
									<p><a href="">Send an email</a> or <a href="">Add call log</a></p>
								</div>
							</div>
							<div class="activities_area">
								<h4>RECENT ACTIVITIES</h4>

								<div class="row">
									<div class="col-md-8">
										<ul class="activiti_list">
											<li>
												<a href="" class="btn btn-view activiti_li">Today</a>
											</li>
											<li><span class="star_sec"><i class="fa fa-star-o"></i></span>
												<span class="text_sec">
													<p>Lead unsubscribed</p>
													<p><small><i class="fa fa-shopping-bag"></i> Sudhir Biswas <i class="fa fa-circle"></i> 19
															hours ago</small></p>

												</span>
											</li>
											<li><span class="star_sec"><i class="fa fa-star-o"></i></span>
												<span class="text_sec">
													<p>Lead unsubscribed</p>
													<p><small><i class="fa fa-shopping-bag"></i> Sudhir Biswas <i class="fa fa-circle"></i> 19
															hours ago</small></p>

												</span>
											</li>
											<li><span class="star_sec"><i class="fa fa-star-o"></i></span>
												<span class="text_sec">
													<p>Lead unsubscribed</p>
													<p><small><i class="fa fa-shopping-bag"></i> Sudhir Biswas <i class="fa fa-circle"></i> 19
															hours ago</small></p>

												</span>
											</li>

											<li><a href="" class="btn btn-view activiti_li">View all</a></li>

										</ul>
									</div>
									<div class="col-md-4">
										<div class="score_area">
											<p>SCORE</p>
											<div class="score_txt">0</div>
											<p><small>Last seen:</small></p>
											<p><small>---</small></p>
											<p><small>Last contacted:</small></p>
											<p><small>---</small></p>
											<p><small>Last modified:</small></p>
											<p><small>19 hours ago</small></p>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
			<!-- /.content -->
		</div>
		<div class="col-md-4 right_panel_sec">
			<div class="row">
				<div class="convert_sec">
					<div class="wrapper_box">

						<p>Convert this lead into a contact?</p>
						<ul class="add_list">
							<li class=""><a href="" class="btn btn-save"> Convert</a></li>

							<li class="dropdown"><a href="" class="dropdown-toggle" type="button" data-toggle="dropdown"
									aria-haspopup="true" aria-expanded="false"><img src="<?=base_url('public/admin/')?>images/convert_list_img1.png" alt=""> Add task
									<i class="fa fa-caret-down"></i></a>
								<div class="dropdown-menu"> <a class="dropdown-item" href="#">Appointments</a> <a class="dropdown-item"
										href="#">Add call log</a> <a class="dropdown-item" href="#">SMS</a> </div>
							</li>

						</ul>


						<div class="clearfix"></div>
					</div>

					<div class="wrapper_box">
						<div class="wrapper_head border_bottom">
							<h3>NOTES</h3>
							<ul class="add_list no-border">

								<li class="dropdown"><a href=""><img src="<?=base_url('public/admin/')?>images/convert_list_img7.png" alt=""></a>

								</li>
							</ul>
						</div>
						<br>
						<div class="summary_table">
							<textarea name="" id="" cols="" rows="5" placeholder="Start typing..." class="form-control"></textarea>

						</div>


						<div class="clearfix"></div>
					</div>
					<div class="wrapper_box">
						<div class="wrapper_head border_bottom">
							<h3>REMINDERS
							</h3>
							<ul class="add_list no-border">

								<li class="dropdown"><a href=""><img src="<?=base_url('public/admin/')?>images/convert_list_img7.png" alt=""></a>

								</li>
							</ul>
						</div>
						<br>
						<div class="summary_table">

							<p class="text-center">No reminders found.
							</p>

						</div>


						<div class="clearfix"></div>
					</div>



				</div>
				<div class="convert_list_sec">
					<ul class="convert_list">
						<li><a href=""><img src="<?=base_url('public/admin/')?>images/convert_list_img.png" alt=""></a></li>
						<li><a href=""><img src="<?=base_url('public/admin/')?>images/convert_list_img1.png" alt=""></a></li>
						<li><a href=""><img src="<?=base_url('public/admin/')?>images/convert_list_img2.png" alt=""></a></li>
						<li><a href=""><img src="<?=base_url('public/admin/')?>images/convert_list_img3.png" alt=""></a></li>
						<li><a href=""><img src="<?=base_url('public/admin/')?>images/convert_list_img4.png" alt=""></a></li>
						<li><a href=""><img src="<?=base_url('public/admin/')?>images/convert_list_img5.png" alt=""></a></li>
						<li><a href=""><img src="<?=base_url('public/admin/')?>images/convert_list_img6.png" alt=""></a></li>
						<li><a href=""><img src="<?=base_url('public/admin/')?>images/convert_list_img7.png" alt=""></a></li>

					</ul>
				</div>
			</div>

		</div>
	</div>
</div>
<!-- /.content-wrapper -->
<!-- <footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 2.4.0
    </div>
    Copyright &copy; 2014-2016  All rights
    reserved.
  </footer>-->

<!-- Control Sidebar -->

<!-- /.control-sidebar -->
<!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
<div class="control-sidebar-bg"></div>

<!-- Modal -->
<div class="modal fade" id="ImportsModal" tabindex="-1" role="dialog" aria-labelledby="">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
						aria-hidden="true">&times;</span></button>
				<h4 class="modal-title" id="">IMPORT CONTACTS <span class="step_btn btn">Step 1 of 2</span></h4>
			</div>
			<div class="modal-body">
				<form action="" class="row">
					<div class="col-md-12">
						<p>Import your contacts using your own file, or use our <a href="">sample CSV</a>. <i
								class="fa fa-question-circle-o"></i> </p>
					</div>
					<div class="col-md-12">
						<div class="form-group">
							<div class="drag_sec">
								<div class="choose-file">
									<input type="file">
									<label><span class="img_sec"><img src="<?=base_url('public/admin/')?>images/csv_img.png" alt=""></span> Drop or upload your file
										here</label>
									<p>(.csv, .xlsx formats supported)</p>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-12">
						<div class="form-group">
							<label>Select an import option for this file</label>
							<select name="" id="" class="form-control">
								<option value="">Create new contacts</option>
								<option value="">Create new and update existing contacts (without overwrite)</option>
								<option value="">Create new and update existing contacts (with overwrite)</option>
							</select>
						</div>
					</div>
					<div class="col-md-12">
						<div class="form-group">
							<input type="checkbox" id="Skip">
							<label for="Skip">Skip duplicates automatically by matching <span>Primary email <i
										class="fa fa-caret-down"></i></span></label>
						</div>
					</div>
					<div class="col-md-12">
						<div class="form-group"> <a href="javascript:void(0)" class="show_more1">Manage email subscriptions <i
									class="fa fa-caret-down"></i></a> <span class="more_checkbox1">
								<div class="form-group">
									<input type="checkbox" id="Subscribe">
									<label for="Subscribe">Subscribe contacts to all types of emails</label>
								</div>
							</span> </div>
					</div>
					<div class="col-md-12">
						<div class="form-group"> <a href="javascript:void(0)" class="show_more2">Manage sales owner <i
									class="fa fa-caret-down"></i></a> <span class="more_checkbox2">
								<div class="form-group">
									<select id="single3" class="js-states form-control">
										<option>Sales Owner</option>
										<option>Sales Owner1</option>
										<option>Sales Owner2</option>
										<option>Sales Owner3</option>
									</select>
								</div>
							</span> </div>
					</div>
				</form>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-creat " data-dismiss="modal">Close</button>
				<button type="button" class="btn btn-save" data-dismiss="modal" data-toggle="modal"
					data-target="#ImportsModal1">Next</button>
			</div>
		</div>
	</div>
</div>

<!-- Modal -->
<div class="modal fade" id="ImportsModal1" tabindex="-1" role="dialog" aria-labelledby="">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
						aria-hidden="true">&times;</span></button>
				<h4 class="modal-title" id="">IMPORT CONTACTS <span class="step_btn btn">Step 2 of 2</span></h4>
			</div>
			<div class="modal-body">
				<form action="" class="row">
					<div class="col-md-12">
						<p>Map columns in your file to fields in Freshsales. </p>
						<hr>
					</div>
					<div class="col-md-6">
						<label><i class="fa fa-file-text-o"></i> FILE COLUMN </label>
					</div>
					<div class="col-md-6">
						<label>FRESHSALES FIELD</label>
					</div>
					<div class="col-md-12">
						<hr>
					</div>
					<div class="col-md-6">
						<p>dfsfsf</p>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<div class="form-group">
								<select id="single4" class="js-states form-control">
									<option>Choose a value</option>
									<option>Choose a value1</option>
									<option>Choose a value2</option>
									<option>Choose a value3</option>
								</select>
							</div>
						</div>
					</div>
				</form>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-creat " data-dismiss="modal" data-toggle="modal"
					data-target="#ImportsModal">Back</button>
				<button type="button" class="btn btn-save">Import</button>
			</div>
		</div>
	</div>
</div>
<!-- footer section -->
<style>
.fa.fa-pencil{
  cursor: pointer;
}
.custom-text{
    border: 1px solid #2196f3 !important;
    background: #fff !important;
}
  </style>
<script type="text/javascript" src="<?=base_url('public/admin/')?>js/theme.js"></script>
<script>
  $(document).ready(function(){
    /*
      ** enable and disabled empty fields
      ** Chayan
    */
    $('#show-empty').on('click', function(){
      let isChecked = $(this). prop("checked");
      $('input.form-control').each(function(key, val){
        if($(this).val()==""){
          if(isChecked == true){
            let x = $(this).parents('.form-group'); //.show();
            x.parent('.col-md-6.col-sm-6').show();
          }else{
            let x= $(this).parents('.form-group'); //.hide();
            x.parent('.col-md-6.col-sm-6').hide();
          }
        }        
      })      
    })
    // End


    $('.lead-stage').on('click', function(){
      console.log($(this).parent('li').hasClass('active'));
      if($(this).parent('li').hasClass('active')){
        swalAlert('You are already confirmed this stage', 'warning');
        return false;
      }
      let stage = $(this).data('val');

      Swal.fire({
				html: '<img src="'+logo_url+'public/admin/images/logo.png" alt="no-image">',
				title: "Are you sure to update lead stage ?",
				type: "warning",
				showCancelButton: true, // true or false  
				confirmButtonColor: "#dd6b55",
				cancelButtonColor: "#48cab2",
				confirmButtonText: "Yes !!!", 
			}).then((result) => {
				if (result.value) {
					$.ajax({
						type: "POST",
						url: base_url+'leads/update-status',
						data: {
							id: "<?=$project[0]['lead_id']?>",
              status: $(this).data('val'),
              'column': 'stage'
						},
						success: function(response) {
							if(response.status.error_code == 0){
								//populate all required fields
                swalAlert(response.status.message, 'success');
                location.reload();
							}else{
								swalAlert(response.status.message, 'warning');
							}
						},
						error: function(response){
							swalAlert('Something wrong, try again', 'warning');
						} 
					});
				}
			});	
    })

    /**
     * Update details column value
     */
    $('.edit').on('click', function(){
      $(this).parent('.col-md-6').find('.fa-pencil').hide();
      $(this).parent('.col-md-6').find('.fa-check').show();

      $(this).parent('.col-md-6').find('input').addClass('custom-text');
      //$(this).closest('.update').show();
    })
    $('.fa.fa-check').on('click', function(){
      let xx = $(this);
      if($('#'+$(this).data('id')).val().trim() == ""){
        return false;
      }
      $.ajax({
						type: "POST",
						url: base_url+'leads/update-lead-details',
						data: {
							id: "<?=$project[0]['lead_id']?>",
              status: $(this).data('val'),
              'column': $(this).data('column'),
              'value': $('#'+$(this).data('id')).val()
						},
						success: function(response) {
							if(response.status.error_code == 0){
                xx.parent('.edit').find('.fa-check').hide();
                xx.parent('.edit').find('.fa-pencil').show();
                xx.parents('.col-md-6').find('input').removeClass('custom-text');
							}else{
								//swalAlert(response.status.message, 'warning');
							}
						},
						error: function(response){
							swalAlert('Something wrong, try again', 'warning');
						} 
					});
    })
  })
	$('.right_panel').slimscroll({
		height: '544px',
		color: '#e12f36',
		size: '5px'

	});

</script>
<script>
	$('.app_cal_body').slimscroll({
		height: '300px',
		color: '#e12f36',
		size: '5px'

	});

	$('.user_detail_sec').slimscroll({
		height: '600px',
		color: '#e12f36',
		size: '5px'

	});

</script>
<script>
	$(document).ready(function () {
		$('#leads_table').DataTable({
			"paging": false,
			"searching": false
		});
	});

</script>
