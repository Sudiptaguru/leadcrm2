<!-- Load header -->
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
	<!-- Content Header (Page header) -->
	<section class="content-header">
        <ol class="bread_crumb">
          <li><a href="#"><img src="images/home_ico.png" alt=""></a></li>
          <li><a href="#">Contacts</a></li>
          <!-- <li class="active">My Contacts (1)</li> -->

        </ol>

        <ol class="breadcrumb setting_btn">
          <ul class="add_list">

            <li class=""><a href="javascript:void(0);" class="btn btn-creat" data-toggle="modal"
                data-target="#ImportsModal">Import Contacts <i class="fa fa-caret-down"></i></a>

            </li>
			<li>
            	<a href="#" class="btn btn-creat" data-toggle="modal" data-target="#ceartModal" id="add-contact-modal">Add Contact <i class="fa fa-plus" aria-hidden="true"></i></a>
			</li>
          </ul>
        </ol>
      </section>

	<!-- Main content -->
	<section class="content leads_page">
		<!-- Small boxes (Stat box) -->
		<div class="row">
			<div class="col-md-12">
				<div class="table-responsive">
					<table width="100%" border="0" cellspacing="0" cellpadding="0" class="table" id="leads_table">
						<thead>
							<tr>
								<th><input type="checkbox"></th>
								<th>Name</th>
								<th>Score</th>
								<th>Open deals amount</th>
								<th>Last contacted time</th>
								<th>Sales owner</th>
								<th>Emails</th>
								<th>Work</th>
								<th>Actions</th>
							</tr>
						</thead>
						</thead>
						<tbody>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</section>
	<!-- /.content -->
</div>

<!-- Modal -->
<div class="modal fade" id="ImportsModal" tabindex="-1" role="dialog" aria-labelledby="">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
						aria-hidden="true">&times;</span></button>
				<h4 class="modal-title" id="">IMPORT CONTACTS
					<span class="step_btn btn">Step 1 of 2</span></h4>

			</div>
			<div class="modal-body">
				<form action="" class="row">
					<div class="col-md-12">
						<p>Import your contacts using your own file, or use our <a href="">sample CSV</a>. <i
								class="fa fa-question-circle-o"></i> </p>
					</div>

					<div class="col-md-12">
						<div class="form-group">
							<div class="drag_sec">
								<div class="choose-file">
									<input type="file">
									<label><span class="img_sec"><img src="./images/csv_img.png" alt=""></span> Drop or upload your file
										here</label>
									<p>(.csv, .xlsx formats supported)</p>
								</div>
							</div>
						</div>
					</div>

					<div class="col-md-12">
						<div class="form-group">
							<label>Select an import option for this file</label>
							<select name="" id="" class="form-control">
								<option value="">Create new contacts</option>
								<option value="">Create new and update existing contacts (without overwrite)</option>
								<option value="">Create new and update existing contacts (with overwrite)</option>
							</select>
						</div>
					</div>
					<div class="col-md-12">

						<div class="form-group">
							<input type="checkbox" id="Skip"> <label for="Skip">Skip duplicates automatically by matching
								<span>Primary email <i class="fa fa-caret-down"></i></span></label>
						</div>

					</div>

					<div class="col-md-12">

						<div class="form-group">
							<a href="javascript:void(0)" class="show_more1">Manage email subscriptions <i
									class="fa fa-caret-down"></i></a>
							<span class="more_checkbox1">
								<div class="form-group">
									<input type="checkbox" id="Subscribe"> <label for="Subscribe">Subscribe contacts to all types of
										emails</label>
								</div>

							</span>
						</div>

					</div>
					<div class="col-md-12">

						<div class="form-group">
							<a href="javascript:void(0)" class="show_more2">Manage sales owner <i class="fa fa-caret-down"></i></a>
							<span class="more_checkbox2">
								<div class="form-group">
									<select id="single3" class="js-states form-control">
										<option>Sales Owner</option>
										<option>Sales Owner1</option>
										<option>Sales Owner2</option>
										<option>Sales Owner3</option>
									</select>
								</div>
							</span>
						</div>
					</div>
				</form>
			</div>
			<div class="modal-footer">

				<button type="button" class="btn btn-creat " data-dismiss="modal">Close</button>
				<button type="button" class="btn btn-save" data-dismiss="modal" data-toggle="modal"
					data-target="#ImportsModal1">Next</button>
			</div>
		</div>
	</div>
</div>

<!-- Modal -->
<div class="modal fade" id="ImportsModal1" tabindex="-1" role="dialog" aria-labelledby="">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
						aria-hidden="true">&times;</span></button>
				<h4 class="modal-title" id="">IMPORT CONTACTS
					<span class="step_btn btn">Step 2 of 2</span></h4>

			</div>
			<div class="modal-body">
				<form action="" class="row">
					<div class="col-md-12">
						<p>Map columns in your file to fields in Freshsales. </p>
						<hr>
					</div>

					<div class="col-md-6">
						<label><i class="fa fa-file-text-o"></i> FILE COLUMN </label>
					</div>
					<div class="col-md-6">
						<label>FRESHSALES FIELD</label>
					</div>
					<div class="col-md-12">
						<hr>
					</div>
					<div class="col-md-6">
						<p>dfsfsf</p>
					</div>
					<div class="col-md-6">

						<div class="form-group">
							<div class="form-group">
								<select id="single4" class="js-states form-control">
									<option>Choose a value</option>
									<option>Choose a value1</option>
									<option>Choose a value2</option>
									<option>Choose a value3</option>
								</select>
							</div>
						</div>

					</div>
				</form>
			</div>
			<div class="modal-footer">

				<button type="button" class="btn btn-creat " data-dismiss="modal" data-toggle="modal"
					data-target="#ImportsModal">Back</button>
				<button type="button" class="btn btn-save">Import</button>
			</div>
		</div>
	</div>
</div>

<!-- Add leade modal -->
<!-- Modal -->
<div class="modal fade" id="ceartModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
						aria-hidden="true">&times;</span></button>
				<h4 class="modal-title" id="myModalLabel">Add Contact</h4>
			</div>
			<form id="frm-lead" method="post" action="" class="row">
				<div class="modal-body">
					<div class="col-md-12">
						<div class="form-group">
							<label>Full Name</label>
							<input type="text" class="form-control" name="full_name" id="full_name" placeholder="Full Name" required>
						</div>
					</div>
					<div class="col-md-12">
						<div class="form-group">
							<label>Score</label>
							<input type="text" class="form-control" name="score" id="score" placeholder="Score" required>
						</div>
					</div>
					<div class="col-md-12">
						<div class="form-group">
							<label>Deal amount</label>
							<input type="number" min="1" class="form-control" name="deal_amount" id="deal_amount" placeholder="Deal amount" required>
						</div>
					</div>
					<div class="col-md-12">
						<div class="row app_mail">
							<div class="form-group register_email">
								<div class="col-md-12">
									<label>Email</label>
									<input type="email" class="form-control default" name="email" id="email" placeholder="Enter Value" required>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-12">
						<div class="form-group">
							<label>Work</label>
							<input type="text" class="form-control" id="work" name="work" placeholder="Work" required>
						</div>
					</div>
					<div class="col-md-12">
						<div class="form-group">
							<label>Sales Owner</label>
							<select id="sales_owner" name="sales_owner" class="js-states form-control users-list" required>
								<option>Sales Owner</option>
							</select>
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<div class="col-md-12">
						<div class="form-group">
							<input type="hidden" id="contact_id" name="contact_id" value="">
							<input type="hidden" id="cloneStatus" name="cloneStatus" value="">
							<!-- <button type="button" class="btn btn-creat pull-left"><i class="fa fa-pencil"></i> Customize fields</button> -->
							<button type="button" class="btn btn-creat " id="btn-close-contact" data-dismiss="modal">Close</button>
							<button type="submit" class="btn btn-save" id="btn-add-contact">Save 			
							</button>
							<button class="buttonload" style="display: none">
								<i class="fa fa-refresh fa-spin"></i> Loading
							</button>
						</div>
					</div>
				</div>			
			</form>
		</div>
	</div>
</div>
<style>
	/* Style buttons */
.buttonload {
	padding: 8px 13px;
    border: #16364d 1px solid;
    display: inline-block;
    font-size: 13px;
    color: #fff;
    background: #16364d;
}

	.company-title span {
		color: #3c8dbc;
		font-size: 15px;
		font-weight: 600;
		margin-bottom: 0px;
	}

	.company-title {
		color: #000;
	}
	label.error{
		/* background: #f00; */
		color: #f00;
		padding: 3px 5px;
		margin-top: 2px;
		border-radius: 5px;
	}
	.form-control.error{
		border: 1px solid #f00;
		/* background: #fff; */
	}

</style>
<script>
	adminPage = 'leadList';
	var table = '';
	$(document).ready(function () {
		var now = new Date();
		var date = now.getFullYear() + "-" + now.getMonth() + "-" + now.getDate();
		table = $('#leads_table').DataTable({

			"processing": true, //Feature control the processing indicator.
			"serverSide": true, //Feature control DataTables' server-side processing mode.
			"order": [], //Initial no order.

			// Load data for the table's content from an Ajax source
			"ajax": {
				"url": "<?php echo site_url('admin/contacts/all_content_list')?>",
				"type": "POST",
				"data": function (args) {
					args.start_date = '',
						args.end_date = ''
				}
			},

			//Set column definition initialisation properties.
			"columnDefs": [{
				"targets": 'no-sort',
				"orderable": false, //set not orderable
			}, ],
			rowReorder: {
				selector: 'td:nth-child(2)'
			},
			//responsive: true,
			scrollX: true,
			dom: 'Bfrtip',
			buttons: [{
					extend: 'excel',
					filename: 'leads_list_' + date,
					className: "btn btn-round_small btn-img",
					text: '<i class="fa fa-file-excel-o" aria-hidden="true"></i> Export',
					tag: 'span',
					exportOptions: {
						columns: [0, 1, 2, 3, 4, 5, 6, 7]
					}
				}
				//'excel'
			]
		});
		
		$(document).on('click', '#delete.action', function () {
			var id = $(this).data('id');
			Swal.fire({
				html: '<img src="'+logo_url+'public/admin/images/logo.png" alt="no-image">',
				title: "Are you sure want to delete ?",
				type: "warning",
				showCancelButton: true, // true or false  
				confirmButtonColor: "#dd6b55",
				cancelButtonColor: "#48cab2",
				confirmButtonText: "Yes !!!", 
			}).then((result) => {
				if (result.value) {
					$.ajax({
						type: "POST",
						url: base_url+'leads/update-status',
						data: {
							id: id,
							status: 3,
							'column': 'status'
						},
						success: function(response) {
							if(response.status.error_code == 0){
								//populate all required fields
								swalAlert(response.status.message, 'success');
								table.draw();
							}else{
								swalAlert(response.status.message, 'warning');
							}
						},
						error: function(response){
							swalAlert('Something wrong, try again', 'warning');
						} 
					});
				}
			});			
		});
		$('.datepicker').datepicker({
			maxDate: '0',
			format: 'yyyy-mm-dd',
			setDate: new Date()
		});
		//$('.js-example-basic-single').select2({});
	});

	//perform reset modal
	$('#add-lead-modal').on('click', function(){

	})
	// Submit lead add form
	// validate signup form on keyup and submit
	var validator = $("#frm-lead").validate({
			rules: {
				full_name: "required",
				score: "required",
				deal_amount: "required",
				email: {
					required: true,
					email: true
				},				
				work: "required",
				sales_owner: "required",
			},
			messages: {
				full_name: "Please enter your Name",
				deal_amount: "Please enter Deal amount",
				email: "Please enter a valid email address",
				score: "Please enter Score",
				work: "Please enter work for",
				sales_owner: "Please select sales owner",
			},
			submitHandler: function(form) {
				$.ajax({
					url: base_url+'contacts/store',
					type: 'POST',
					data: $(form).serialize(),
					beforeSend: function() {
						$("#btn-add-contact").hide();
						$(".buttonload").show();	
					},
					success: function(response) {
						console.log(response)
						$(".buttonload").hide();						
						$("#btn-add-contact").show();
						console.log(response.status.error_code);
						if(response.status.error_code == 0){
							resetApplicationForm();							
							$("#btn-close-contact").click();
							swalAlert(response.status.message, 'success');
							//draw table with updated rows
							table.draw();
						}else{
							swalAlert(response.status.message, 'warning');
						}
					},
					error: function(response){
						$(".buttonload").hide();						
						$("#btn-add-contact").show();
						swalAlert('Something wrong, try again', 'warning');
					}           
				});
			}
	});
	function resetApplicationForm(){
		validator.resetForm();
	}

	$('#btn-close-lead').click(function(){
		$('.modal-title').text('Add Lead');
	})

	$(document).on('click', '#edit.action', function(){
		let id = $(this).data('id');
		$.ajax({
				url: base_url+'contacts/get',
				type: 'GET',
				data: {
					id: id
				},
				beforeSend: function() {
					
				},
				success: function(response) {
					if(response.status.error_code == 0){
						//populate all required fields
						populateLeadInfo(response.result.data, cloneStatus = false);
						$('.modal-title').text('Edit Contact');
						$('#ceartModal').modal('show');
					}else{
						swalAlert(response.status.message, 'warning');
					}
				},
				error: function(response){
					swalAlert('Something wrong, try again', 'warning');
				}           
			});
	})

	$(document).on('click', '#clone.action', function(){
		let id = $(this).data('id');
		$.ajax({
				url: base_url+'leads/get-lead',
				type: 'GET',
				data: {
					id: id
				},
				beforeSend: function() {
					
				},
				success: function(response) {
					if(response.status.error_code == 0){
						//populate all required fields
						populateLeadInfo(response.result.data, cloneStatus = true);

						$('#cloneStatus').val('1');
						$('.modal-title').text('Clone Lead');
						$('#ceartModal').modal('show');
					}else{
						swalAlert(response.status.message, 'warning');
					}
				},
				error: function(response){
					swalAlert('Something wrong, try again', 'warning');
				}           
			});
	})

	function populateLeadInfo(d = null, cloneStatus){
		let data = d['data'][0];
		let emails = d['email'];
		console.log(cloneStatus)
		if(cloneStatus != true){
			$('#contact_id').val(data.contact_id);
		}else{
			$('#contact_id').val('');
		}
		$('#full_name').val(data.contact_name);
		$('#email').val(data.email);
		$('#score').val(data.score);
		$('#work').val(data.work);
		$('#deal_amount').val(data.open_deal_amount);
		$('#sales_owner option[value="'+data.sale_owner+'"]').attr("selected", "selected");
	}
</script>
