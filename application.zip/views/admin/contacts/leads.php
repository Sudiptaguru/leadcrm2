<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Freshsale</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <!-- Select2 CSS -->
    <link href="css/select2.min.css" rel="stylesheet" />
  <!-- Font Awesome -->
  <link rel="stylesheet" href="css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="css/AdminLTE.min.css">
  <!-- AdminLTE Skins. We have chosen the skin-blue for this starter
        page. However, you can choose any other skin. Make sure you
        apply the skin class to the body tag so the changes take effect. -->
  <link rel="stylesheet" href="css/skin-blue.min.css">
  
  <link rel="stylesheet" href="css/custom.css">
  <link rel="stylesheet" href="css/responsive.css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">

</head>
<body class="hold-transition skin-blue sidebar-mini sidebar-collapse">
<div class="wrapper">

  <header class="main-header">
    <!-- Logo -->
    <a href="index2.html" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><img src="./images/logo.png" alt=""></span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg"><img src="./images/logo.png" alt=""></span>
    </a>
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
     
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>
      
      <div class="search_sec">
      	<div class="input-group">
                <div class="input-group-btn search-panel">
                    <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown">
                    	<span id="search_concept"><i class="fa fa-search"></i></span> <span class="caret"></span>
                    </button>
                    <ul class="dropdown-menu" role="menu">
                      <li><a href=""><i class="fa fa-search"></i> All</a></li>
                      <li><a href=""><img src="./images/Leads_ico1.png" alt=""> Leads</a></li>
                      <li><a href=""><img src="./images/Contacts_ico1.png" alt=""> Contact</a></li>
                      <li><a href=""><img src="./images/Accounts_ico1.png" alt=""> Accounts</a></li>
                      <li><a href=""><img src="./images/Deals_ico1.png" alt=""> Deals</a></li>
                      <li><a href=""><img src="./images/Reports_ico1.png" alt=""> Reports</a></li>
                      
                    </ul>
                </div>
                <!--<input type="hidden" name="search_param" value="all" id="search_param">-->         
                <input type="text" class="form-control" name="x" placeholder="Search by lead, contact, account, deal, report">
                <!--<span class="input-group-btn">
                    <button class="btn btn-default" type="button"></button>
                </span>-->
            </div>
      </div>


      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
          <!-- Messages: style can be found in dropdown.less-->
          <li><a href="">20 days free trial</a></li>
          <li><a href=""><span class="btn btn-upgrade">Upgrade</span></a></li>
          <li class="dropdown messages-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
             <img src="images/plush.png" alt="">
            </a>
            <ul class="dropdown-menu">
              <li class="header">You have 4 messages</li>
              <li>
                <!-- inner menu: contains the actual data -->
                <ul class="menu">
                  <li><!-- start message -->
                    <a href="#">
                      <div class="pull-left">
                        <img src="dist/img/user2-160x160.jpg" class="img-circle" alt="User Image">
                      </div>
                      <h4>
                        Support Team
                        <small><i class="fa fa-clock-o"></i> 5 mins</small>
                      </h4>
                      <p>Why not buy a new awesome theme?</p>
                    </a>
                  </li>
                  <!-- end message -->
                  <li>
                    <a href="#">
                      <div class="pull-left">
                        <img src="dist/img/user3-128x128.jpg" class="img-circle" alt="User Image">
                      </div>
                      <h4>
                        AdminLTE Design Team
                        <small><i class="fa fa-clock-o"></i> 2 hours</small>
                      </h4>
                      <p>Why not buy a new awesome theme?</p>
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <div class="pull-left">
                        <img src="dist/img/user4-128x128.jpg" class="img-circle" alt="User Image">
                      </div>
                      <h4>
                        Developers
                        <small><i class="fa fa-clock-o"></i> Today</small>
                      </h4>
                      <p>Why not buy a new awesome theme?</p>
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <div class="pull-left">
                        <img src="dist/img/user3-128x128.jpg" class="img-circle" alt="User Image">
                      </div>
                      <h4>
                        Sales Department
                        <small><i class="fa fa-clock-o"></i> Yesterday</small>
                      </h4>
                      <p>Why not buy a new awesome theme?</p>
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <div class="pull-left">
                        <img src="dist/img/user4-128x128.jpg" class="img-circle" alt="User Image">
                      </div>
                      <h4>
                        Reviewers
                        <small><i class="fa fa-clock-o"></i> 2 days</small>
                      </h4>
                      <p>Why not buy a new awesome theme?</p>
                    </a>
                  </li>
                </ul>
              </li>
              <li class="footer"><a href="#">See All Messages</a></li>
            </ul>
          </li>
          <!-- Notifications: style can be found in dropdown.less -->
          <li class="dropdown notifications-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
             	<img src="./images/mail_ico3.png" alt="">
            </a>
            <ul class="dropdown-menu">
              <li class="header">You have 10 notifications</li>
              <li>
                <!-- inner menu: contains the actual data -->
                <ul class="menu">
                  <li>
                    <a href="#">
                      <i class="fa fa-users text-aqua"></i> 5 new members joined today
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <i class="fa fa-warning text-yellow"></i> Very long description here that may not fit into the
                      page and may cause design problems
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <i class="fa fa-users text-red"></i> 5 new members joined
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <i class="fa fa-shopping-cart text-green"></i> 25 sales made
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <i class="fa fa-user text-red"></i> You changed your username
                    </a>
                  </li>
                </ul>
              </li>
              <li class="footer"><a href="#">View all</a></li>
            </ul>
          </li>
          <!-- Tasks: style can be found in dropdown.less -->
          <li class="dropdown tasks-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <img src="images/roket.png" alt="" style="
    margin-top: 1px;
">
            </a>
            <ul class="dropdown-menu">
              <li class="header">You have 9 tasks</li>
              <li>
                <!-- inner menu: contains the actual data -->
                <ul class="menu">
                  <li><!-- Task item -->
                    <a href="#">
                      <h3>
                        Design some buttons
                        <small class="pull-right">20%</small>
                      </h3>
                      <div class="progress xs">
                        <div class="progress-bar progress-bar-aqua" style="width: 20%" role="progressbar"
                             aria-valuenow="20" aria-valuemin="0" aria-valuemax="100">
                          <span class="sr-only">20% Complete</span>
                        </div>
                      </div>
                    </a>
                  </li>
                  <!-- end task item -->
                  <li><!-- Task item -->
                    <a href="#">
                      <h3>
                        Create a nice theme
                        <small class="pull-right">40%</small>
                      </h3>
                      <div class="progress xs">
                        <div class="progress-bar progress-bar-green" style="width: 40%" role="progressbar"
                             aria-valuenow="20" aria-valuemin="0" aria-valuemax="100">
                          <span class="sr-only">40% Complete</span>
                        </div>
                      </div>
                    </a>
                  </li>
                  <!-- end task item -->
                  <li><!-- Task item -->
                    <a href="#">
                      <h3>
                        Some task I need to do
                        <small class="pull-right">60%</small>
                      </h3>
                      <div class="progress xs">
                        <div class="progress-bar progress-bar-red" style="width: 60%" role="progressbar"
                             aria-valuenow="20" aria-valuemin="0" aria-valuemax="100">
                          <span class="sr-only">60% Complete</span>
                        </div>
                      </div>
                    </a>
                  </li>
                  <!-- end task item -->
                  <li><!-- Task item -->
                    <a href="#">
                      <h3>
                        Make beautiful transitions
                        <small class="pull-right">80%</small>
                      </h3>
                      <div class="progress xs">
                        <div class="progress-bar progress-bar-yellow" style="width: 80%" role="progressbar"
                             aria-valuenow="20" aria-valuemin="0" aria-valuemax="100">
                          <span class="sr-only">80% Complete</span>
                        </div>
                      </div>
                    </a>
                  </li>
                  <!-- end task item -->
                </ul>
              </li>
              <li class="footer">
                <a href="#">View all tasks</a>
              </li>
            </ul>
          </li>
          <!-- User Account: style can be found in dropdown.less -->
          <li class="dropdown user user-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <img src="./images/user_icon1.png" class="user-image" alt="User Image">
              <!--<span class="hidden-xs">Alexander Pierce</span>-->
            </a>
            <ul class="dropdown-menu">
              <!-- User image -->
              <li class="user-header">
                <img src="dist/img/user2-160x160.jpg" class="img-circle" alt="User Image">

                <p>
                  Alexander Pierce - Web Developer
                  <small>Member since Nov. 2012</small>
                </p>
              </li>
              <!-- Menu Body -->
              <li class="user-body">
                <div class="row">
                  <div class="col-xs-4 text-center">
                    <a href="#">Followers</a>
                  </div>
                  <div class="col-xs-4 text-center">
                    <a href="#">Sales</a>
                  </div>
                  <div class="col-xs-4 text-center">
                    <a href="#">Friends</a>
                  </div>
                </div>
                <!-- /.row -->
              </li>
              <!-- Menu Footer-->
              <li class="user-footer">
                <div class="pull-left">
                  <a href="#" class="btn btn-default btn-flat">Profile</a>
                </div>
                <div class="pull-right">
                  <a href="#" class="btn btn-default btn-flat">Sign out</a>
                </div>
              </li>
            </ul>
          </li>
          <!-- Control Sidebar Toggle Button -->
         <!-- <li>
            <a href="#" data-toggle="control-sidebar"><i class="fa fa-gears"></i></a>
          </li>-->
        </ul>
      </div>
    </nav>
  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      
      <!-- search form -->
      <form action="#" method="get" class="sidebar-form">
        <div class="input-group">
          <input type="text" name="q" class="form-control" placeholder="Search...">
          <span class="input-group-btn">
                <button type="submit" name="search" id="search-btn" class="btn btn-flat"><i class="fa fa-search"></i>
                </button>
              </span>
        </div>
      </form>
      <!-- /.search form -->
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu" data-widget="tree">
        <!--<li class="header">MAIN NAVIGATION</li>-->
        <li><a href="dashboard.html"><img src="./images/dash_ico.png" alt=""> <span>Activities Dashboard</span></a></li>
        <li><a href="leads.html"><img src="./images/Leads_ico.png" alt=""> <span>Leads</span></a></li>
        <li><a href="#"><img src="./images/Contacts_ico.png" alt=""> <span>Contacts</span></a></li>
        <li><a href="#"><img src="./images/Accounts_ico.png" alt=""> <span>Accounts</span></a></li>
        <li><a href="#"><img src="./images/Deals_ico.png" alt=""> <span>Deals</span></a></li>
        
        <li class="treeview">
          <a href="#">
            <img src="./images/Conversations_ico.png" alt=""> <span>Conversations</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li class=""><a href=""><img src="./images/mail_ico.png" alt=""> Email</a></li>
<li class=""><a href=""><img src="./images/mail_ico1.png" alt=""> Email Templates</a></li>
<li class=""><a href=""><img src="./images/target_ico.png" alt=""> Sales Sequences</a></li>
<li class=""><a href=""><img src="./images/mail_ico2.png" alt=""> Bulk Email</a></li>
<li class=""><a href=""><img src="./images/phone_ico1.png" alt=""> Phone</a></li>
<li class=""><a href=""><img src="./images/sms_ico.png" alt=""> Sms</a></li>
            
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <img src="./images/Reports_ico.png" alt=""> <span>Reports</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li class=""><a href=""><img src="./images/Reports_ico.png" alt=""> Reports</a></li>
<li class=""><a href=""><img src="./images/dash_ico_R.png" alt=""> Dashboards</a></li>
            
          </ul>
        </li>
        
        
        <li><a href="#"><img src="./images/Settings_ico.png" alt=""> <span>Admin Settings</span></a></li>
        <li class="mrg50T"><a href="#"><img src="./images/phone_ico.png" alt=""> <span>Phone</span></a></li>
        <li><a href="#"><img src="./images/chat_ico.png" alt=""> <span>Chat</span></a></li>
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
     
       <ol class="bread_crumb">
        <li><a href="#"><img src="images/home_ico.png" alt=""></a></li>
        <li><a href="#">Leads</a></li>
        <li class="active">My Leads</li>
        
      </ol>
      
      <ol class="breadcrumb setting_btn">
       <ul class="add_list">
		  			
		  			<li class=""><a href="javascript:void(0);" class="btn btn-creat" data-toggle="modal" data-target="#ImportsModal">Import leads <i class="fa fa-caret-down"></i></a>
		  			
		  			</li>
		  			<li class="dropdown"><a href="" class="dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Edit columns <i class="fa fa-caret-down"></i></a>
		  			<div class="dropdown-menu">
    <a class="dropdown-item" href="#">Follow up</a>
    <a class="dropdown-item" href="#">Call reminder</a>
    <a class="dropdown-item" href="#">Appointment</a>
  </div>
		  			</li>
		  			<li class="dropdown"><a href="" class="dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><img src="./images/filter.png" alt=""></a>
		  			<div class="dropdown-menu">
    <a class="dropdown-item" href="#">Follow up</a>
    <a class="dropdown-item" href="#">Call reminder</a>
    <a class="dropdown-item" href="#">Appointment</a>
  </div>
		  			</li>
		  		</ul>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content leads_page">
      <!-- Small boxes (Stat box) -->
      <div class="row">
      	<div class="col-md-12">
      		<div class="lead_head">
      			<h3>No leads match this filter</h3>
      			<h4>...but don't worry. There's help below...
</h4>
      		</div>
      	</div>
      	
      	<div class="col-md-12">
      		<ul class="creat_list">
      			<li>
      				<div class="creat_sec">
      					<div class="creat_img"><img src="./images/creat_img.png" alt=""></div>
      					<div class="creat_txt">
      						<h4>Maybe a different filter?
</h4>
     						<p>Apply the right filters to find the leads you need


</p>
     						<a href="javascript:void(0);" class="btn btn-creat" data-toggle="modal" data-target="#filtersModal"> Edit filters</a>
      					</div>
      					
      				</div>
      			</li>
      			<li>
      				<div class="creat_sec">
      					<div class="creat_img"><img src="./images/creat_img1.png" alt=""></div>
      					<div class="creat_txt">
      						<h4>Just starting out?
</h4>
     						<p>Create your own list of leads in Freshsales


</p>
     						<a href="javascript:void(0);" class="btn btn-creat" data-toggle="modal" data-target="#ceartModal"> Create lead</a>
      					</div>
      					
      				</div>
      			</li>
      			<li>
      				<div class="creat_sec">
      					<div class="creat_img"><img src="./images/creat_img2.png" alt=""></div>
      					<div class="creat_txt">
      						<h4>Your leads are in a spreadsheet?</h4>
     						<p>Import them all into Freshsales


</p>
     						<a href="javascript:void(0);" class="btn btn-creat" data-toggle="modal" data-target="#ImportsModal"> Import leads</a>
      					</div>
      					
      				</div>
      			</li>
      		</ul>
      	</div>
      	
      </div>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
 <!-- <footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 2.4.0
    </div>
    Copyright &copy; 2014-2016  All rights
    reserved.
  </footer>-->

  <!-- Control Sidebar -->
  
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
  
  <!-- Modal -->
<div class="modal fade" id="ceartModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Add Lead</h4>
      </div>
      <div class="modal-body">
        <form action="" class="row">
        	<div class="col-md-12">
        		<div class="form-group">
        			<label>First Name</label>
        			<input type="text" class="form-control" placeholder="First Name">
        		</div>
        	</div>
        	<div class="col-md-12">
        		<div class="form-group">
        			<label>Last Name</label>
        			<input type="text" class="form-control" placeholder="Last Name">
        		</div>
        	</div>
        	<div class="col-md-12">
        		<div class="form-group">
        			<label>Company Name</label>
        			<input type="text" class="form-control" placeholder="Company Name">
        		</div>
        	</div>
        	<div class="col-md-12">
        		<div class="row app_mail">
        			<div class="form-group">
        			
        			<div class="col-md-12">
        			 <label>Email</label>
        			</div>
       			  <div class="col-md-1">
        			  <input type="radio" name="RadioGroup1" value="radio" id="RadioGroup1_0">
        			</div>
        			<div class="col-md-7">
        				<input type="text" class="form-control" placeholder="Enter Value">
        			</div>
        			<div class="col-md-4">
        				
        				<select id="single1" class="js-states form-control">
            <option value="">Pick a label</option>
        					<option value="">Work</option>
        					<option value="">Personal</option>
          </select>
        			</div>
        			
        		</div>
        			<a href="javascript:void(0);" class="btn btn-add app_btn"><img src="./images/add_ico.png" alt=""> Add Email</a>
        		</div>
        		
        	</div>
        	<div class="col-md-12">
        		<div class="form-group">
        			<label>Mobile</label>
        			<input type="text" class="form-control" placeholder="Mobile">
        		</div>
        	</div>
        	<div class="col-md-12">
        		<div class="form-group">
        			<label>Work</label>
        			<input type="text" class="form-control" placeholder="Work">
        		</div>
        	</div>
        	<div class="col-md-12">
        		<div class="form-group">
        			<label>Sales Owner</label>
        			<select id="single" class="js-states form-control">
            <option>Sales Owner</option>
            <option>Sales Owner1</option>
            <option>Sales Owner2</option>
            <option>Sales Owner3</option>
          </select>
        			<!--
        			<select id="multiple" class="js-states form-control" multiple>
            <option>Sales Owner</option>
            <option>Sales Owner1</option>
            <option>Sales Owner2</option>
            <option>Sales Owner3</option>
          </select>-->
        		</div>
        	</div>
        	<div class="col-md-12">
        		<div class="form-group">
        			<label>Subscription Status</label>
        			<select id="single2" class="js-states form-control">
            <option>Unsubscribed</option>
            <option>Subscribed</option>
            <option>Not Subscribed</option>
            
          </select>
        			<!--
        			<select id="multiple" class="js-states form-control" multiple>
            <option>Sales Owner</option>
            <option>Sales Owner1</option>
            <option>Sales Owner2</option>
            <option>Sales Owner3</option>
          </select>-->
        		</div>
        	</div>
        	
        	
        	
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-creat pull-left"><i class="fa fa-pencil"></i> Customize fields</button>
        <button type="button" class="btn btn-creat " data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-save">Save</button>
      </div>
    </div>
  </div>
</div>

 
  <!-- Modal -->
<div class="modal fade" id="filtersModal" tabindex="-1" role="dialog" aria-labelledby="">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="">Filters</h4>
        <a href="javascript:void(0);" class="btn btn-add app_btn pull-right"><img src="./images/add_ico.png" alt=""> Add filter</a>
      </div>
      <div class="modal-body">
        <form action="" class="row">
        	<div class="col-md-12">
		  			<hr>
		  			<a href="javascript:void(0)" class="remove_ico"><i class="fa fa-times-circle"></i></a>
		  				<ul class="showing_list">
		  					<li class="dropdown">Active sales sequences <a href="" class="dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">contains <i class="fa fa-caret-down"></i></a>
		  						<div class="dropdown-menu">
    <a class="dropdown-item" href="#">contains</a>
    <a class="dropdown-item" href="#">does not contain</a>
    <a class="dropdown-item" href="#">is not empty (has any value)</a>
    <a class="dropdown-item" href="#">is empty</a>
    
  </div>
		  					</li>
		  					
		  					
		  				</ul>
		  				<p>No values available for this filter.</p>
		  			
		  		</div>
       	<div class="col-md-12">
		  			<hr>
		  			<a href="javascript:void(0)" class="remove_ico"><i class="fa fa-times-circle"></i></a>
		  				<ul class="showing_list">
		  					<li class="dropdown">Sales owner <a href="" class="dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">contains <i class="fa fa-caret-down"></i></a>
		  						<div class="dropdown-menu">
    <a class="dropdown-item" href="#">contains</a>
    <a class="dropdown-item" href="#">does not contain</a>
    <a class="dropdown-item" href="#">is not empty (has any value)</a>
    <a class="dropdown-item" href="#">is empty</a>
    
  </div>
		  					</li>
		  					
		  					
		  				</ul>
		  			
		  		</div>
       	
        	<div class="col-md-12">
        		<hr>
        		<a href="javascript:void(0)" class="remove_ico"><i class="fa fa-times-circle"></i></a>
        		<div class="form-group">
        			<input type="checkbox" id="me"> <label for="me">Me</label>
        		</div>
        		<span class="more_checkbox">
        			<div class="form-group">
        			<input type="checkbox" id="Unassigned"> <label for="Unassigned">Unassigned</label>
        		</div>
        		<div class="form-group">
        			<input type="checkbox" id="Owner_name"> <label for="Owner_name">Owner Name</label>
        		</div>
        		</span>
        		<a href="javascript:void(0)" class="show_more">Show More</a>
        	</div>
        	
        	
        	
        	
        	
        	
        	
        	
        	
        </form>
      </div>
      <div class="modal-footer">
        
        <button type="button" class="btn btn-creat " data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-save">Apply</button>
      </div>
    </div>
  </div>
</div>


<!-- Modal -->
<div class="modal fade" id="ImportsModal" tabindex="-1" role="dialog" aria-labelledby="">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="">IMPORT CONTACTS
 <span class="step_btn btn">Step 1 of 2</span></h4>
       
      </div>
      <div class="modal-body">
        <form action="" class="row">
        	<div class="col-md-12">
        		<p>Import your contacts using your own file, or use our <a href="">sample CSV</a>. <i class="fa fa-question-circle-o"></i> </p>
        	</div>
       	
       		<div class="col-md-12">
       			<div class="form-group">
       			<div class="drag_sec">
  							<div class="choose-file">
  <input type="file">
  <label><span class="img_sec"><img src="./images/csv_img.png" alt=""></span> Drop or upload your file here</label>
  <p>(.csv, .xlsx formats supported)</p>
</div>
  						</div>
       			</div>
       		</div>
        	
        	<div class="col-md-12">
        		<div class="form-group">
        			<label>Select an import option for this file</label>
        			<select name="" id="" class="form-control">
        				<option value="">Create new contacts</option>
        				<option value="">Create new and update existing contacts (without overwrite)</option>
        				<option value="">Create new and update existing contacts (with overwrite)</option>
        			</select>
        		</div>
        	</div>
        	<div class="col-md-12">
        		
        		<div class="form-group">
        			<input type="checkbox" id="Skip"> <label for="Skip">Skip duplicates automatically by matching <span>Primary email <i class="fa fa-caret-down"></i></span></label>
        		</div>
        		
        	</div>
        	
        	<div class="col-md-12">
        		
        		<div class="form-group">
        			<a  href="javascript:void(0)" class="show_more1">Manage email subscriptions <i class="fa fa-caret-down"></i></a>
        			<span class="more_checkbox1">
        			<div class="form-group">
        			<input type="checkbox" id="Subscribe"> <label for="Subscribe">Subscribe contacts to all types of emails</label>
        		</div>
        		
        		</span>
        		</div>
        		
        	</div>
        	<div class="col-md-12">
        		
        		<div class="form-group">
        			<a  href="javascript:void(0)" class="show_more2">Manage sales owner <i class="fa fa-caret-down"></i></a>
        			<span class="more_checkbox2">
        			<div class="form-group">
        			<select id="single3" class="js-states form-control">
            <option>Sales Owner</option>
            <option>Sales Owner1</option>
            <option>Sales Owner2</option>
            <option>Sales Owner3</option>
          </select>
        		</div>
        		
        		</span>
        		</div>
        		
        	</div>
        	
        	
        	
        	
        	
        	
        </form>
      </div>
      <div class="modal-footer">
        
        <button type="button" class="btn btn-creat " data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-save" data-dismiss="modal" data-toggle="modal" data-target="#ImportsModal1">Next</button>
      </div>
    </div>
  </div>
</div>



<!-- Modal -->
<div class="modal fade" id="ImportsModal1" tabindex="-1" role="dialog" aria-labelledby="">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="">IMPORT CONTACTS
 <span class="step_btn btn">Step 2 of 2</span></h4>
       
      </div>
      <div class="modal-body">
        <form action="" class="row">
        	<div class="col-md-12">
        		<p>Map columns in your file to fields in Freshsales. </p>
        		<hr>
        	</div>
       		
       		<div class="col-md-6">
       			<label><i class="fa fa-file-text-o"></i> FILE COLUMN	</label>
       		</div>
       		<div class="col-md-6">
       			<label>FRESHSALES FIELD</label>
       		</div>
        	<div class="col-md-12"><hr></div>
        	<div class="col-md-6">
        		<p>dfsfsf</p>
        	</div>
        	<div class="col-md-6">
        		
        		<div class="form-group">
        			<div class="form-group">
        			<select id="single4" class="js-states form-control">
            <option>Choose a value</option>
            <option>Choose a value1</option>
            <option>Choose a value2</option>
            <option>Choose a value3</option>
          </select>
        		</div>
        		</div>
        		
        	</div>
        	
        	
        	
        	
        	
        	
        	
        	
        	
        </form>
      </div>
      <div class="modal-footer">
        
        <button type="button" class="btn btn-creat " data-dismiss="modal" data-toggle="modal" data-target="#ImportsModal">Back</button>
        <button type="button" class="btn btn-save">Import</button>
      </div>
    </div>
  </div>
</div>



</div>
<!-- ./wrapper -->

<!-- jQuery 3 -->
<script src="js/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="js/bootstrap.min.js"></script>
<!-- AdminLTE App -->
<script src="js/adminlte.min.js"></script>
<script src="js/jquery.slimscroll.js"></script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
    <script>
      $("#single").select2({
          placeholder: "Select a programming language",
          allowClear: true
      });
	$("#single1").select2({
          //placeholder: "Select a programming language",
          allowClear: true
      });
		$("#single2").select2({
          //placeholder: "Select a programming language",
          allowClear: true
      });
		$("#single3").select2({
          //placeholder: "Select a programming language",
          allowClear: true
      });
		$("#single4").select2({
          //placeholder: "Select a programming language",
          allowClear: true
      });
		$(".single1").select2({
          //placeholder: "Select a programming language",
          allowClear: true
      });
      $("#multiple").select2({
          placeholder: "Select a programming language",
          allowClear: true
      });
    </script>

<script>
	
$('.right_panel').slimscroll({
  height: '544px',
  color: '#e12f36',
  size: '5px'
	
});
	</script>
<script>
	
$('.app_cal_body').slimscroll({
  height: '300px',
  color: '#e12f36',
  size: '5px'
	
});
	</script>
	<script>
$(document).ready(function(){
  

  $(".app_btn").click(function(){
    $(".app_mail").append("<div class="form-group"><div class="col-md-12"><label>Email</label></div><div class="col-md-1"><input type="radio" name="RadioGroup1" value="radio" id="RadioGroup1_0"></div><div class="col-md-7"><input type="text" class="form-control" placeholder="Enter Value"></div><div class="col-md-4"><select id="" class="js-states form-control single1"><option value="">Pick a label</option><option value="">Work</option><option value="">Personal</option></select></div></div>");
  });
});
</script>
<script>
	$(".show_more").click(function(){
  $(".show_more").hide();
});

$(".show_more").click(function(){
  $(".more_checkbox").show();
});
$(".show_more1").click(function(){
  $(".more_checkbox1").show();
});
	$(".show_more2").click(function(){
  $(".more_checkbox2").show();
});
	
	
</script>
</body>
</html>
