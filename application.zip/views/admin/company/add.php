<!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h3>
            Company 
          </h3>
          <!--<ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Dashboard</li>
          </ol>-->
        </section>

        <!-- Main content -->
        <section class="content"> 
			<div class="row">
				<!-- general form elements -->
				<div class="col-md-12">
					  <div class="box box-primary">
						<div class="box-header with-border">
						  <h3 class="box-title"></h3>
						  <?php if($this->session->flashdata('error_msg')){?>
							<div class="alert alert-warning alert-dismissible hite">
								<button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
								<h4><i class="icon fa fa-warning"></i><?php echo $this->session->flashdata('error_msg'); ?></h4>
							</div>
						  <?php }?>
						  <?php if($this->session->flashdata('success_msg')){?>
							<div class="alert alert-success alert-dismissible hite">
								<button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
								<h4><i class="icon fa fa-warning"></i><?php echo $this->session->flashdata('success_msg'); ?></h4>
							</div>
						  <?php }?>
						</div>
						<!-- /.box-header -->
						<!-- form start -->
						<form role="form" class="mtbresize" method="post" action="<?php echo base_url('admin/company/save');?>" enctype="multipart/form-data">
						  	<input type="hidden" name="compId" value="<?php if(isset($company)){ echo $company->company_id; } ?> " >
						  	<div class="box-body">
								<div class="form-group">
								  	<label for="name"> Name</label>
								  	<input type="text" class="form-control" id="company_name" name="company_name" value="<?php if(isset($company)){ echo $company->name; } ?>" placeholder="name" required>
									<?php echo form_error('company_name','<span class="error">', '</span>'); ?>
								</div>	
														
						  	</div>
						  	<div class="box-body">
								<div class="form-group">
								  	<label for="name"> Company Email</label>
								  	<input type="email" onkeypress="nospaces(this)" onkeyup="nospaces(this)" class="form-control" id="company_email" name="company_email" value="<?php if(isset($company)){ echo $company->company_email; } ?>" placeholder="Company Email" required>
									<?php echo form_error('company_email','<span class="error">', '</span>'); ?>
								</div>				
						  	</div>
						  	<div class="box-body">
								<div class="form-group">
								  <label for="name"> Company Phone</label>
								  <input type="text" minlength="10" maxlength="10" pattern="[0-9]{10}"onkeypress="nospaces(this)" onkeyup="nospaces(this)" class="form-control" id="company_phone" name="company_phone" value="<?php if(isset($company)){ echo $company->company_phone; } ?>" placeholder="Company Phone eg: 1111111111" required>
								</div>				
						  	</div>
						  <!-- /.box-body -->
							  <div class="box-footer">
							  	<button type="button" style="background-color:black;color:white" onclick="window.history.back()" class="btn btn-sm btn-round">Back</button>
                            	<button type="submit" class="btn btn-sm btn-primary">Submit</button>
							  </div>
						</form>
					  </div>
				</div>
          <!-- /.box -->
          </div><!-- /.row -->	
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
<script src="https://cdn.ckeditor.com/4.5.7/standard/ckeditor.js"></script>
<script>
function readURL(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('#blah').attr('src', e.target.result);
        }

        reader.readAsDataURL(input.files[0]);
    }
}

$("#imgInp").change(function(){
    readURL(this);
});
CKEDITOR.replace('description');
CKEDITOR.replace('content');


</script>