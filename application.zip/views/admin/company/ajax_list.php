<table class="table table-striped table-bordered export_btn_dt c_table_style" id="tablecompany">
  <thead>
    <tr>
      <th>Sl no</th>
      <th>Company Name</th>
      <th>Email</th>
      <th>Phone</th>
      <th>Status</th>
      <th class="no-sort">Action</th>
    </tr>
  </thead>
  <tbody>
  <?php if(!empty($details)){
          foreach($details as $key => $list){
  ?>
          <tr>
              <td><?php echo $key+1; ?></td>
              <td><?php echo ucfirst($list->name); ?></td>
              <td><?php echo $list->company_email; ?></td>
              <td><?php echo $list->company_phone; ?></td>
              <?php if ($list->status==0) {
                  $status = '<a href="javascript:void(0)" id="'.$list->company_id.'" class="change-p-status text-danger" data-status="1" data-table="company_master" data-key-id="company_id" data-id="'.$list->company_id.'">Inactive</a>';
              } else if($list->status==1){
                  $status = '<a href="javascript:void(0)" id="'.$list->company_id.'" class="change-p-status text-success" data-status="0" data-table="company_master" data-key-id="company_id" data-id="'.$list->company_id.'">Active</a>';
              } ?>
              <td><?php echo $status; ?></td>
              <td>
                  <a class="cstm_view" href="<?=base_url('admin/company/edit/' . $list->company_id) ?>"><i class="glyphicon glyphicon-edit"></i>
                  </a> | 
                  <a class="application_delete" href="javscript:void(0)" data-id="<?php echo $list->company_id; ?>"  data-table="company_master" data-function="faqTable">
                      <i class="glyphicon glyphicon-remove"></i>
                  </a>
              </td>
          </tr>
  <?php   } } else{ ?>
          <tr><h3>No record found</h3></tr>
  <?php } ?>
  </tbody>
  <tfoot>
  </tfoot>
</table>