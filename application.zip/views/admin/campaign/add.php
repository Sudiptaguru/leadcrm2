<!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h3>
            Campaign 
          </h3>
          <!--<ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Dashboard</li>
          </ol>-->
        </section>

        <!-- Main content -->
        <section class="content"> 
			<div class="row">
				<!-- general form elements -->
				<div class="col-md-12">
					  <div class="box box-primary">
						<div class="box-header with-border">
						  <h3 class="box-title"></h3>
						  <?php if($this->session->flashdata('error_msg')){?>
							<div class="alert alert-warning alert-dismissible hite">
								<button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
								<h4><i class="icon fa fa-warning"></i><?php echo $this->session->flashdata('error_msg'); ?></h4>
							</div>
						  <?php }?>
						  <?php if($this->session->flashdata('success_msg')){?>
							<div class="alert alert-success alert-dismissible hite">
								<button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
								<h4><i class="icon fa fa-warning"></i><?php echo $this->session->flashdata('success_msg'); ?></h4>
							</div>
						  <?php }?>
						</div>
						<!-- /.box-header -->
						<!-- form start -->
						<form role="form" class="mtbresize" method="post" action="<?php echo base_url('admin/campaign/save');?>" enctype="multipart/form-data">
						  	<input type="hidden" name="campId" value="<?php if(isset($campaign)){ echo $campaign->campaign_id; } ?> " >
						  	<?php $admin=$this->session->userdata('admin'); ?>
						  	<input type="hidden" name="company_id" value="<?= $company_id ?>">
						  	<div class="box-body">
								<div class="form-group">
								  <label for="name"> Campaign No</label>
								  <input type="text" onkeypress="nospaces(this)" onkeyup="nospaces(this)" class="form-control" id="campaign_no" name="campaign_no" value="<?php if(isset($campaign)){ echo $campaign->campaign_generated_no; } ?>" placeholder="Campaign No" required>
								</div>				
						  	</div>
						  	<div class="box-body">
								<div class="form-group">
								  <label for="name">Campaign Name</label>
								  <input type="text" class="form-control" id="campaign_name" name="campaign_name" value="<?php if(isset($campaign)){ echo $campaign->campaign_name; } ?>" placeholder="Campaign Name" required>
								</div>	
														
						  	</div>
						  	<div class="box-body">
								<div class="form-group">
								  <label for="name"> Campaign Start Date</label>
								  <input type="text" autocomplete="off" onkeypress="nospaces(this)" onkeyup="nospaces(this)" class="form-control datepicker" id="campaign_start_date" name="campaign_start_date" value="<?php if(isset($campaign)){ echo $campaign->campaign_start_date; } ?>" placeholder="Campaign Start Date" required>
								</div>				
						  	</div>
						  	<div class="box-body">
								<div class="form-group">
								  <label for="name"> Campaign End Date</label>
								  <input type="text" autocomplete="off" onkeypress="nospaces(this)" onkeyup="nospaces(this)" class="form-control datepicker" id="campaign_end_date" name="campaign_end_date" value="<?php if(isset($campaign)){ echo $campaign->campaign_end_date; } ?>" placeholder="Campaign End Date" required>
								</div>				
						  	</div>
						  	<div class="box-body">
								<div class="form-group">
								  <label for="source"> Campaign Source</label>
								    <select class="form-control" name="source" required>
								        <option value="" selected disabled>Select Source</option>
								        <?php
								            if($campaign_source){
								                foreach($campaign_source as $key => $value){
								                    ?>
								                        <option value="<?=$value->campaign_source_id?>" <?=$value->campaign_source_id==$campaign->campaign_source_id?'selected':''?>><?=$value->source?></option>
								                    <?
								                }
								            }
								        ?>
								    </select>
								</div>				
						  	</div>
						  <!-- /.box-body -->
							  <div class="box-footer">
							  	<button type="button" style="background-color:black;color:white" onclick="window.history.back()" class="btn btn-sm btn-round">Back</button>
                            	<button type="submit" class="btn btn-sm btn-primary">Submit</button>
							  </div>
						</form>
					  </div>
				</div>
          <!-- /.box -->
          </div><!-- /.row -->	
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
<script src="https://cdn.ckeditor.com/4.5.7/standard/ckeditor.js"></script>
<link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<!-- <link rel="stylesheet" href="https://code.jquery.com/resources/demos/style.css"> -->
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script>
$( function() {
  	$( "#campaign_start_date" ).datepicker({ dateFormat: 'dd-mm-yy',
  		minDate: 0,
  		onSelect: function(selected) {
          $("#campaign_end_date").datepicker("option","minDate", selected)
        }
	});
	$("#campaign_end_date").datepicker({ 
        dateFormat: 'dd-mm-yy',
        
    }); 
	
} );

</script>