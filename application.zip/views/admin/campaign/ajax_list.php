<?php $admin=$this->session->userdata('admin'); ?>
<?php //echo "<pre>"; print_r($admin); die;?>
<?php  $role_id=$admin['role_id'];?>
<?php  //echo $role_id;die;?>
<table class="table table-striped table-bordered export_btn_dt c_table_style" id="tablecampaign">
  <thead>
    <tr>
      <th>Sl no</th>
      <th>Company</th>
      <th>Campaign No</th>
      <th>Campaign Name</th>
      <th>Campaign Start Date</th>
      <th>Campaign End Date</th>
      <th>Source</th>
      <?php if($role_id!=3){?>
      <th>Status</th>
      <th class="no-sort">Action</th>
      <?php } ?>
    </tr>
  </thead>
  <tbody>
  <?php if(!empty($details)){
          foreach($details as $key => $list){
  ?>
          <tr>
              <td><?php echo $key+1; ?></td>
              <td><?php echo $list->name; ?></td>
              <td><?php echo $list->campaign_generated_no; ?></td>
              <td><?php echo ucfirst($list->campaign_name); ?></td>
              <td><?php echo date('d-M-Y',strtotime($list->campaign_start_date)); ?></td>
              <td><?php echo date('d-M-Y',strtotime($list->campaign_end_date)); ?></td>
              <td><?= $list->source?></td>
              <?php if($role_id!=3){?>
              <?php if ($list->status==0) {
                  $status = '<a href="javascript:void(0)" id="'.$list->campaign_id.'" class="change-p-status text-danger" data-status="1" data-table="campaign_master" data-key-id="campaign_id" data-id="'.$list->campaign_id.'">Inactive</a>';
              } else if($list->status==1){
                  $status = '<a href="javascript:void(0)" id="'.$list->campaign_id.'" class="change-p-status text-success" data-status="0" data-table="campaign_master" data-key-id="campaign_id" data-id="'.$list->campaign_id.'">Active</a>';
              } ?>
              <td><?php echo $status; ?></td>
              <td>
                  <a class="cstm_view" href="<?=base_url('admin/campaign/edit/' . $list->campaign_id) ?>"><i class="glyphicon glyphicon-edit"></i>
                  </a> | 
                  <a class="application_delete" href="javscript:void(0)" data-id="<?php echo $list->campaign_id; ?>"  data-table="campaign_master" data-function="faqTable">
                      <i class="glyphicon glyphicon-remove"></i>
                  </a>
              </td>
            <?php } ?>
          </tr>
  <?php   } } else{ ?>
          <tr><h3>No record found</h3></tr>
  <?php } ?>
  </tbody>
  <tfoot>
  </tfoot>
</table>