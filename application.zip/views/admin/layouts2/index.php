<?php

$this->load->view('admin/layouts2/header');
//$this->load->view('admin/layouts/leftsidebar.php');
$this->load->view($content);
//$this->load->view('layouts/rightsidebar.php');
$this->load->view('admin/layouts2/footer');