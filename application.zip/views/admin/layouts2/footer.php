<!-- /.content-wrapper -->
   <!-- <footer class="main-footer">
      <div class="pull-right hidden-xs">
        <b>Version</b> 2.4.0
      </div>
      Copyright &copy; 2014-2016  All rights
      reserved.
    </footer>-->

    <!-- Control Sidebar -->
    
    <!-- /.control-sidebar -->
    <!-- Add the sidebar's background. This div must be placed
     immediately after the control sidebar -->
     <div class="control-sidebar-bg"></div>
   </div>
   <!-- ./wrapper -->

   <!-- Bootstrap 3.3.7 -->
   <script src="<?=base_url('public/admin/')?>js/bootstrap.min.js"></script>
   <!-- AdminLTE App -->
   <script src="<?=base_url('public/admin/')?>js/adminlte.min.js"></script>
    <!-- datatables -->
    <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo base_url()?>public/admin_assets/plugins/datatables/dataTables.bootstrap.min.js"></script>
    <script src="https://cdn.datatables.net/rowreorder/1.2.5/js/dataTables.rowReorder.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.2.3/js/dataTables.responsive.min.js"></script>
    <script type="text/javascript" src="<?= base_url('public/sweetalert2.all.min.js') ?>"></script>
    <script type="text/javascript" src="<?= base_url('public/common-function.js') ?>"></script>
    <script type="text/javascript" src="<?= base_url('public/custom.js') ?>"></script>
   <script>

    $('.right_panel').slimscroll({
      height: '544px',
      color: '#e12f36',
      size: '5px'

    });
  </script>
  <script>
  	
    $('.app_cal_body').slimscroll({
      height: '300px',
      color: '#e12f36',
      size: '5px'

    });
  </script>
  </body>
  </html>
