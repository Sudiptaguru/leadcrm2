<!DOCTYPE html>
<html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Fitser</title>
    <!--<link rel="shortcut icon" href="<?//=base_url()?>public/front_assets/css/images/favIcon.png" type="image/x-icon">
    <link rel="icon" href="<?//=base_url()?>public/front_assets/css/images/favIcon.png" type="image/x-icon">-->
    <!--<link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700" rel="stylesheet">-->
    <!-- BOOTSTRAP STYLE -->
    <!--<link rel="stylesheet" type="text/css" href="<?//=base_url()?>public/front_assets/css/bootstrap.min.css" />-->
    <link rel="stylesheet" type="text/css" href="<?=base_url()?>public/front_assets/css/bootstrap-datetimepicker.css"/>
    <!-- JQUERY LIBRARY -->
    <script type="text/javascript" src="<?=base_url()?>public/front_assets/js/jquery-2.1.4.js"></script>
    <!-- BOOTSTRAP SCRIPTS -->
    <script type="text/javascript" src="<?=base_url()?>public/front_assets/js/bootstrap.min.js" defer></script>
    <script type="text/javascript" src="<?=base_url()?>public/front_assets/js/moment-with-locales.js" defer></script>
    <script type="text/javascript" src="<?=base_url()?>public/front_assets/js/bootstrap-datetimepicker.js" defer></script>
    <script src="<?=base_url()?>public/front_assets/js/jquery.counterup.min.js" defer></script>
    <script src="<?=base_url()?>public/front_assets/js/script.js" defer></script>
    <!-- FONT AWESOME-->
    <!--<link rel="stylesheet" type="text/css" href="<?//=base_url()?>public/front_assets/css/font-awesome.css" />
    <link rel="stylesheet" type="text/css" href="<?//=base_url()?>public/front_assets/owlcarousel/animate.css">
    <link rel="stylesheet" href="<?//=base_url()?>public/front_assets/owlcarousel/owl.carousel.min.css">
    <link rel="stylesheet" href="<?//=base_url()?>public/front_assets/owlcarousel/owl.theme.default.min.css">-->
    <script src="<?=base_url()?>public/front_assets/owlcarousel/owl.carousel.min.js" defer></script>
    <!-- SITE STYLES -->
    <link rel="stylesheet" type="text/css" href="<?=base_url()?>public/front_assets/css/all.css" />
    <!--<link rel="stylesheet" type="text/css" href="<?//=base_url()?>public/front_assets/css/intlTelInput.css" />-->
    <style>
      #contact_submit {
        background: #990000;
          text-align: center;
          color: #fff;
          width: 100%;
          padding: 15px;
          font-family: 'Lato', sans-serif;
          font-weight: 700;
          font-size: 15px;
          border: 0;
      }
      input.error {
          border: 1px dotted red;
      }
      textarea.error {
          border: 1px dotted red;
      }
      .form-group {
          position: relative;
      }
    </style>
    <script>
      (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
      (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
      m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
      })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
    
      ga('create', 'UA-85455930-1', 'auto');
      ga('send', 'pageview');
    </script>
    <!-- Global site tag (gtag.js) - Google Ads: 784397410 -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=AW-784397410"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());
    
      gtag('config', 'AW-784397410');
    </script>

</head>

<body>
    <div class="side_quote"> <img class="show_side" src="<?=base_url()?>public/front_assets/css/images/request.png">
        <form action="" method="post" id="contact_form2" class="contact_form">
            <div class="form-group">
               <input type="text" class="form-control" id="name" placeholder="Name" name="name" required autocomplete="off">
            </div>
            <div class="form-group">
                <input type="email" class="form-control" id="email" placeholder="Email" name="email" required autocomplete="off">
            </div>
            <div class="form-group">
                <div class="row">
                    <div class="col-xs-3">
                      <input type="text" class="form-control" id="country_code2" placeholder="Country Code" name="country_code" title="Country Code">
                    </div>
                    <!-- col-sm-4 -->
                    <div class="col-xs-9">
                      <input type="text" class="form-control" id="phone" placeholder="Phone" name="phone" required autocomplete="off">
                    </div>
                    <!-- col-sm-8 -->
                </div>
            </div>
            <!--<div class="form-group">
                <input type="text" class="form-control" id="schedule2" placeholder="Schedule" name="schedule" required autocomplete="off" readonly>
            </div>-->
            <div class="form-group">
                <textarea class="form-control" id="message" placeholder="Requirement" rows="2" name="message" autocomplete="off"></textarea>
            </div>
            <div class=" text-left">
                <button type="submit" class="btn btn-success">Submit</button>
                <button type="button" class="btn btn-danger">Close</button>
            </div>
        </form>
    </div>
    <header class="land_header">
        <div class="container">
            <div class="row">
                <div class="col-sm-3">
                    <a href="https://www.fitser.com/" class="logo"><img src="<?=base_url()?>public/front_assets/css/images/logo.png" alt="*" /></a>
                </div>
                <!-- col-sm-3 -->
                <div class="col-sm-9">
                    <div class="wrapCallUs"> <span class="callUs"><img src="<?=base_url()?>public/front_assets/css/images/iconPhone.png" alt="*">Call Us Today : <span class="flag"><img src="<?=base_url()?>public/front_assets/css/images/flagUsa.png" alt="*"></span> <a href="tel:(+1) 3605383135">(+1) 3605383135 </a> <span class="flag"><img src="<?=base_url()?>public/front_assets/css/images/flagAus.png" alt="*"></span><a href="tel:(+61) 280113465">(+61) 280113465</a> </span>
                      <ul class="listSocialTop">
                        <li><a href="https://www.facebook.com/FitserNews" target="_blank"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="https://twitter.com/FitserNews" target="_blank"><i class="fa fa-twitter"></i></a></li>            
                        <li><a href="https://www.linkedin.com/company/fitser" target="_blank"><i class="fa fa-linkedin"></i></a></li>
                        <li><a href="https://www.youtube.com/c/FitserNews" target="_blank"><i class="fa fa-youtube"></i></a></li>
                      </ul>
                    </div>
                </div>
                <!-- col-sm-9 -->
            </div>
        </div>
    </header>
    <div class="wraperBanner"> <img src="<?=base_url()?>public/front_assets/css/images/banner04.jpg" alt="" />
        <div class="wrapperBannerContent">
            <div class="container">
                <div class="row">
                    <div class="col-md-8">
                        <div class="banner_caption caption_for_mapp">
          <h2>Make Your Mobile App Easily with Fitser</h2>
          <ul class="listApp">
            <!-- <li>Expertise in Android,</li>
            <li>iOS & Hybrid. Native & Cross</li>
            <li>Platform App Development Fast & Affordable Solution</li> -->
            <li>Expertise in Android, iOS &amp; Hybrid.</li>
            <li>Native &amp; Cross Platform Mobile Apps Development</li>
            <li>On-Time Delivery</li>
            <li>Over 600 Happy Clients</li>
            <li>Assured Quality Services</li>
          </ul>
          <!-- <p><img src="css/images/iconAndroidApple.png" alt="*" /></p> -->
          <!-- <h2>WE CREATE</h2> -->
          <!-- <h4>MOBILE APP DESIGN</h4> -->
        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="banner_form">
                            <div class="wraperGITForm" id="GITForm">
                                <h2>Get in Touch with Us </h2>
                                <div class="GITBody">
                                    <form action="" method="post" id="contact_form" class="contact_form">
                                      <?php if($this->session->flashdata('success_msg')){?>
                                        <div class="success_msg">
                                            <p><?php echo $this->session->flashdata('success_msg'); ?></p>
                                        </div>
                                      <?php }?>
                                      <div class="form-group">
                                          <input type="text" class="form-control" id="name" placeholder="Name" name="name" required autocomplete="off">
                                      </div>
                                      <div class="form-group">
                                          <input type="email" class="form-control" id="email" placeholder="Email" name="email" required autocomplete="off">
                                      </div>
                                      <div class="form-group">
                                          <div class="row">
                                              <div class="col-xs-3">
                                                  <input type="text" class="form-control" id="country_code" placeholder="Country Code" name="country_code" title="Country Code">
                                              </div>
                                              <!-- col-sm-4 -->
                                              <div class="col-xs-9">
                                                  <input type="text" class="form-control" id="phone" placeholder="Phone" name="phone" required autocomplete="off">
                                              </div>
                                              <!-- col-sm-8 -->
                                          </div>
                                          
                                      </div>
                                      <!--<div class="form-group">
                                          <input type="text" class="form-control" id="schedule" placeholder="Schedule" name="schedule" required autocomplete="off" readonly>
                                      </div>-->
                                      <div class="form-group">
                                          <textarea class="form-control" id="message" placeholder="Requirement" rows="2" name="message" autocomplete="off"></textarea>
                                      </div>
                                      <div class="">
                                        <input type="submit" class="btn btn-default" id="contact_submit" value="Submit">
                                      </div>
                                    </form>
                                </div>
                            </div>
                            <!-- wraperGITForm -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- text-right -->
    </div>
    <!-- wraperBanner -->
    <div class="sectionWelcome">
        <div class="container">
            <h1>Mobile App Development Services</h1>
            <p>Are you worried with mobile app development that your business demands? Fitser is here to help you in all possible ways. The experts here offer customized options for all your requirements. Fitser is a certified mobile app development company that also offers various other services, providing cost-effective solutions depending on need of the hour! The team of experienced professionals consist of – UI designers, developers and UX experts thus offering you top class within a stipulated timeframe at an affordable rate!</p>
            <p>If you are still wondering about which company to choose from the innumerable options available? Trust the service provided by us. Here’s a list of highly interactive and robust applications developed on the following platform:</p>
            <h4>1.  Android:</h4>
            <p>With more than millions of users, Android have been a game changer thus standing out as one of the sought-out platforms. Fitser is a leading company that offers solutions that you might require in the long run! Get in touch with the custom Android application company that offers unique, user-engaging applications and innovative ideas.</p>
            <h4>2.  Hybrid:</h4>
            <p>When in need of a cost-effective solution, customers seek installation of mobile app that is customized in a way that they need it. The experts at Fitser will help you get a translated mobile site with the help of a compiler. Thus, the transformed application is viable to be used in any platform.</p>
            <h4>3.  iOS:</h4>
            <p>Want your idea to be transformed into reality when it comes to iPhone and iPad? We are here to provide you a cutting edge solution! There is a talented team of individual experienced in the field thus providing interactive, innovative and scalable apps for iOS development, iOS system framework, Swift and Objective C.</p>

            <h1>Why Choose us:</h1>
            <p>If you are still not convinced about choosing us your mobile application development partner, here’s a list of positive factors that will help you get the best that you deserve for your own business:</p>
            <ol class="listService">
                <li>we promise to deliver the works within a stipulated timeframe</li>
                <li>Expertise in Android, iOS &amp; Hybrid.</li>
                <li>Native &amp; Cross Platform Mobile Apps Development</li>
                <li>Over 600 Happy Clients</li>
                <li>Assured Quality Services</li>
                <li>Proficient team to lend an attentive ears to the requirement</li>

            </ol>
            <p><a href="#GITForm" class="btnCallBack">Request a Call Back</a></p>
        </div>
    </div>
    <!-- sectionWelcome -->
    <!-- Portfolio:Start -->
    <div class="home-portfolio">
        <div class="container">
            <h2>Our Portfolio</h2>
            <div class="port_box">
                <!--<div class="portfolio-view-all"> <a href="#">view all</a> </div>-->
                <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 portfolio-nav">
                    <div>
                        <div class="left-nav mt">
                            <ul class="nav nav-pills nav-stacked">
                                <!--<li><a data-toggle="tab" href="#menu-1">All</a></li>-->
                                <li class="active"><a data-toggle="tab" href="#menu-2" style="color: #fff;">Mobile App</a></li>
                                <!--<li><a data-toggle="tab" href="#menu-3">Web Design</a></li>
                <li><a data-toggle="tab" href="#menu-4">Graphic design</a></li>
                <li><a data-toggle="tab" href="#menu-5">Logo Design</a></li>-->
                            </ul>
                        </div>
                        <div class="clearfix"></div>
                        <h1 class="portfolio-heading">our portfolio</h1>
                        <h1 class="portfolio-link-no">01</h1>
                    </div>
                </div>
                <!--/.col4-->
                <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12 portfolio-wrapper">
                    <div class="tab-content">

                        <div id="menu-2" class="tab-pane fade in active">
                            <div class="row">
                                <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
                                    <div class="row">
                                        <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 portfolio-padding-fixer"> <img src="<?=base_url()?>public/front_assets/images/mob1.png" class="img-responsive center-block">
                                            <div class="overlay-portfolio">
                                                <div>
                                                    <div>
                                                        <h1>KITCHEN OF POSSIBILITIES</h1>
                                                        <p>Mobile App</p>
                                                        <!--<a href="#"> <i class="fa fa-arrows-alt" aria-hidden="true"></i> </a>
                                                        <a href="#"> <i class="fa fa-paperclip" aria-hidden="true"></i> </a>-->
                                                    </div>
                                                </div>
                                            </div>
                                            <!--/.overlay-portfolio-->
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 portfolio-padding-fixer"> <img src="<?=base_url()?>public/front_assets/images/mob2.png" class="img-responsive center-block">
                                            <div class="overlay-portfolio">
                                                <div>
                                                    <div>
                                                        <h1>lemon group messenger</h1>
                                                        <p>Mobile App</p>
                                                        <!--<a href="#"> <i class="fa fa-arrows-alt" aria-hidden="true"></i> </a>
                                                        <a href="#"> <i class="fa fa-paperclip" aria-hidden="true"></i> </a>-->
                                                    </div>
                                                </div>
                                            </div>
                                            <!--/.overlay-portfolio-->
                                        </div>
                                    </div>
                                    <!--/.row-->
                                    <div class="row">
                                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 portfolio-padding-fixer"> <img src="<?=base_url()?>public/front_assets/images/mob4.png" class="img-responsive center-block">
                                            <div class="overlay-portfolio">
                                                <div>
                                                    <div>
                                                        <h1>dealmeals</h1>
                                                        <p>Mobile App</p>
                                                        <!--<a href="#"> <i class="fa fa-arrows-alt" aria-hidden="true"></i> </a>
                                                        <a href="#"> <i class="fa fa-paperclip" aria-hidden="true"></i> </a>-->
                                                    </div>
                                                </div>
                                            </div>
                                            <!--/.overlay-portfolio-->
                                        </div>
                                    </div>
                                    <!--/.row-->
                                </div>
                                <!--/.col6-->
                                <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 portfolio-padding-fixer"> <img src="<?=base_url()?>public/front_assets/images/mob3.png" class="img-responsive center-block">
                                    <div class="overlay-portfolio">
                                        <div>
                                            <div>
                                                <h1>shnarped hockey</h1>
                                                <p>Mobile App</p>
                                                <!--<a href="#"> <i class="fa fa-arrows-alt" aria-hidden="true"></i> </a>
                                                <a href="#"> <i class="fa fa-paperclip" aria-hidden="true"></i> </a>-->
                                            </div>
                                        </div>
                                    </div>
                                    <!--/.overlay-portfolio-->
                                </div>
                                <!--/.col6-->
                            </div>
                            <!--/.row-->
                            <div class="row">
                                <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 portfolio-padding-fixer"> <img src="<?=base_url()?>public/front_assets/images/mob5.png" class="img-responsive center-block">
                                    <div class="overlay-portfolio">
                                        <div>
                                            <div>
                                                <h1>sweet bouquet</h1>
                                                <p>Mobile App</p>
                                                <!--<a href="#"> <i class="fa fa-arrows-alt" aria-hidden="true"></i> </a>
                                                <a href="#"> <i class="fa fa-paperclip" aria-hidden="true"></i> </a>-->
                                            </div>
                                        </div>
                                    </div>
                                    <!--/.overlay-portfolio-->
                                </div>
                                <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12 portfolio-padding-fixer"> <img src="<?=base_url()?>public/front_assets/images/mob6.png" class="img-responsive center-block">
                                    <div class="overlay-portfolio">
                                        <div>
                                            <div>
                                                <h1>THE MOON AND YOU</h1>
                                                <p>Mobile App</p>
                                                <!--<a href="#"> <i class="fa fa-arrows-alt" aria-hidden="true"></i> </a>
                                                <a href="#"> <i class="fa fa-paperclip" aria-hidden="true"></i> </a>-->
                                            </div>
                                        </div>
                                    </div>
                                    <!--/.overlay-portfolio-->
                                </div>
                            </div>
                            <!--/.row-->
                        </div>
                    </div>
                    <!--/.tab-content-->
                </div>
                <!--/.col8-->
            </div>
            <!--/.row-->
        </div>
        <!--/.container-->
    </div>
    <!--/.row-->
    <!-- Portfolio:End -->
    <div class="sectionClientSay">
      <div class="container">
        <h1>WHAT OUR CLIENT SAYS</h1>
        <div class="wraperTestimonials">
          <div class="iconTestimonial"> <img src="<?=base_url()?>public/front_assets/css/images/iconTestimonial.png" alt="*" /> </div>
          <div class="owl-carousel owl-theme sliderTestimonial">
            <div class="item">
              <div class="wrapTestimonials">
                <div class="contentTestimonials">
                  <p class="author">Ken Dagley </p>
                  <p>Doghavior is an excellent mobile app which helped me immensely understand my four-legged friend’s personality. Ken Dagley has a deep comprehension about canine behavior. I will recommend people with pet dogs to play the game to interpret the personality traits of their pups easily. </p>
                </div>
                <!-- contentTestimonials -->
              </div>
            </div>
            <!-- item -->
            <div class="item">
              <div class="wrapTestimonials">
                <div class="contentTestimonials">
                  <p class="author">Jennifer Sawyer</p>
                  <p>Nothing comes closer to the beauty and aestheticism provided by Glamour Shells. Jennifer Sawyer makes all the efforts to make the customers satisfied with the custom handmade shell jewelry. I got a unique shell neckpiece last month and I must say I adore the piece of art endlessly. </p>
                  
                </div>
                <!-- contentTestimonials -->
                
              </div>
            </div>
            <!-- item -->
            <div class="item">
              <div class="wrapTestimonials">
                <div class="contentTestimonials">
                  <p class="author">Jordan Walters </p>
                  <p>As a passionate songwriter and singer, I have immense love for 504Beats. Here you can listen to the beats and purchase it by following some very easy steps. Jordan Walters has created an excellent platform for you to enjoy and discover new music from various producers. </p>
                  
                </div>
                <!-- contentTestimonials -->
                
              </div>
            </div>
            <!-- item -->
            <div class="item">
              <div class="wrapTestimonials">
                <div class="contentTestimonials">
                  <p class="author">MAURICE SMITH</p>
                  <p>I am very happy with our new website produced by Fitser and especially for the support I received from Sukhwinder (Harry) and his team. I have only good words to say about Harry, his professional attitude and the valued assistance he provided to us throughout the building process of our website & App. Harry’s ability to communicate and work with us to achieve a quality website can only be good for our future business. I would recommend anyone to use the services of Fitser to design and build their website & App.</p>
                  
                </div>
                <!-- contentTestimonials -->
              </div>
            </div>
            <!-- item -->
          </div>
          <!-- owl-carousol -->
        </div>
        <!-- wraperTestimonials -->
        <a href="#GITForm" class="btnCallBack">Request a Call Back</a> </div>
    </div>
    <!-- sectionClientSay -->
    <div class="sectionCounter">
        <div class="container">
            <div class="row">
                <div class="col-sm-3">
                    <div class="wraperCounter">
                        <h3>Projects</h3>
                        <div class="numscroller numscroller-big-bottom" data-slno="5" data-min="0" data-max="620" data-delay="1" data-increment="1">0</div>
                    </div>
                </div>
                <!-- col-sm-3 -->
                <div class="col-sm-3">
                    <div class="wraperCounter">
                        <h3>Working Days</h3>
                        <div class="numscroller numscroller-big-bottom" data-slno="5" data-min="0" data-max="365" data-delay="1" data-increment="1">0</div>
                    </div>
                </div>
                <!-- col-sm-3 -->
                <div class="col-sm-3">
                    <div class="wraperCounter">
                        <h3>Team Member</h3>
                        <div class="numscroller numscroller-big-bottom" data-slno="5" data-min="0" data-max="100" data-delay="1" data-increment="1">0</div>
                    </div>
                </div>
                <!-- col-sm-3 -->
                <div class="col-sm-3">
                    <div class="wraperCounter">
                        <h3>Happy Clients</h3>
                        <div class="numscroller numscroller-big-bottom" data-slno="5" data-min="0" data-max="500" data-delay="1" data-increment="1">0</div>
                    </div>
                </div>
                <!-- col-sm-3 -->
            </div>
        </div>
    </div>
    <!-- sectionCounter -->
    <section class="callback">
        <div class="container">
            <h3>Have Questions? Feel Free To Ask Us!</h3>
            <a href="#" class="callback_bttn">Request A call back</a> </div>
    </section>
    <section class="footer">
        <div class="container">
            <h3>Contact Us</h3>
            <span><i class="fa fa-phone" aria-hidden="true"></i><span class="flag"><img src="<?=base_url()?>public/front_assets/css/images/flagUsa.png" alt="*" /></span> <a href="tel:(+1) 3605383135">(+1) 3605383135 </a>
            <span class="flag"><img src="<?=base_url()?>public/front_assets/css/images/flagAus.png" alt="*" /></span><a href="tel:(+61) 280113465">(+61) 280113465</a></span>
            <div> <span><i class="fa fa-envelope" aria-hidden="true"></i><a href="mailto:info@fitser.com">info@fitser.com</a></span> </div>
        </div>
    </section>
    <div class="sectionFooterBottom">
        <div class="container">
            <p>© <?=date('Y')?> <a href="https://www.fitser.com" target="_blank" style="color: white;">Fitser</a> . All Rights Reserved</p>
        </div>
    </div>
    <!-- sectionFooterBottom -->
    <script src="<?=base_url()?>public/front_assets/js/numscroller-1.0.js"></script>
    <script src="<?=base_url()?>public/front_assets/js/intlTelInput.js"></script>
    <script src="<?=base_url()?>public/front_assets/js/jquery.validate.min.js"></script>
    <script src="<?=base_url()?>public/front_assets/js/custom.js" type="text/javascript"></script>
    <script>
          $(function () {
                /*$('#schedule').datetimepicker({
                    format: 'DD-MM-YYYY HH:mm',
                    ignoreReadonly: true,
                    minDate:new Date()
                });
                $('#schedule2').datetimepicker({
                    format: 'DD-MM-YYYY HH:mm',
                    ignoreReadonly: true,
                    minDate:new Date()
                });*/
            });
        var input2 = document.querySelector("#country_code2");
        window.intlTelInput(input2, {
          autoPlaceholder: "off",
          separateDialCode: true,
          onlyCountries: ['us', 'ca', 'au'],
          preferredCountries: []
        });
        $("#contact_form2").validate({
          errorPlacement: function(error, element) {
          // Append error within linked label
          $( element )
            .closest( "form" )
              .find( "label[for='" + element.attr( "id" ) + "']" )
                .append( error );
        },
        errorElement: "span",
        messages: {
          name: {
            required: " (required)"
          },
          email: {
            required: " (required)",
            email: true
          },
          phone: {
            required: " (required)"
          },
          schedule: {
            required: " (required)"
          },
          message: {
            required: " (required)"
          }
        }
        })
        var input = document.querySelector("#country_code");
        window.intlTelInput(input, {
          autoPlaceholder: "off",
          separateDialCode: true,
          onlyCountries: ['us', 'ca', 'au'],
          preferredCountries: []
        });
        $("#contact_form").validate({
          errorPlacement: function(error, element) {
          // Append error within linked label
          $( element )
            .closest( "form" )
              .find( "label[for='" + element.attr( "id" ) + "']" )
                .append( error );
        },
        errorElement: "span",
        messages: {
          name: {
            required: " (required)"
          },
          email: {
            required: " (required)",
            email: true
          },
          phone: {
            required: " (required)"
          },
          schedule: {
            required: " (required)"
          },
          message: {
            required: " (required)"
          }
        }
        })
    </script>
    <!--DATE TIME PICKER-->
</body>

</html>