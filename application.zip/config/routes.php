<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$route['default_controller'] = 'index';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

$route['web-designing'] = 'index/web_design';
$route['app-development'] = 'index/mobile_app';
$route['web-development'] = 'index/web_development';
$route['thank-you'] = 'index/thank_you';

$route['admin/settings/changepassword'] = 'admin/Changepassword';

$route['admin/change-status']               	= 'admin/Dashboard/changeStatus';

/**
 * Lead management by Chayan
*/
$route['admin/leads']           = 'admin/leads';    //call index to get list
$route['admin/leads/store']       = 'admin/leads/addStore';
$route['admin/leads/get-lead']        = 'admin/leads/getLead';
$route['admin/leads/update-status']        = 'admin/leads/updateStatus';
$route['admin/leads/update-lead-details']        = 'admin/leads/updateLeadDetails';

$route['admin/leads/edit/(:any)']                = 'admin/leads/edit/$1';

/**
 * Contacts management by Chayan
*/
$route['admin/contacts']           = 'admin/contacts';    //call index to get list
$route['admin/contacts/store']       = 'admin/contacts/addStore';
$route['admin/contacts/get']        = 'admin/contacts/get';
$route['admin/contacts/update-status']        = 'admin/contacts/updateStatus';
$route['admin/contacts/update-lead-details']        = 'admin/contacts/updateLeadDetails';

$route['admin/contacts/edit/(:any)']                = 'admin/contacts/edit/$1';

/**Lead Settings */
$route['admin/settings/contacts/form']          = 'admin/settings/contacts_form';
$route['admin/settings/contacts/lifecycle']     = 'admin/settings/lifecycle';

/**Lead Settings */
$route['admin/settings/accounts/form']          = 'admin/settings/accounts_form';
$route['admin/settings/accounts/lifecycle']     = 'admin/settings/lifecycle';


$route['admin/settings/deals/form']          = 'admin/settings/deals_form';
$route['admin/settings/deals/pipeline']      = 'admin/settings/deals_pipeline';


/**---------------------------------------------------- */
$route['admin/deals/store']                  = 'admin/deals/addDeal';

#Company Management
$route['admin/company'] 						= "admin/Company/index";
$route['admin/company/get-list'] 				= "admin/Company/getCompanyList";
$route['admin/company/add'] 					= "admin/Company/add";
$route['admin/company/save'] 					= "admin/Company/save";
$route['admin/company/edit/(:num)'] 			= "admin/Company/add/$1";

#campaign Management
$route['admin/campaign'] 						= "admin/Campaign/index";
$route['admin/campaign/get-list'] 				= "admin/Campaign/getCampaignList";
$route['admin/campaign/add'] 					= "admin/Campaign/add";
$route['admin/campaign/save'] 					= "admin/Campaign/save";
$route['admin/campaign/edit/(:num)'] 			= "admin/Campaign/add/$1";

#Role Management
$route['admin/role/list'] 						= "admin/Role/index";
$route['admin/role/get-list'] 					= "admin/Role/getRoleList";
$route['admin/role/add'] 						= "admin/Role/add";
$route['admin/role/save'] 						= "admin/Role/save";
$route['admin/role/edit/(:num)'] 				= "admin/Role/add/$1";

#User Commission Management
$route['admin/commission'] 						= "admin/Commission/index";
$route['admin/commission/get-list'] 			= "admin/Commission/getCommissionList";

#Dashboard
$route['admin/dashboard/filter'] 				= "admin/Dashboard/load_company_dashboard_view";
$route['admin/company-dashboard/(:num)'] 		= "admin/Dashboard/load_company_dashboard_view/$1";

#deals
$route['admin/deals/get-deal']        = 'admin/Deals/getdeal';