<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mproject extends CI_Model {

    var $table = 'leads';
    
    var $column_order = array('leads.name','leads.lname','leads.mobile','leads.work', 'leads.stage'); //set column field database for datatable orderable
    var $column_search = array('leads.name','leads.lname','leads.mobile','leads.work', 'leads.stage','cm.name', 'u.name', 'st.type_name'); //set column field database for datatable searchable just firstname , lastname , address are searchable
    var $order = array('lead_id' => 'desc'); // default order 
	public function __construct() {
		parent::__construct();
	}
	private function _get_datatables_query($company_id =null,$start_date =null,$end_date =null,$user_id =null){
       // echo 'Test'.$company_id."<br>".$start_date."<br>".$end_date;exit;
        $this->db->select('leads.*, cm.name company_name, u.name sales_user_name, st.type_name, llife.lifecycle lifecycle_stage');
        $this->db->from($this->table);
        $this->db->join('company_master cm', 'cm.company_id = leads.company_id', 'left');
        $this->db->join('users u', 'u.id = leads.sale_owner', 'left');
        $this->db->join('subscription_types st', 'st.subscription_type_id = leads.subscription_status', 'left');
        $this->db->join('lead_lifecycle llife', 'llife.lead_lifecycle_id = leads.lifecycle_stage', 'left');
        if($start_date){
            $this->db->where("DATE_FORMAT(schedule_for_contact,'%Y-%m-%d')>=",$start_date);
        }
        if($end_date){
            $this->db->where("DATE_FORMAT(schedule_for_contact,'%Y-%m-%d')<=",$end_date);
        }
        // if(!empty($user_id) && $user_id !='1'){
        //     $this->db->where("leads.user_id",$user_id);
        // }
        if(!empty($company_id)){
            $this->db->where("leads.company_id",$company_id);
        }

        $i = 0;
        //print_r($this->column_search); die;
        foreach ($this->column_search as $item){ // loop column 
            if($_POST['search']['value']){ // if datatable send POST for search
                 
                if($i===0){ // first loop
					$this->db->group_start(); // open bracket. query Where with OR clause better with bracket. because maybe can combine with other WHERE with AND.
                    $this->db->like($item, trim($_POST['search']['value']));
                }
                else{
                    $this->db->or_like($item, trim($_POST['search']['value']));
                }
				if(count($this->column_search) - 1 == $i) //last loop
                $this->db->group_end(); //close bracket
            }
            $i++;
        }
         
        if(isset($_POST['order'])){ // here order processing
			$this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        }else if(isset($this->order)){
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
        
    }
	public function get_datatables($company_id,$start_date,$end_date,$user_id){	
        //echo $company_id;exit;
        $this->_get_datatables_query($company_id,$start_date,$end_date,$user_id);
        //get olny active/inactive status request
        $this->db->where("leads.status !=",3);
        if($_POST['length'] != -1)
        $this->db->limit($_POST['length'], $_POST['start']);
        $query = $this->db->get();
        //echo $this->db->last_query();exit;
        return $query->result();
    }
	public function count_filtered($start_date,$end_date){
        $this->_get_datatables_query($start_date,$end_date);
        $query = $this->db->get();
        return $query->num_rows();
    }
    public function count_all($start_date,$end_date){
        $this->db->from($this->table);
        $this->db->where("DATE_FORMAT(created_at,'%Y-%m-%d')>=",$start_date);
        $this->db->where("DATE_FORMAT(created_at,'%Y-%m-%d')<=",$end_date);
        $this->db->where("status !=",3);
        return $this->db->count_all_results();
    }
	public function get_details($user_id){
		$this->db->select('*');
		$this->db->from($this->table);
		$this->db->where('id',$user_id);
		$query=$this->db->get();
		return $query->row_array();
    }
    /**
     * get lead details for leads
     *  ** Chayan
     */
    public function getDetails($lead_id = 0)
    {
        $this->db->select('leads.*,leads.updated_at lead_update_on, cm.name company_name, u.name sales_user_name, st.type_name');
        $this->db->from($this->table);
        $this->db->join('company_master cm', 'cm.company_id = leads.company_id', 'left');
        $this->db->join('users u', 'u.id = leads.sale_owner', 'left');
        $this->db->join('subscription_types st', 'st.subscription_type_id = leads.subscription_status', 'left');
        $this->db->where('lead_id', $lead_id);
        return $this->db->get()->result_array();
    }

	public function update($condition,$data){
		$this->db->where($condition);
		$this->db->update($this->table,$data);
		return 1;
	}
	public function add($data){
		$this->db->insert($this->table,$data);
		return true;
	}
	public function delete($condition){
		$this->db->delete($this->table,$condition);
		return 1;
	}

    public function get_users($company_id){
        $this->db->select('*');
        $this->db->from('users');
        $this->db->where('role_id','3');
        $this->db->where('company_id',$company_id);
        $this->db->where('status','1');
        $query=$this->db->get();
        //echo $this->db->last_query();die;
        return $query->result_array();
    }

    public function get_assign_details($project_id){
        $this->db->select('*');
        $this->db->from('assign_project');
        $this->db->where('project_id',$project_id);
        $query=$this->db->get();
        return $query->row_array();
    }
}