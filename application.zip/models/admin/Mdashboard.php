<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mdashboard extends CI_Model {

	public function __construct() {
		parent::__construct();
	}	
	
	
	public function total_project($status)
	{
		$this->db->select('count(*)'.$status);
		$this->db->from('new_project');
		$this->db->where('status',$status);
		$query=$this->db->get();		
        return $query->row_array();
	}
	public function get_assigned_project($user_id)
	{
		$this->db->select('count(*) total_project');
		$this->db->from('assign_project');
		$this->db->where('user_id',$user_id);
		$query=$this->db->get();		
        return $query->row_array();
	}
	private function _get_datatables_query($company_id,$start_date,$end_date,$flag =null,$status =null,$Source =null){
		//echo $flag;exit;
		$table = 'new_project';
	    $column_order = array('id','name','email_id','phone','schedule_for_contact','status','quotation_price','closing_price','assign_status'); //set column field database for datatable orderable
	   	$column_search = array('name','email_id','phone','schedule_for_contact','status','quotation_price','closing_price','assign_status'); //set column field database for datatable searchable just firstname , lastname , address are searchable
	    $order = array('id' => 'desc');
        $this->db->select('new_project.*,assign_project.user_id');
        $this->db->from($table);
        $this->db->join('assign_project', 'assign_project.project_id = new_project.id', 'left');
        if($start_date){
        	$this->db->where("DATE_FORMAT(post_date,'%Y-%m-%d')>=",$start_date);
        }
        if($end_date){
        	$this->db->where("DATE_FORMAT(post_date,'%Y-%m-%d')<=",$end_date);
        }
        if($flag == 'conversion' || $flag == 'ARR'){
        	$this->db->where("closing_price !=",'0.00');
        }
        if($flag == 'SAL'){
        	$this->db->where("assign_status",'assigned');
        	$this->db->where("status",'open');
        }
        if($flag == 'SQL'){
        	$this->db->where("assign_status",'assigned');
        	$this->db->where("status",'close');
        }
        if(!empty($status)){        	
        	$this->db->where("status",$status);
        }
        if(!empty($Source)){        	
        	$this->db->where("source_type",$Source);
        }
        $this->db->where("company_id",$company_id);
		$i = 0;
		
		/*Validate user except super admin & company administrator*/
		$adminData = $this->session->userdata('admin');
		if($adminData['role_id'] != 1 && $adminData['role_id'] != 2){
		    $this->db->where("assign_project.user_id",$adminData['id']);
		}
     
        if(isset($_POST['order'])){ // here order processing
			$this->db->order_by($column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        }else if(isset($order)){

            $this->db->order_by(key($order), $order[key($order)]);
        }
    }
	public function dashboardCount($company_id,$start_date,$end_date,$flag = null,$status = null,$Source = null){	
       //echo $flag;exit;
        $this->_get_datatables_query($company_id,$start_date,$end_date,$flag,$status,$Source);
        
        $query = $this->db->get();
      //echo $this->db->last_query();exit;
        return $query->result();
    }
    // public function dashboardCount2($start_date,$end_date,$flag = null,$status = null,$Source = null){	
    //    //echo $status;exit;
    //     $this->_get_datatables_query($start_date,$end_date,$flag,$status,$Source);
        
    //     $query = $this->db->get();
    //   echo $this->db->last_query();exit;
    //     return $query->result();
    // }
    public function getLeadsListByMonth($company_id,$start_date= null,$end_date= null,$flag = null,$status = null,$Source = null){
       // $sql ="SELECT *, YEAR(post_date) AS YEAR, MONTHNAME(post_date) AS MONTH, WEEK(post_date) AS WEEK, MINUTE(post_date) AS MINUTE FROM new_project GROUP BY YEAR(post_date) order by post_date ASC";
      $where=array();
    //   if($start_date){
    //     	$this->db->where("DATE_FORMAT(post_date,'%Y-%m-%d')>=",$start_date);
    //     }
    //     if($end_date){
    //     	$this->db->where("DATE_FORMAT(post_date,'%Y-%m-%d')<=",$end_date);
    //     }
      if($status!=""&&$status!=null)
      {
         $where[]= "status=".$status;
      }
      
       if($Source!=""&&$Source!=null)
      {
         $where[]= "source_type=".$Source;
      }
      $whereStr="";
      if(!empty($where))
      {
          $where=implode("AND",$where);
      }
      if($whereStr!="")
      {
          $whereStr=" where ".$where;
      }
      $sql ="SELECT *, YEAR(post_date) AS YEAR, MONTHNAME(post_date) AS MONTH, WEEK(post_date) AS WEEK, MINUTE(post_date) AS MINUTE FROM new_project ".$whereStr." GROUP BY YEAR(post_date) order by post_date ASC";
      //echo $sql;exit;
        $Query = $this->db->query($sql);
        $rows = $Query->result_array();

        $result =  array(); $i=0; $temp = array();
        foreach ($rows as $row) {
            $this->db->select('MONTHNAME(post_date)');       
            $this->db->from('new_project');       
            $this->db->where('YEAR(post_date)',$row['YEAR']);
            $this->db->where('YEAR(post_date)',$row['YEAR']);
            $this->db->where('YEAR(post_date)',$row['YEAR']);
            $this->db->where("company_id",$company_id);
            $this->db->group_by('MONTH(post_date)');
            $this->db->order_by('post_date','ASC');
            $query = $this->db->get();
            $temp[$i][$row['YEAR']] = $query->result_array();
            foreach ($temp[$i][$row['YEAR']] as $raw) {
              $this->db->select('*');   
              $this->db->from('new_project');       
              $this->db->where('MONTHNAME(post_date)',$raw['MONTHNAME(post_date)']);
              $this->db->where('YEAR(post_date)',$row['YEAR']);
              $this->db->where("company_id",$company_id);
              $this->db->order_by('post_date','ASC');
              $query = $this->db->get();
              $result[$i][$row['YEAR']][$raw['MONTHNAME(post_date)']] = $query->result_array();

            }
            $i++;
        }
        return $result;
    }
    
}