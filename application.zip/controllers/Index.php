<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Index extends CI_Controller {

	public function __construct() {
		parent::__construct();
	}
	
	public function index()
	{
		redirect('web-designing');
	}

	public function mobile_app()
	{
		if ($this->input->server('REQUEST_METHOD') == 'POST') {
			$name = $this->input->post('name');
			$email = $this->input->post('email');
			$phone = $this->input->post('phone');
			//$schedule = date('Y-m-d H:i', strtotime($this->input->post('schedule')));
			$message = $this->input->post('message');

			$input_data = array(
				'name' => $name,
				'email_id' => $email,
				'phone' => $phone,
				//'schedule_for_contact' => $schedule,
				'message' => $message,
				'status' => 'open',
				'assign_status' => 'unassigned',
				'post_date' => date('Y-m-d H:i:s')
			);
			$this->db->insert('new_project',$input_data);
			//$this->session->set_flashdata('success_msg','Thank You for contacting with us! We will get back you soon.');
			redirect('thank-you');
		}
		$this->load->view('mobile_app');
	}
	public function web_development()
	{
		if ($this->input->server('REQUEST_METHOD') == 'POST') {
			$name = $this->input->post('name');
			$email = $this->input->post('email');
			$phone = $this->input->post('phone');
			//$schedule = date('Y-m-d H:i', strtotime($this->input->post('schedule')));
			$message = $this->input->post('message');

			$input_data = array(
				'name' => $name,
				'email_id' => $email,
				'phone' => $phone,
				//'schedule_for_contact' => $schedule,
				'message' => $message,
				'status' => 'open',
				'assign_status' => 'unassigned',
				'post_date' => date('Y-m-d H:i:s')
			);
			$this->db->insert('new_project',$input_data);
			//$this->session->set_flashdata('success_msg','Thank You for contacting with us! We will get back you soon.');
			redirect('thank-you');
		}
		$this->load->view('web_development');
	}
	
	public function web_design()
	{
		if ($this->input->server('REQUEST_METHOD') == 'POST') {
			$name = $this->input->post('name');
			$email = $this->input->post('email');
			$phone = $this->input->post('phone');
			//$schedule = date('Y-m-d H:i', strtotime($this->input->post('schedule')));
			$message = $this->input->post('message');

			$input_data = array(
				'name' => $name,
				'email_id' => $email,
				'phone' => $phone,
				//'schedule_for_contact' => $schedule,
				'message' => $message,
				'status' => 'open',
				'assign_status' => 'unassigned',
				'post_date' => date('Y-m-d H:i:s')
			);
			$this->db->insert('new_project',$input_data);
			//$this->session->set_flashdata('success_msg','Thank You for contacting with us! We will get back you soon.');
			redirect('thank-you');
		}
		$this->load->view('index');
	}
	
	public function thank_you(){
	    $this->load->view('thankYouPage');
	}
	
	public function wp_insert()
	{
		if ($this->input->server('REQUEST_METHOD') == 'POST') {
			$name = $this->input->post('wp_name');
			$email = $this->input->post('wp_email');
			$phone = $this->input->post('wp_phone');
			//$schedule = date('Y-m-d H:i', strtotime($this->input->post('wp_schedule')));
			$time_zone = $this->input->post('wp_from_time_zone');
			$from_time = date('h:i a', strtotime($this->input->post('wp_from_time')));
			$to_time = date('h:i a', strtotime($this->input->post('wp_to_time')));
			$message = $this->input->post('wp_message');
			$domain_website = $this->input->post('wp_domain_name');
			$requirement = $this->input->post('wp_requirement');
			$others = $this->input->post('wp_requirement_others');

			$input_data = array(
				'name' => $name,
				'email_id' => $email,
				'phone' => $phone,
				//'schedule_for_contact' => $schedule,
				'time_zone' => $time_zone,
				'from_time' => $from_time,
				'to_time' => $to_time,
				'message' => $message,
				'domain_website' => $domain_website,
				'requirement' => $requirement,
				'requirement_other' => $others,
				'status' => 'open',
				'assign_status' => 'unassigned',
				'post_date' => date('Y-m-d H:i:s')
			);
			$id = $this->db->insert('new_project',$input_data);
			if(!empty($id)){
			    redirect("https://www.fitser.com/campaign/web-designing/thankyou/?success=ok");
			}else{
			    redirect("https://www.fitser.com/campaign/web-designing");
			}
		}else{
		    redirect("https://www.fitser.com/campaign/web-designing");
		}
	}
}