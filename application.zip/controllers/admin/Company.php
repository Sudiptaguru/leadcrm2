<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Company extends MY_Controller
{
    public function __construct() {
        parent::__construct();
        $this->redirect_guest();
        $this->admin=$this->session->userdata('admin');
        
        $this->load->model('common_model');
    }
    private function outputJson($response){
        header('Content-Type: application/json');
        echo json_encode($response);
        exit;
    }
    public function index()
    {
        $data['content']        = 'admin/company/list';
        $this->load->view('admin/layouts/index', $data);
    }
    public function save()
    {
       	if($this->input->post()){  
            if(empty(trim($this->input->post('compId')))){     
            	$this->form_validation->set_rules('company_name','company name','required');
				$this->form_validation->set_rules('company_email','company email','trim|valid_email|is_unique[users.email]',array('is_unique'=>'This %s already exists.'));
				
				if($this->form_validation->run()==FALSE){
					$data['content']        = 'admin/company/add';
        			$this->load->view('admin/layouts/index', $data);
				}
				else{
	                $insertArray = [
	                    "name"                 => $this->input->post('company_name'),
	                    "company_email"        => $this->input->post('company_email'),
	                    "company_phone"        => $this->input->post('company_phone')
	                ];

	                $insert_id  = $this->common_model->add('company_master', $insertArray);
	                if($insert_id){ 	
	                	$insrt_user_arr	= array('company_id' => $insert_id,
	                							'name'		 => $this->input->post('company_name'),
	                							'email'		 =>	$this->input->post('company_email'),
	                							'password'	 => sha1('123456'),
	                							'role_id'	 => '1',
	                							'status'	 => '1'
	                							);
						$this->common_model->add('users', $insrt_user_arr);   
	/*****************  Company Login details  mail ****************************/
						$logo                     = base_url('public/images/logo.png'); 
						//$mail['to']               = $this->input->post('company_email'); 
						$mail['to']               = 'sreelabiswas.kundu@met-technologies.com';  
						$mail['name']			  = $this->input->post('company_name');
						$mail['subject']          = 'Fitser PPC- Login Details';                             
						$mail_temp                = file_get_contents('./global/mail/registration_template.html');
						$mail_temp                = str_replace("{web_url}", base_url(), $mail_temp);
						$mail_temp                = str_replace("{logo}", $logo, $mail_temp);
						$mail_temp                = str_replace("{shop_name}", 'Fitser PPC', $mail_temp);  
						$mail_temp                = str_replace("{name}", $this->input->post('company_name'), $mail_temp);
						$mail_temp                = str_replace("{username}", $this->input->post('company_email'), $mail_temp);
						$mail_temp                = str_replace("{password}", '123456', $mail_temp);
						$mail['message']          = $mail_temp;
						$msg 					  = registration_mail($mail);
	                    $this->session->set_flashdata('success_msg', 'New Company Successfully Added !!!');
	                    //$this->session->set_flashdata('color', '#7cff9a');
	                }else{
	                    $this->session->set_flashdata('error_msg', 'Unable to add company!!');
	                    //$this->session->set_flashdata('color', '#ff394c');
	                }
	                redirect('admin/company');
                }
            } else {
                //echo "hdga";exit;
               
                $this->form_validation->set_rules('company_name','company name','required');
               
			    $this->form_validation->set_rules('company_email','company email','trim|required|valid_email|callback_check_email',array('check_email'=>'This %s already exists.'));
				
				if($this->form_validation->run()==FALSE){
					if($this->input->post('compId') != '') {
			            $where['company_id']        =   $this->input->post('compId');
			            $where['status !=']         =   3; 
			            $data['company']            =   $this->common_model->get('company_master',null,$where,null,null,null,null,null,null,null,null,'row');
			        }
					$data['content']        = 'admin/company/add';
        			$this->load->view('admin/layouts/index', $data);
				}
				else{
	                $updateArray = [
	                    "name"                 => $this->input->post('company_name'),
	                    "company_email"        => $this->input->post('company_email'),
	                    "company_phone"        => $this->input->post('company_phone'),
	                    "date_of_update"       => date('Y-m-d h:i:s')
	                ];
	                
	                if($this->common_model->update('company_master',$updateArray, array("company_id" => $this->input->post('compId')))){
	                    
	                	$update_user_Array = [
		                    'name'		 => $this->input->post('company_name'),
	                		'email'		 =>	$this->input->post('company_email'),
		                ];
		                $this->common_model->update('users',$update_user_Array, array("company_id" => $this->input->post('compId'),"role_id" =>'1'));
	                    $this->session->set_flashdata('success_msg', 'Company Successfully Updated !!!');
	                    //$this->session->set_flashdata('color', '#7cff9a');
	                }else{
	                    $this->session->set_flashdata('error_msg', 'Unable to update company!!!');
	                    //$this->session->set_flashdata('color', '#ff394c');
	                }
	               // redirect('admin/company/edit/'. $this->input->post('compId'));
                    redirect('admin/company');
           		}
            }
        }
        
    }
    public  function check_email() {
       $email = $this->input->post('company_email');
       $company_id = $this->input->post('company_id');
       $role_id = '1';
       $result = $this->common_model->check_email_exist($email,$company_id,$role_id);
       return $result;
    }
    public function getCompanyList(){
        
        $where = array();
        if($this->admin['role_id'] !='2'){
        	$cond['company_id'] =  $this->admin['company_id'];
    	}
        $cond['status !=']  =  3;   
        $dataObj            =  $this->common_model->get('company_master',null, $cond,null,null,null,null,'company_id','desc',null,null,'result');
        $data['details']    = $dataObj;
		if($this->input->post('source') == 'WEB'){
			$html = $this->load->view('admin/company/ajax_list', $data, true);
			//print $html;
			$this->response=array('status'=>array('error_code'=>0,'message'=>'Success'),'result'=>$html);
		}else{
			$this->response=array('status'=>array('error_code'=>0,'message'=>'Success'),'result'=>$dataObj);
		}
        $this->outputJson($this->response);
    }
    public function add($id=''){
        $menu_permission_arr            = array();    
        if ($id != '') {
            $where['company_id']        =   $id;
            $where['status !=']         =   3; 
            $data['company']               =   $this->common_model->get('company_master',null,$where,null,null,null,null,null,null,null,null,'row');
        }
        
        $data['content']        = 'admin/company/add';
        $this->load->view('admin/layouts/index', $data);
    }
    public function delete(){
        //pr($_POST);
        if($this->input->post()){
            $id = $this->input->post('id');
            $table = $this->input->post('table');

            if($this->common_model->update($table,array('status'=>'3'),array('company_id'=>$id))){
                $response['status'] =1;
                $response['message'] = "Deleted successfully done.";
            }else{
                $response['status'] =0;
                $response['message'] = "Unable to deleted.";
            }

            echo json_encode($response);
        }
    }
    
}