<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Leads extends MY_Controller {

	public function __construct() {
		ini_set('display_errors', 1);
		parent::__construct();
		$this->redirect_guest();
		$this->admin = $this->session->userdata('admin');
		
		$this->load->model('admin/mproject');
		$this->load->model('mcommon');
	}
	public function index() { 
		
		$this->_load_list_view();
	}
	public function all_content_list(){
		//print_r($this->admin);
		if($this->admin['role_id'] != '2'){
			if($this->admin['role_id'] == '1'){
				$user_id = '';
			}
			else{
				$user_id =	$this->admin['id'];
			}
			$company_id	= $this->admin['company_id'];
		}
		else{
			$company_id	= '';
			$user_id	= '';
		}		
		$start_date = $_POST['start_date'];
		$end_date = $_POST['end_date'];
		$admin=$this->session->userdata('admin');
		//echo 'company_id'.$company_id;
		$list = $this->mproject->get_datatables($company_id,$start_date,$end_date,$user_id);
		// echo $this->db->last_query();
		// print_r($list); die;
       //$users = $this->mproject->get_users();
        $data = array();
        $no = $_POST['start'];
		$i=1;
        foreach ($list as $project) {
            $no++;
            $row = array();
			$row[]='<input type="checkbox" id="lead-'.$project->lead_id.'">';
			$row[] = '<a href="'.base_url('admin/leads/edit/'.$project->lead_id).'" class="company-title">'.$project->name.' '.$project->lname.'<br><span>'.$project->company_name.'</span></a>';
			
			// if($project->stage=="new"){$html = '<span style="color:green">New</span>';}
            // else if($project->stage=="contacted"){$html = '<span style="color:orange">Contacted</span>';}
            // else if($project->stage=="interested"){$html = '<span style="color:red">Interested</span>';}
            // else if($project->stage=="under review"){$html = '<span style="color:red">Under review</span>';}
            // else if($project->stage=="demo"){$html = '<span style="color:red">Demo</span>';}
            // else if($project->stage=="converted"){$html = '<span style="color:red">Converted</span>';}
            // else{$html = '<span style="color:red">Unqualified</span>';}
			$row[] = '<span>'.$project->lifecycle_stage.'<p style="color:#3c8dbc">'.$project->stage.'</p></span>';	//status/stage
			$row[] = date('d-M-Y h:ia', strtotime( $project->updated_at));			
            $row[] = $project->sales_user_name;
            $row[] = $project->work;
            //$row[] = ($project->assign_status=="assigned"?'<span style="color:green">Assigned</span>':'<span style="color:red">Unassigned</span>');
			//$row[] = '<a class="cstm_view" href="'.base_url('admin/leads/edit/'.$project->id).'" title="Edit"><i class="glyphicon glyphicon-edit"></i></a><a class="cstm_view" href="'.base_url('admin/leads/message_list/'.$project->id).'" title="Messages"><i class="glyphicon glyphicon-book"></i></a>'
			$row[] = '<div class="dropdown"><a href="" class="dropdown-toggle" type="button" data-toggle="dropdown"
						aria-haspopup="true" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
					<div class="dropdown-menu">
						<a class="dropdown-item" href="#">Add task</a>
						<a class="dropdown-item action" href="#" id="edit" title="Edit" data-id="'.$project->lead_id.'">Edit</a>
						<a class="dropdown-item action" href="#" id="clone" title="Clone" data-id="'.$project->lead_id.'">Clone</a>
						<a class="dropdown-item action" id="delete" title="Delete" data-id="'.$project->lead_id.'" href="#">Delete</a>
					</div>
				</div>';
       
			$data[] = $row;
			$i++;
        }
        $output = array(
                        "draw" => $_POST['draw'],
                        "recordsTotal" => $this->mproject->count_all($start_date,$end_date),
                        "recordsFiltered" => $this->mproject->count_filtered($start_date,$end_date),
                        "data" => $data,
                );
        echo json_encode($output);
	}
	public function edit($id){
		$data['project']=$this->mproject->getDetails($id);
		$data['projectEmail'] = $this->common_model->select_row('lead_emails', ['lead_id'=> $id, 'is_default'=> 1], 'lead_emails.*');
		$data['projectDetails'] = $this->common_model->select_row('lead_details', ['lead_id '=> $id], 'lead_details.*');
		
		if(empty($data['project'])){
			$this->_load_list_view();
		}else{
			$this->_load_details_view($data);
		}
	}
	
	public function message($id){
		$data['content'] = 'admin/leads/add_message';
		$data['lead_id'] = $id;
		$condition['id'] = $id;
		$row1=$this->mcommon->getRow("new_project",$condition);
		$data['project_name'] = $row1['title'].' '.$row1['name'].' '.$row1['lname'];
		$this->load->view('admin/layouts/index', $data);	
	}
	
	public function add_message(){
	/*
		$id=$this->input->post('client_id');
		$client_query = $this->db->query("SELECT * FROM new_project where id='$id'");  
		foreach ($client_query->result() as $row): 
		$phone=$phone->phone;
		endforeach;	
	*/
    $client_id=$this->input->post('client_id');
	$user_id=$this->session->userdata('admin')['id'];
	$data = array(
      'lead_id' => $this->input->post('client_id'),
      'message' => $this->input->post('msg'),
      'user_id' => $user_id,
        ); 

	if($this->db->insert('lead_message', $data)) {
		$code_id = $this->db->insert_id();
	$msg="Message Send Successfully.";   
		$this->session->set_flashdata('client_msg', $msg);
	} else {
	$msg="Error Message.";   
		$this->session->set_flashdata('client_msg', $msg);
	}   
    
     redirect('admin/leads/message_list/'.$client_id);  	
	}
	
	public function message_list($id){
		$data['content'] = 'admin/leads/message_list';
		$data['lead_id'] = $id;
	    $messageList=$this->mcommon->getMessageList($id);
	    $data['messageList']=$messageList;
	    $condition['id'] = $id;
		$row1=$this->mcommon->getRow("new_project",$condition);
		$data['project_name'] = $row1['title'].' '.$row1['name'].' '.$row1['lname'];
		$this->load->view('admin/layouts/index', $data);	
	}
	
	public function delete1(){
        //pr($_POST);
        if($this->input->post()){
            $id =$this->input->post('id');
            $table = $this->input->post('table');

            if($this->common_model->update1($table,array('id'=>$id))){
                //$response['status'] =1;
                $response['message'] = "Deleted successfully done.";
            }else{
                //$response['status'] =0;
                $response['message'] = "Unable to deleted.";
            }

            echo json_encode($response);
        }
    }
	
	public function delete_message() {
	        $quote_art_id=$this->input->get('id');
	        $m_id=$this->input->get('m_id');
	        $this->db->query("DELETE FROM lead_message WHERE `id` = '$quote_art_id'");
	        redirect(base_url('admin/leads/message_list/'.$m_id));
            }

	public function edit_message(){
	$this->load->view('admin/layouts/header');	
	$this->load->view('admin/layouts/leftsidebar');	
	$this->load->view('admin/leads/edit_message');
    $this->load->view('admin/layouts/footer');	
	}
	
	public function update_message(){
	$id=$this->input->post('message_id');	
    $client_id=$this->input->post('client_id');
	$data = array(
      'message' => $this->input->post('msg')
        ); 
    $this->db->where('id',$id);
	$this->db->update('lead_message', $data);
	$msg="Message Send Successfully.";   
	$this->session->set_flashdata('client_msg', $msg);
    redirect('admin/leads/message_list/'.$client_id);  	
	}
	
	public function update(){
		if($this->input->post()){
			$id=$this->input->post('project_id');
			//$this->form_validation->set_rules('project_description','Project Description');
			//$this->form_validation->set_rules('quotation_price','Quotation Price');
			//$this->form_validation->set_rules('closing_price','Closing Price');
// 			if($this->form_validation->run()==FALSE){
// 			    echo 1;die;
// 				$data['project']=$this->mproject->get_details($id);
// 				$this->_load_details_view($data);
// 			}else{
				$condition=array('id'=>$id);
				$udata['project_name']=$this->input->post('project_name');
				$udata['project_description']=$this->input->post('project_description');
				$udata['quotation_price']=$this->input->post('quotation_price');
				$udata['closing_price']=$this->input->post('closing_price');
				$udata['commission']=$this->input->post('commission_price');
				$udata['currency']=$this->input->post('currency');
				$udata['status']=$this->input->post('status');
				$udata['assign_status'] = 'assigned';
				$this->mproject->update($condition,$udata);
                //echo 2;
				$project = $this->mproject->get_assign_details($id);
				if($this->input->post('user')>0){
    				if (empty($project)) {
    					$insert_data = array(
    						'project_id' => $id,
    						'user_id'	=> $this->input->post('user'),
    						'assign_date' => date('Y-m-d')
    					);
    					$this->db->insert('assign_project',$insert_data);
    				} else {
    					$update_data = array(
    						'project_id' => $id,
    						'user_id'	=> $this->input->post('user')
    					);
    					$this->db->where('id',$project['id']);
    					$this->db->update('assign_project',$update_data);
    				}
				}
				//echo 3;
				$this->session->set_flashdata('success_msg','Detail updated successfully');
				redirect('admin/leads');
		//	}
		}else{
			$this->_load_list_view();
		}
	}
	public function delete_content(){
		$condition['id']=$this->input->post('id');
		$this->mproject->delete($condition);
		$response=array('status'=>1,'message'=>'Success');
		echo header('Content-Type: application/json');
		echo json_encode($response);
	}
	private function _load_list_view() {
		$data['admin'] = $this->admin;
		$data['content'] = 'admin/leads/leads-list';
		$this->load->view('admin/layouts2/index', $data);
	}
	private function _load_details_view($parms){
		$data['admin'] = $this->admin;
		$data['project']=$parms['project'];
		$data['projectEmail']=$parms['projectEmail'];
		$data['projectDetails']=$parms['projectDetails'];
		$company_id=$data['project'][0]['company_id'];
        $users = $this->mproject->get_users($company_id);
        
        //$assigned_data = $this->mproject->get_assign_details($data['project']['id']);
        
        // $data['assigned_data'] = $assigned_data;
		// $data['users'] = $users;
		$data['content'] = 'admin/leads/leads-details';
		$this->load->view('admin/layouts2/index', $data);
	}
	private function _load_add_view(){
		$data['roles'] = $this->mproject->get_roles();
		$data['content']='admin/leads/add';
		$this->load->view('admin/layouts/index',$data);
	}

	public function assign_project()
	{
		$project_id = $this->input->post('project_id');
		$project = $this->mproject->get_assign_details($project_id);
		if (empty($project)) {
			$insert_data = array(
				'project_id' => $project_id,
				'user_id'	=> $this->input->post('user_id'),
				'assign_date' => date('Y-m-d')
			);
			$this->db->insert('assign_project',$insert_data);
		} else {
			$update_data = array(
				'project_id' => $project_id,
				'user_id'	=> $this->input->post('user_id')
			);
			$this->db->where('id',$project['id']);
			$this->db->update('assign_project',$update_data);
		}
		$update_data = array(
			'assign_status' => 'assigned'
		);
		$this->db->where('id',$project_id);
		$this->db->update('new_project',$update_data);
		$response=array('status'=>1,'message'=>'Success');
		echo header('Content-Type: application/json');
		echo json_encode($response);
	}
	
	public function delete(){
        if($this->input->post()){
            $id = $this->input->post('id');
            $table = $this->input->post('table');

            if($this->common_model->update($table,array('status'=>'3'),array('company_id'=>$id))){
                $response['status'] =1;
                $response['message'] = "Deleted successfully done.";
            }else{
                $response['status'] =0;
                $response['message'] = "Unable to deleted.";
            }

            echo json_encode($response);
        }
	}
	
	/**
	 * Add lead by chayan
	 */
	public function addStore(){
		//print_r($this->input->post());
		if($this->session->userdata('admin')){
			if($postArray = $this->input->post()){
				//check request is for save or update
				$leadArray = array(
					'name'			=> $postArray['first_name'],
					'lname'			=> $postArray['last_name'],
					'mobile'		=> $postArray['mobile'],
					'sale_owner'	=> $postArray['sales_owner'],
					'lifecycle_stage'=> isset($postArray['lifecycle_stage'])?$postArray['lifecycle_stage']:'New',
					'updated_at'	=> date('Y-m-d h:i:s')
				);
				//precess for unrequired fields
				if(isset($postArray['work'])){
					$leadArray['work'] = $postArray['work'];
				}
				if(isset($postArray['stage'])){
					$leadArray['stage'] = $postArray['stage'];
				}
				if(isset($postArray['subscription_status'])){
					$leadArray['subscription_status'] = $postArray['subscription_status'];
				}
				if(isset($postArray['company_name'])){
					$leadArray['company_id'] = $postArray['company_name'];
				}
				if(isset($postArray['accounts'])){
					$leadArray['accounts'] = $postArray['accounts'];
				}
				if(isset($postArray['subscription_status'])){
					$leadArray['subscription_status'] = $postArray['subscription_status'];
				}
				if(isset($postArray['subscription_type'])){
					$leadArray['subscription_type'] = $postArray['subscription_type'];
				}
				if(isset($postArray['lost_reason'])){
					$leadArray['lost_reason'] = $postArray['lost_reason'];
				}

				//echo $leadArray; die;
				if(isset($postArray['lead_id']) && !empty($postArray['lead_id'])){
					$lead_id = $postArray['lead_id'];
					if($this->common_model->update('leads', $leadArray, ['lead_id'=> $lead_id])){
						//echo $this->db->last_query(); die;
						if($postArray['email']){
							$lead_email = [];
							for($i=0; $i< count($postArray['email']); $i++){
								$isExists = $this->common_model->select_row('lead_emails le', ['le.lead_id'=> $lead_id, 'le.email'=>trim($postArray['email'][$i])], 'le.*');
								if($isExists){
									$leadEmail = array(
										'email'=> trim($postArray['email'][$i]),
										'label_for'=> $postArray['pick_label'][$i],
										'status'=> 1
									);
									$this->common_model->update('lead_emails', $leadEmail, ['lead_email_id '=> $isExists->lead_email_id]);
								}else{
									$lead_email[] = array(
										'email'=> trim($postArray['email'][$i]),
										'label_for'=> $postArray['pick_label'][$i],
										'lead_id'=> $lead_id,
										'is_default'=> $i==0?1:0
									);
								}
							}
							if($lead_email){
								$this->common_model->batch_insert('lead_emails', $lead_email);
							}
						}
						/*--------------------*--------------------------------------------- */
						//add to activity log
						$log_array = array(
							'lead_id'=> $lead_id,
							'action'=> 'Update Lead',
							'message'=> 'Update lead information',
							'user_id'=> $this->admin['id'],
							'created_at'=> date('Y-m-d h:ia'),
						);
						//Add log
						$this->common_model->add('lead_logs', $log_array);
						/*--------------------*--------------------------------------------- */
						$this->response = array('status' => array('error_code' => 0, 'message' => 'Lead updated successfully'), 'result' => array('data' => $this->obj));
					}else{
						$this->response = array('status' => array('error_code' => 1, 'message' => 'Unknown error, Unable to update lead'), 'result' => array('data' => $this->obj));
					}
				}else{
					if($lead_id = $this->common_model->add('leads', $leadArray)){
						if($postArray['email']){
							$lead_email = [];
							for($i=0; $i< count($postArray['email']); $i++){
								$lead_email[] = array(
									'email'=> trim($postArray['email'][$i]),
									'label_for'=> $postArray['pick_label'][$i],
									'lead_id'=> $lead_id,
									'is_default'=> $i==0?1:0
								);
							}
							if($lead_email){
								if($this->common_model->batch_insert('lead_emails', $lead_email)){
									$this->response = array('status' => array('error_code' => 0, 'message' => 'Lead added successfully'), 'result' => array('data' => $this->obj));
								}
							}
						}
						/*--------------------*--------------------------------------------- */
						//add to activity log
						$log_array = array(
							'lead_id'=> $lead_id,
							'action'=> 'Add Lead',
							'message'=> 'Add a new lead ',
							'user_id'=> $this->admin['id'],
							'created_at'=> date('Y-m-d h:ia'),
						);
						//Add log
						$this->common_model->add('lead_logs', $log_array);
						/*--------------------*--------------------------------------------- */
					}else{
						$this->response = array('status' => array('error_code' => 1, 'message' => 'Unknown error, Unable to add lead'), 'result' => array('data' => $this->obj));
					}

					// if($lead_id = $this->common_model->add('leads', $leadArray)){
					// 	$this->response = array('status' => array('error_code' => 0, 'message' => 'Lead added successfully'), 'result' => array('data' => $this->obj));
					// }else{
					// 	$this->response = array('status' => array('error_code' => 1, 'message' => 'Unknown error, Unable to add lead'), 'result' => array('data' => $this->obj));
					// }
				}
			}else{
				//empty request
				$this->response = array('status' => array('error_code' => 1, 'message' => 'Unable to parse request'), 'result' => array('data' => $this->obj));

			}
		}
		header('Content-Type: application/json');
		echo json_encode($this->response);
		exit;
	}

	/*
		* @request id
		* response lead info
		* By chayan
	*/
	public function getLead()
	{
		$result['data'] = $this->mproject->getDetails($this->input->get('id'));
		$this->db->where(['lead_id'=> $this->input->get('id'), 'status'=> 1]);
		$result['email'] = $this->db->get('lead_emails')->result();
		//$result['q'] = $this->db->last_query();
		if($result){
			$this->response = array('status' => array('error_code' => 0, 'message' => 'success'), 'result' => array('data' => $result));
		}else{
			$this->response = array('status' => array('error_code' => 1, 'message' => 'Unable to get result'), 'result' => array('data' => $this->obj));
		}
		header('Content-Type: application/json');
		echo json_encode($this->response);
		exit;
	}

	public function updateStatus()
	{
		$updateArray = array($this->input->post('column')=> $this->input->post('status'));
		if($this->input->post('column') == 'stage'){
			$updateArray['updated_at'] = date('Y-m-d H:i:s a');
		}
		if($this->common_model->update('leads', $updateArray, ['lead_id '=> $this->input->post('id')])){
			//echo $this->db->last_query();
			$this->response = array('status' => array('error_code' => 0, 'message' => 'Action successfully done'), 'result' => array('data' => $result));
		}
		else{
			$this->response = array('status' => array('error_code' => 1, 'message' => 'Unable to perform request'), 'result' => array('data' => $result));
		}
		header('Content-Type: application/json');
		echo json_encode($this->response);
		exit;
	}

	/**
	 * @request data-column, lead_id, value
	 */
	public function updateLeadDetails()
	{
		$leadDetails = $this->common_model->select_row('lead_details', ['lead_id '=> $this->input->post('id')], 'lead_id');
		if(!$leadDetails){
			$this->common_model->add('lead_details', ['lead_id'=> $this->input->post('id')]);
		}
		$updateArray = array($this->input->post('column')=> $this->input->post('value'));
		if($this->common_model->update('lead_details', $updateArray, ['lead_id '=> $this->input->post('id')])){
			$this->response = array('status' => array('error_code' => 0, 'message' => 'Action successfully done'), 'result' => array('data' => $result));
		}
		else{
			$this->response = array('status' => array('error_code' => 1, 'message' => 'Unable to perform request'), 'result' => array('data' => $result));
		}
		header('Content-Type: application/json');
		echo json_encode($this->response);
		exit;
	}

	/**
	 * ---------------------- Manage leads addons ----------------------------------- *
	*/
	public function saveLeadNote()
	{
		if($this->input->post('note') && $this->input->post('lead_id')){
			$insertArray = array(
								'user_id'=> $this->admin['id'],
								'lead_id'=> $this->input->post('lead_id'),
								'note'=> $this->input->post('note'),
							);
			if(!empty($this->input->post('lead_note_id'))){
				$exe = $this->common_model->add('lead_notes', $insertArray, ['lead_note_id'=> $this->input->post('lead_note_id')]);
				$mgs = "Update note";
			}else{
				$exe = $this->common_model->update('lead_notes', $insertArray);
				$mgs = "Add note";
			}
				if($exe){
					/*--------------------*--------------------------------------------- */
					//add to activity log
					$log_array = array(
										'lead_id'=> $this->input->post('lead_id'),
										'action'=> $mgs,
										'message'=> $mgs.' for lead',
										'user_id'=> $this->admin['id'],
										'created_at'=> date('Y-m-d h:ia'),
									);
					//Add log
					$this->common_model->add('lead_logs', $log_array);
					/*--------------------*--------------------------------------------- */
					$this->response = array('status' => array('error_code' => 0, 'message' => 'Action successfully done'), 'result' => array('data' => []));
				}
			else{
				$this->response = array('status' => array('error_code' => 1, 'message' => 'Unable to perform request'), 'result' => array('data' => []));
			}
		}else{
			$this->response = array('status' => array('error_code' => 1, 'message' => 'Unable to perform request'), 'result' => array('data' => []));
		}
		header('Content-Type: application/json');
		echo json_encode($this->response);
		exit;
	}

	//Save task
	public function saveTask()
	{
		if($this->input->post('title') && $this->input->post('lead_id')){
			$insertArray = array(
								'user_id'=> $this->admin['id'],
								'lead_id'=> $this->input->post('lead_id'),
								'title'=> $this->input->post('title'),
								'description'=> $this->input->post('description'),
								'type'=> $this->input->post('type'),
								'date'=> date('Y-m-d', strtotime($this->input->post('date'))),
								'time'=> !empty($this->input->post('time'))?$this->input->post('time'):null,
								'outcome'=> $this->input->post('outcome')
							);
			if(!empty($this->input->post('lead_task_id'))){
				$exe = $this->common_model->update('lead_tasks', $insertArray, ['lead_task_id'=> $this->input->post('lead_task_id')]);
				$msg = "Task updated";
			}else{
				$exe = $this->common_model->add('lead_tasks', $insertArray);
				$msg = "Task added";
			}
			if( $exe ){
				/*--------------------*--------------------------------------------- */
				//add to activity log
				$log_array = array(
									'lead_id'=> $this->input->post('lead_id'),
									'action'=> $msg,
									'message'=> $msg.' for a lead',
									'user_id'=> $this->admin['id'],
									'created_at'=> date('Y-m-d h:ia'),
								);
				//Add log
				$this->common_model->add('lead_logs', $log_array);
				/*--------------------*--------------------------------------------- */
				$this->response = array('status' => array('error_code' => 0, 'message' => 'Action successfully done'), 'result' => array('data' => []));
			}
			else{
				//echo $this->db->last_query();
				$this->response = array('status' => array('error_code' => 1, 'message' => 'Unable to perform request'), 'result' => array('data' => []));
			}
		}else{
			$this->response = array('status' => array('error_code' => 1, 'message' => 'Unable to perform request'), 'result' => array('data' => []));
		}
		header('Content-Type: application/json');
		echo json_encode($this->response);
		exit;
	}
	//Save lead files
	public function saveFiles()
	{
		if($this->input->post('file_name') && $_FILES['file']['name']){
			$image_file = '';
			$insertArray = array(
								'user_id'=> $this->admin['id'],
								'lead_id'=> $this->input->post('lead_id'),
								'file_name'=> $this->input->post('file_name')
							);
			if($_FILES['file']['name']){
				$filename = $_FILES['file']['name'];
				$ext = pathinfo($filename, PATHINFO_EXTENSION);

				$image_file = time().'_'.strtolower(str_replace(' ', '~', $this->input->post('file_name')))."." . $ext;
				$imgPath = getcwd()."/public/lead_files/".$image_file;
				ini_set('display_errors', 1);
				if(move_uploaded_file($_FILES['file']['tmp_name'], $imgPath)){
					$insertArray['file'] = $image_file;
				}
			}
			if($this->common_model->add('lead_files', $insertArray)){
				/*--------------------*--------------------------------------------- */
				//add to activity log
				$log_array = array(
									'lead_id'=> $this->input->post('lead_id'),
									'action'=> 'Add Lead file',
									'message'=> 'Add a lead file ( '.$this->input->post('file_name').' )',
									'user_id'=> $this->admin['id'],
									'created_at'=> date('Y-m-d h:ia'),
								);
				//Add log
				$this->common_model->add('lead_logs', $log_array);
				/*--------------------*--------------------------------------------- */
				$insertArray['file'] = base_url('public/lead_files/'.$image_file);
				$this->response = array('status' => array('error_code' => 0, 'message' => 'Action successfully done'), 'result' => array('data' => (object)$insertArray));
			}
			else{
				//echo $this->db->last_query();
				$this->response = array('status' => array('error_code' => 1, 'message' => 'Unable to perform request'), 'result' => array('data' => []));
			}
		}else{
			$this->response = array('status' => array('error_code' => 1, 'message' => 'Unable to perform request'), 'result' => array('data' => []));
		}
		header('Content-Type: application/json');
		echo json_encode($this->response);
		exit;
	}

	public function sendEmail(Type $var = null)
	{
		$to = $this->input->post('to');
		$cc = $this->input->post('cc');
		$subject = $this->input->post('subject');
		$body = $this->input->post('body');
		$lead_id = $this->input->post('lead_id');
		$logo               =   base_url('public/admin/images/logo.png');
		$params['to']       =   $to; 
		$params['subject']  =   $subject;                             
		$mail_temp          =   file_get_contents('./global/mail/lead-mail.html');
		$mail_temp          =   str_replace("{web_url}", base_url(), $mail_temp);
		$mail_temp          =   str_replace("{logo}", $logo, $mail_temp);
		$mail_temp          =   str_replace("{shop_name}", 'LEAD CRM', $mail_temp);
		$mail_temp          =   str_replace("{subject}", $subject, $mail_temp);
		$mail_temp          =   str_replace("{body}", $body, $mail_temp);
		$mail_temp          =   str_replace("{current_year}", date('Y'), $mail_temp);           
		$params['message']  =   $mail_temp;
		
		$response                =   mailSend($params);
		if($response){
			//insert mail details
			/*--------------------*--------------------------------------------- */
				//add to activity log
				$log_array = array(
					'lead_id'=> $this->input->post('lead_id'),
					'action'=> 'Send mail',
					'message'=> 'Send mail to '.$to,
					'user_id'=> $this->admin['id'],
					'created_at'=> date('Y-m-d h:ia'),
				);
		//Add log
		$this->common_model->add('lead_logs', $log_array);
		/*--------------------*--------------------------------------------- */
		$this->response = array('status' => array('error_code' => 0, 'message' => 'Action successfully done'), 'result' => array('data' => []));
		}else{
		$this->response = array('status' => array('error_code' => 1, 'message' => 'Mail not send'), 'result' => array('data' => []));
		}
	}

	public function deleteSection()
	{
		$lead_id = $this->input->post('lead_id');
		$id = $this->input->post('id');
		$key = $this->input->post('key');
		$table = $this->input->post('table');
		$where = array(
			$key=> $id,
			'lead_id'=> $lead_id
		);
		$exe = $this->common_model->update($table, ['status'=> 3], $where);
		$this->response = array('status' => array('error_code' => 0, 'message' => 'Action performed successfully'), 'result' => array('data' => []));

		header('Content-Type: application/json');
		echo json_encode($this->response);
		exit;
	}
}