<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Campaign extends MY_Controller
{
    public function __construct() {
        parent::__construct();
        $this->redirect_guest();
        $this->admin = $this->session->userdata('admin');
        
        $this->load->model('common_model');
    }
    private function outputJson($response){
        header('Content-Type: application/json');
        echo json_encode($response);
        exit;
    }
    public function index()
    {
        $data['content']        = 'admin/campaign/list';
        $this->load->view('admin/layouts/index', $data);
    }
    public function save()
    {
       if($this->input->post()){
          //pr($_POST);
        
            if(empty(trim($this->input->post('campId')))){     
            
                $insertArray = [
                    "campaign_generated_no"         => $this->input->post('campaign_no'),
                    "campaign_name"                 => $this->input->post('campaign_name'),
                    "company_id"                    => $this->input->post('company_id'),
                    //"company_id"                    => '1',
                    "campaign_start_date"           => $this->input->post('campaign_start_date'),
                    "campaign_end_date"             => $this->input->post('campaign_end_date'),
                    "campaign_source_id"            => $this->input->post('source'),
                ];

                $insert_id  = $this->common_model->add('campaign_master', $insertArray);
                if($insert_id){                    
                    $this->session->set_flashdata('success_msg', 'New Campaign Successfully Added !!!');
                    //$this->session->set_flashdata('color', '#7cff9a');
                }else{
                    $this->session->set_flashdata('error_msg', 'Unable to add campaign!!');
                    //$this->session->set_flashdata('color', '#ff394c');
                }
            } else {
                //echo "hdga";exit;
                $updateArray = [
                    "campaign_generated_no"         => $this->input->post('campaign_no'),
                    "campaign_name"                 => $this->input->post('campaign_name'),                    
                    "campaign_start_date"           => $this->input->post('campaign_start_date'),
                    "campaign_end_date"             => $this->input->post('campaign_end_date'),
                    "campaign_source_id"            => $this->input->post('source'),
                    "date_of_update"                => date('Y-m-d h:i:s')
                ];
                
                if($this->common_model->update('campaign_master',$updateArray, array("campaign_id" => $this->input->post('campId')))){
                    $this->session->set_flashdata('success_msg', 'Campaign Successfully Updated !!!');
                    //$this->session->set_flashdata('color', '#7cff9a');
                }else{
                    $this->session->set_flashdata('error_msg', 'Unable to update campaign!!!');
                    //$this->session->set_flashdata('color', '#ff394c');
                }
            }
        }
        redirect('admin/campaign');
    }
    public function getCampaignList(){
        
        $where = array();
        if($this->admin['role_id'] !='2'){
            $cond['campaign_master.company_id'] =  $this->admin['company_id'];
        }
        $cond['campaign_master.status !=']  =  3; 
        $selectarr = array('campaign_master.*','company_master.name', 'campaign_source.source');
        $joinarr['company_master']     =   'campaign_master.company_id=company_master.company_id';
        
        /* Added by chayan with Isser join*/
        $joinarr['campaign_source']     =   'campaign_source.campaign_source_id=campaign_master.campaign_source_id';
        //$joinType['campaign_source']     =   'left';
        $dataObj            =  $this->common_model->get('campaign_master',$selectarr, $cond,null,null,null,null,'campaign_id','desc',$joinarr,null,'result');
        
        //echo $this->db->last_query(); die;
        $data['details']    =  $dataObj;
        $html = $this->load->view('admin/campaign/ajax_list', $data, true);
        //print $html;
        $this->response=array('status'=>array('error_code'=>0,'message'=>'Success'),'result'=>$html);
        $this->outputJson($this->response);
    }
    
    public function add($id=''){
        $menu_permission_arr                = array();    
        if ($id != '') {
            $where['campaign_id']           =   $id;
            $where['status !=']             =   3; 
            $data['campaign']               =   $this->common_model->get('campaign_master',null,$where,null,null,null,null,null,null,null,null,'row');
        }
        $cond['status']                    =  1;
        $data['company']                    =   $this->common_model->get('company_master',null, $cond,null,null,null,null,'name','asc',null,null,'result');
        $data['campaign_source']            =  $this->common_model->get('campaign_source',null, $cond,null,null,null,null,'source','asc',null,null,'result'); 
        $data['company_id']                 = $this->admin['company_id'];
        $data['content']        = 'admin/campaign/add';
        $this->load->view('admin/layouts/index', $data);
    }
    public function delete(){
        //pr($_POST);
        if($this->input->post()){
            $id = $this->input->post('id');
            $table = $this->input->post('table');

            if($this->common_model->update($table,array('status'=>'3'),array('campaign_id'=>$id))){
                $response['status'] =1;
                $response['message'] = "Deleted successfully done.";
            }else{
                $response['status'] =0;
                $response['message'] = "Unable to deleted.";
            }

            echo json_encode($response);
        }
    }
    
}