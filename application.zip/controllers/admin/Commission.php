<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Commission extends MY_Controller
{
    public function __construct() {
        parent::__construct();
        $this->redirect_guest();
        $this->admin = $this->session->userdata('admin');
        
        $this->load->model('common_model');
    }
    private function outputJson($response){
        header('Content-Type: application/json');
        echo json_encode($response);
        exit;
    }
    public function index()
    {
    	//echo "dhfdkjfk";exit;
        $data['content']        = 'admin/commission/list';
        $this->load->view('admin/layouts/index', $data);
    }    
    public function getCommissionList(){
        
      
        $where = array();         
       
    	$selectarr = array('user_commission.*','sum(commission_ratio)as total_commission_ratio','users.name');
    	$joinarr['users']     =   'users.id=user_commission.user_id';
    	$commission_data      =  $this->common_model->get('user_commission',$selectarr, $where,null,null,'user_id',null,null,null,$joinarr,null,'result');
			
        //$dataObj            =  $this->common_model->get('roles',null, $cond,null,null,null,null,'role_id','desc',null,null,'result');
        $data['details']    =  $commission_data;
        //spr($data['details']);
        $html = $this->load->view('admin/commission/ajax_list', $data, true);
        //print $html;
        $this->response=array('status'=>array('error_code'=>0,'message'=>'Success'),'result'=>$html);
        $this->outputJson($this->response);
    }
}