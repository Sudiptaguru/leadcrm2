<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Assignedproject extends MY_Controller {

	public function __construct() {
		parent::__construct();
		$this->redirect_guest();
		$this->load->model('admin/massignedproject');
	}
	public function index() { 
		$this->_load_list_view();
	}
	public function all_content_list(){

		$start_date = $_POST['start_date'];
		$end_date = $_POST['end_date'];
		$list = $this->massignedproject->get_datatables($start_date,$end_date);
        $data = array();
        $no = $_POST['start'];
		$i=1;
		//echo "<pre>";print_r($list);die(); 
        foreach ($list as $project) {
            $no++;
            $row = array();
			$row[]=$i;
            $row[] = $project->name;
            $row[] = $project->email_id;
            $row[] = $project->phone;
            $row[] = $project->company_name;
            $row[] = $project->campaign_name;
            //$row[] = date( 'd-M-Y h:ia', strtotime( $project->schedule_for_contact ) );
            $row[] = '<select class="project_status">
            			<option value="open"'.($project->status == "open" ? "selected":"").' data-project_id="'.$project->id.'">Open</option>
            			<option value="innegotiation"'.($project->status == "innegotiation" ? "selected":"").' data-project_id="'.$project->id.'">Innegotiation</option>
            			<option value="lost"'.($project->status == "lost" ? "selected":"").' data-project_id="'.$project->id.'">Lost</option>
            			<option value="awarded"'.($project->status == "awarded" ? "selected":"").' data-project_id="'.$project->id.'">Awarded</option>
					</select>';
            $row[] = $project->quotation_price;
            $row[] = $project->closing_price;
            $row[] = date( 'd-M-Y h:ia', strtotime( $project->post_date ) );
            $row[] = ($project->assign_status=="assigned"?'<span style="color:green">Assigned</span>':'<span style="color:red">Unassigned</span>');
            $row[] = '<a class="cstm_view" href="'.base_url('admin/assignedproject/edit/'.$project->id).'" title="Edit"><i class="glyphicon glyphicon-edit"></i></a><a class="cstm_view" href="'.base_url('admin/leads/message_list/'.$project->id).'" title="Messages"><i class="glyphicon glyphicon-book"></i></a>';
            $data[] = $row;
			$i++;
        }
        $output = array(
                        "draw" => $_POST['draw'],
                        "recordsTotal" => $this->massignedproject->count_all($start_date,$end_date),
                        "recordsFiltered" => $this->massignedproject->count_filtered($start_date,$end_date),
                        "data" => $data,
                );
        echo json_encode($output);
	}
	public function edit($id){
		$data['assignedproject']=$this->massignedproject->get_details($id);
		if(empty($data['assignedproject'])){
			$this->_load_list_view();
		}else{
			$this->_load_details_view($data);
		}
	}
	public function update(){
		if($this->input->post()){
			$id=$this->input->post('project_id');
			$this->form_validation->set_rules('project_description','Project Description','required');
			$this->form_validation->set_rules('quotation_price','Quotation Price','required');
			$this->form_validation->set_rules('closing_price','Closing Price','required');
			if($this->form_validation->run()==FALSE){
				$data['assignedproject']=$this->massignedproject->get_details($id);
				$this->_load_details_view($data);
			}else{
				//echo $this->input->post('status');exit;
				$user = $this->session->userdata('admin');
				$user_id = $user['id'];
				$condition=array('id'=>$id);
				$udata['project_name']=$this->input->post('project_name');
				$udata['project_description']=$this->input->post('project_description');
				$udata['quotation_price']=$this->input->post('quotation_price');
				$udata['closing_price']=$this->input->post('closing_price');
				$udata['status']=$this->input->post('status');
				$udata['currency']=$this->input->post('currency');
				$this->massignedproject->update($condition,$udata);
				if($this->massignedproject->update($condition,$udata)){
					if($udata['status'] =='close'){
						$lead_details 	= $this->common_model->getRow('new_project', array('id' => $project_id));
						$commission		= $lead_details['commission'];
						$closing_price	= $lead_details['closing_price'];
						$commission_ratio =  $this->calculate_ratio($closing_price,$commission);
						$updateArr = array(	'user_id' 	=> $user_id,
											'lead_id' 	=>$project_id,
											'commission_ratio'=>$$commission_ratio
										 );
						$this->common_model->add('user_commission',$updateArr);
					}
				}
				$this->session->set_flashdata('success_msg','Detail updated successfully');
				redirect('admin/assignedproject');
			}
		}else{
			$this->_load_list_view();
		}
	}
	public function delete_content(){
		$condition['id']=$this->input->post('id');
		$this->massignedproject->delete($condition);
		$response=array('status'=>1,'message'=>'Success');
		echo header('Content-Type: application/json');
		echo json_encode($response);
	}
	private function _load_list_view() {
		$data['content'] = 'admin/assignedproject/list';
		$this->load->view('admin/layouts/index', $data);
	}
	private function _load_details_view($parms){
		$data['assignedproject']=$parms['assignedproject'];
		$data['users'] = $this->massignedproject->get_users();
		$data['content'] = 'admin/assignedproject/detail';
		$this->load->view('admin/layouts/index', $data);
	}

	public function change_project_status()
	{
		$user = $this->session->userdata('admin');
		$user_id = $user['id'];
		$project_id = $this->input->post('project_id');
		$project_status = $this->input->post('project_status');
		//print_r($_POST);die();
		$update_data = array(
			'status' => $project_status
		);
		$this->db->where('id',$project_id);
		$this->db->update('new_project',$update_data);
		if($project_status =='close'){

			$lead_details 	= $this->common_model->getRow('new_project', array('id' => $project_id));
			$commission		= $lead_details['commission'];
			$closing_price	= $lead_details['closing_price'];
			$commission_ratio =  $this->calculate_ratio($closing_price,$commission);
			$updateArr = array(	'user_id' 	=> $user_id,
								'lead_id' 	=>$project_id,
								'commission_ratio'=>$commission_ratio
							 );
			$this->common_model->add('user_commission',$updateArr);
		}
		$response=array('status'=>1,'message'=>'Success');
		echo header('Content-Type: application/json');
		echo json_encode($response);
	}
	public function calculate_ratio($num_1, $num_2){
  
	    for($n=$num_2; $n>1; $n--) {
	        if(($num_1%$n) == 0 && ($num_2%$n) == 0) {
	            $num_1=$num_1/$n;
	            $num_2=$num_2/$n;
	        }
	    }
	    return $num_2;
	}
}