<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Contacts extends MY_Controller {
	public function __construct() {
		ini_set('display_errors', 1);
		parent::__construct();
		$this->redirect_guest();
		$this->admin = $this->session->userdata('admin');
		$this->load->model('mcommon');
	}
	public function index() { 
		
		$this->_load_list_view();
	}
	public function all_content_list(){
		//print_r($this->admin);
		if($this->admin['role_id'] != '2'){
			if($this->admin['role_id'] == '1'){
				$user_id = '';
			}
			else{
				$user_id =	$this->admin['id'];
			}
			$company_id	= $this->admin['company_id'];
		}
		else{
			$company_id	= '';
			$user_id	= '';
		}		
		$start_date = $_POST['start_date'];
		$end_date = $_POST['end_date'];
		$admin=$this->session->userdata('admin');
		//echo 'company_id'.$company_id;
		//$list = $this->mcontact->get_datatables($company_id,$start_date,$end_date,$user_id);
		$this->join[] = ['table' => 'users u', 'on' => 'u.id = c.sale_owner', 'type' => 'left'];
        $list = $this->common_model->select('contacts c', ['c.status !='=> 3], 'c.*, u.name sales_user_name, u.email', 'c.contact_id', 'DESC', $this->join);
            
		// echo $this->db->last_query();
		// print_r($list); die;
	   //$users = $this->mproject->get_users();
        $data = array();
        $no = $_POST['start'];
		$i=1;
        foreach ($list as $project) {
            $no++;
            $row = array();
			$row[]='<input type="checkbox" id="contact-'.$project->contact_id.'">';
			$row[] = '<a href="" class="company-title">'.$project->contact_name.'</span></a>';
			$row[] = $project->score;
			$row[] = $project->open_deal_amount;
			$row[] = date( 'd-M-Y h:ia', strtotime( $project->last_contact_time) );			
            $row[] = $project->sales_user_name;
            $row[] = $project->email;
            $row[] = $project->work;
            $row[] = '<div class="dropdown"><a href="" class="dropdown-toggle" type="button" data-toggle="dropdown"
						aria-haspopup="true" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
					<div class="dropdown-menu">
						<a class="dropdown-item" href="#">Add task</a>
						<a class="dropdown-item action" href="#" id="edit" title="Edit" data-id="'.$project->contact_id.'">Edit</a>
						<a class="dropdown-item action" href="#" id="clone" title="Clone" data-id="'.$project->contact_id.'">Clone</a>
						<a class="dropdown-item action" id="delete" title="Delete" data-id="'.$project->contact_id.'" href="#">Delete</a>
					</div>
				</div>';
       
			$data[] = $row;
			$i++;
        }
        $output = array(
                        "draw" => $_POST['draw'],
                        "recordsTotal" => count($list),
                        "recordsFiltered" =>count($list),
                        "data" => $data,
                );
        echo json_encode($output);
	}
	public function edit($id){
		$data['project']=$this->mproject->getDetails($id);
		$data['projectEmail'] = $this->common_model->select_row('lead_emails', ['contact_id'=> $id, 'is_default'=> 1], 'lead_emails.*');
		$data['projectDetails'] = $this->common_model->select_row('lead_details', ['contact_id '=> $id], 'lead_details.*');
 		if(empty($data['project'])){
			$this->_load_list_view();
		}else{
			$this->_load_details_view($data);
		}
	}
	
	public function message($id){
		$data['content'] = 'admin/leads/add_message';
		$data['contact_id'] = $id;
		$condition['id'] = $id;
		$row1=$this->mcommon->getRow("new_project",$condition);
		$data['project_name'] = $row1['title'].' '.$row1['name'].' '.$row1['lname'];
		$this->load->view('admin/layouts/index', $data);	
	}
	
	public function add_message(){
	/*
	$id=$this->input->post('client_id');
    $client_query = $this->db->query("SELECT * FROM new_project where id='$id'");  
    foreach ($client_query->result() as $row): 
    $phone=$phone->phone;
    endforeach;	
	*/
    $client_id=$this->input->post('client_id');
	$user_id=$this->session->userdata('admin')['id'];
	$data = array(
      'contact_id' => $this->input->post('client_id'),
      'message' => $this->input->post('msg'),
      'user_id' => $user_id,
        ); 

	if($this->db->insert('lead_message', $data)) {
		$code_id = $this->db->insert_id();
	$msg="Message Send Successfully.";   
		$this->session->set_flashdata('client_msg', $msg);
	} else {
	$msg="Error Message.";   
		$this->session->set_flashdata('client_msg', $msg);
	}   
    
     redirect('admin/leads/message_list/'.$client_id);  	
	}
	
	public function message_list($id){
		$data['content'] = 'admin/leads/message_list';
		$data['contact_id'] = $id;
	    $messageList=$this->mcommon->getMessageList($id);
	    $data['messageList']=$messageList;
	    $condition['id'] = $id;
		$row1=$this->mcommon->getRow("new_project",$condition);
		$data['project_name'] = $row1['title'].' '.$row1['name'].' '.$row1['lname'];
		$this->load->view('admin/layouts/index', $data);	
	}
	
	public function delete1(){
        //pr($_POST);
        if($this->input->post()){
            $id =$this->input->post('id');
            $table = $this->input->post('table');

            if($this->common_model->update1($table,array('id'=>$id))){
                //$response['status'] =1;
                $response['message'] = "Deleted successfully done.";
            }else{
                //$response['status'] =0;
                $response['message'] = "Unable to deleted.";
            }

            echo json_encode($response);
        }
    }
	
	public function delete_message() {
	        $quote_art_id=$this->input->get('id');
	        $m_id=$this->input->get('m_id');
	        $this->db->query("DELETE FROM lead_message WHERE `id` = '$quote_art_id'");
	        redirect(base_url('admin/leads/message_list/'.$m_id));
            }

	public function edit_message(){
	$this->load->view('admin/layouts/header');	
	$this->load->view('admin/layouts/leftsidebar');	
	$this->load->view('admin/leads/edit_message');
    $this->load->view('admin/layouts/footer');	
	}
	
	public function update_message(){
	$id=$this->input->post('message_id');	
    $client_id=$this->input->post('client_id');
	$data = array(
      'message' => $this->input->post('msg')
        ); 
    $this->db->where('id',$id);
	$this->db->update('lead_message', $data);
	$msg="Message Send Successfully.";   
	$this->session->set_flashdata('client_msg', $msg);
    redirect('admin/leads/message_list/'.$client_id);  	
	}
	
	public function update(){
		if($this->input->post()){
			$id=$this->input->post('project_id');
			//$this->form_validation->set_rules('project_description','Project Description');
			//$this->form_validation->set_rules('quotation_price','Quotation Price');
			//$this->form_validation->set_rules('closing_price','Closing Price');
// 			if($this->form_validation->run()==FALSE){
// 			    echo 1;die;
// 				$data['project']=$this->mproject->get_details($id);
// 				$this->_load_details_view($data);
// 			}else{
				$condition=array('id'=>$id);
				$udata['project_name']=$this->input->post('project_name');
				$udata['project_description']=$this->input->post('project_description');
				$udata['quotation_price']=$this->input->post('quotation_price');
				$udata['closing_price']=$this->input->post('closing_price');
				$udata['commission']=$this->input->post('commission_price');
				$udata['currency']=$this->input->post('currency');
				$udata['status']=$this->input->post('status');
				$udata['assign_status'] = 'assigned';
				$this->mproject->update($condition,$udata);
                //echo 2;
				$project = $this->mproject->get_assign_details($id);
				if($this->input->post('user')>0){
    				if (empty($project)) {
    					$insert_data = array(
    						'project_id' => $id,
    						'user_id'	=> $this->input->post('user'),
    						'assign_date' => date('Y-m-d')
    					);
    					$this->db->insert('assign_project',$insert_data);
    				} else {
    					$update_data = array(
    						'project_id' => $id,
    						'user_id'	=> $this->input->post('user')
    					);
    					$this->db->where('id',$project['id']);
    					$this->db->update('assign_project',$update_data);
    				}
				}
				//echo 3;
				$this->session->set_flashdata('success_msg','Detail updated successfully');
				redirect('admin/leads');
		//	}
		}else{
			$this->_load_list_view();
		}
	}
	public function delete_content(){
		$condition['id']=$this->input->post('id');
		$this->mproject->delete($condition);
		$response=array('status'=>1,'message'=>'Success');
		echo header('Content-Type: application/json');
		echo json_encode($response);
	}
	private function _load_list_view() {
		$data['content'] = 'admin/contacts/index';
		$this->load->view('admin/layouts2/index', $data);
	}
	private function _load_details_view($parms){
		$data['project']=$parms['project'];
		$data['projectEmail']=$parms['projectEmail'];
		$data['projectDetails']=$parms['projectDetails'];
		//print_r($data['project']);die;
		$company_id=$data['project']['company_id'];
        $users = $this->mproject->get_users($company_id);
        
        //$assigned_data = $this->mproject->get_assign_details($data['project']['id']);
        
        // $data['assigned_data'] = $assigned_data;
		// $data['users'] = $users;
		$data['content'] = 'admin/leads/leads-details';
		$this->load->view('admin/layouts2/index', $data);
	}
	private function _load_add_view(){
		$data['roles'] = $this->mproject->get_roles();
		$data['content']='admin/leads/add';
		$this->load->view('admin/layouts/index',$data);
	}

	public function assign_project()
	{
		$project_id = $this->input->post('project_id');
		$project = $this->mproject->get_assign_details($project_id);
		if (empty($project)) {
			$insert_data = array(
				'project_id' => $project_id,
				'user_id'	=> $this->input->post('user_id'),
				'assign_date' => date('Y-m-d')
			);
			$this->db->insert('assign_project',$insert_data);
		} else {
			$update_data = array(
				'project_id' => $project_id,
				'user_id'	=> $this->input->post('user_id')
			);
			$this->db->where('id',$project['id']);
			$this->db->update('assign_project',$update_data);
		}
		$update_data = array(
			'assign_status' => 'assigned'
		);
		$this->db->where('id',$project_id);
		$this->db->update('new_project',$update_data);
		$response=array('status'=>1,'message'=>'Success');
		echo header('Content-Type: application/json');
		echo json_encode($response);
	}
	
	public function delete(){
        if($this->input->post()){
            $id = $this->input->post('id');
            $table = $this->input->post('table');

            if($this->common_model->update($table,array('status'=>'3'),array('company_id'=>$id))){
                $response['status'] =1;
                $response['message'] = "Deleted successfully done.";
            }else{
                $response['status'] =0;
                $response['message'] = "Unable to deleted.";
            }

            echo json_encode($response);
        }
	}
	
	/**
	 * Add lead by chayan
	 */
	public function addStore(){
		//print_r($this->input->post());
		if($this->session->userdata('admin')){
			if($postArray = $this->input->post()){
				//print_r($postArray);
				//check request is for save or update
				$leadArray = array(
					'contact_name'			=> $postArray['full_name'],
					'score'			=> $postArray['score'],
					'open_deal_amount'	=> $postArray['deal_amount'],
					'email'	=> $postArray['email'],
					'last_contact_time'		=> date('Y-m-d H:i'),
					'work'			=> $postArray['work'],
					'sale_owner'	=> $postArray['sales_owner'],
				);
				//print_r($leadArray);
				//echo $postArray['contact_id']; die;
				if(isset($postArray['contact_id']) && !empty($postArray['contact_id'])){
					$contact_id = $postArray['contact_id'];
					if($this->common_model->update('contacts', $leadArray, ['contact_id'=> $contact_id])){
						//echo $this->db->last_query();
						$this->response = array('status' => array('error_code' => 0, 'message' => 'Contact updated successfully'), 'result' => array('data' => $this->obj));
					}else{
						$this->response = array('status' => array('error_code' => 1, 'message' => 'Unknown error, Unable to update Conatct'), 'result' => array('data' => $this->obj));
					}
				}else{
					$contact_id = $this->common_model->add('contacts', $leadArray);
					//echo $this->db->last_query();
					if($contact_id){
						$this->response = array('status' => array('error_code' => 0, 'message' => 'Contact added successfully'), 'result' => array('data' => $this->obj));
					}else{
						$this->response = array('status' => array('error_code' => 1, 'message' => 'Unknown error, Unable to add Contact'), 'result' => array('data' => $this->obj));
					}
				}
			}else{
				//empty request
				$this->response = array('status' => array('error_code' => 1, 'message' => 'Unable to parse request'), 'result' => array('data' => $this->obj));
			}
		}
		header('Content-Type: application/json');
		echo json_encode($this->response);
		exit;
	}

	/*
		* @request id
		* response lead info
		* By chayan
	*/
	public function get()
	{
		$this->db->where(['contact_id'=> $this->input->get('id'), 'status'=> 1]);
		$result['data'] = $this->db->get('contacts')->result_array();
		//$result['q'] = $this->db->last_query();
		if($result){
			$this->response = array('status' => array('error_code' => 0, 'message' => 'success'), 'result' => array('data' => $result));
		}else{
			$this->response = array('status' => array('error_code' => 1, 'message' => 'Unable to get result'), 'result' => array('data' => $this->obj));
		}
		header('Content-Type: application/json');
		echo json_encode($this->response);
		exit;
	}

	public function updateStatus()
	{
		$updateArray = array($this->input->post('column')=> $this->input->post('status'));
		if($this->input->post('column') == 'stage'){
			$updateArray['updated_at'] = date('Y-m-d H:i:s a');
		}
		if($this->common_model->update('contacts', $updateArray, ['contact_id '=> $this->input->post('id')])){
			//echo $this->db->last_query();
			$this->response = array('status' => array('error_code' => 0, 'message' => 'Action successfully done'), 'result' => array('data' => $result));
		}
		else{
			$this->response = array('status' => array('error_code' => 1, 'message' => 'Unable to perform request'), 'result' => array('data' => $result));
		}
		header('Content-Type: application/json');
		echo json_encode($this->response);
		exit;
	}

	/**
	 * @request data-column, contact_id, value
	 */
	public function updateLeadDetails()
	{
		$leadDetails = $this->common_model->select_row('lead_details', ['contact_id '=> $this->input->post('id')], 'contact_id');
		if(!$leadDetails){
			$this->common_model->add('lead_details', ['contact_id'=> $this->input->post('id')]);
		}
		$updateArray = array($this->input->post('column')=> $this->input->post('value'));
		if($this->common_model->update('lead_details', $updateArray, ['contact_id '=> $this->input->post('id')])){
			$this->response = array('status' => array('error_code' => 0, 'message' => 'Action successfully done'), 'result' => array('data' => $result));
		}
		else{
			$this->response = array('status' => array('error_code' => 1, 'message' => 'Unable to perform request'), 'result' => array('data' => $result));
		}
		header('Content-Type: application/json');
		echo json_encode($this->response);
		exit;
	}
}