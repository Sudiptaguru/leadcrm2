<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Deals extends MY_Controller {

	public function __construct() {
		parent::__construct();
		$this->redirect_guest();
		$this->admin = $this->session->userdata('admin');
		
		$this->load->model('admin/mproject');
		$this->load->model('mcommon');
		$this->load->model('admin/mdeals');
	}
	public function index() {
		$this->_load_list_view();
	}
	public function edit($id){
		$data['project']=$this->mproject->getDetails($id);
		$data['projectEmail'] = $this->common_model->select_row('lead_emails', ['lead_id'=> $id, 'is_default'=> 1], 'lead_emails.*');
		$data['projectDetails'] = $this->common_model->select_row('lead_details', ['lead_id '=> $id], 'lead_details.*');
 		if(empty($data['project'])){
			$this->_load_list_view();
		}else{
			$this->_load_details_view($data);
		}
	}
	
	
	public function update(){
		if($this->input->post()){
			$id=$this->input->post('project_id');
			//$this->form_validation->set_rules('project_description','Project Description');
			//$this->form_validation->set_rules('quotation_price','Quotation Price');
			//$this->form_validation->set_rules('closing_price','Closing Price');
		// 			if($this->form_validation->run()==FALSE){
		// 			    echo 1;die;
		// 				$data['project']=$this->mproject->get_details($id);
		// 				$this->_load_details_view($data);
		// 			}else{
				$condition=array('id'=>$id);
				$udata['project_name']=$this->input->post('project_name');
				$udata['project_description']=$this->input->post('project_description');
				$udata['quotation_price']=$this->input->post('quotation_price');
				$udata['closing_price']=$this->input->post('closing_price');
				$udata['commission']=$this->input->post('commission_price');
				$udata['currency']=$this->input->post('currency');
				$udata['status']=$this->input->post('status');
				$udata['assign_status'] = 'assigned';
				$this->mproject->update($condition,$udata);
                //echo 2;
				$project = $this->mproject->get_assign_details($id);
				if($this->input->post('user')>0){
    				if (empty($project)) {
    					$insert_data = array(
    						'project_id' => $id,
    						'user_id'	=> $this->input->post('user'),
    						'assign_date' => date('Y-m-d')
    					);
    					$this->db->insert('assign_project',$insert_data);
    				} else {
    					$update_data = array(
    						'project_id' => $id,
    						'user_id'	=> $this->input->post('user')
    					);
    					$this->db->where('id',$project['id']);
    					$this->db->update('assign_project',$update_data);
    				}
				}
				//echo 3;
				$this->session->set_flashdata('success_msg','Detail updated successfully');
				redirect('admin/leads');
		//	}
		}else{
			$this->_load_list_view();
		}
	}
	public function delete_content(){
		$condition['id']=$this->input->post('id');
		$this->mproject->delete($condition);
		$response=array('status'=>1,'message'=>'Success');
		echo header('Content-Type: application/json');
		echo json_encode($response);
	}
	private function _load_list_view() {
		$data['admin'] = $this->admin;
		$this->db->where('user_id', $this->admin['id']);
		$deal_stage = $this->db->get('deals_company_pipelines')->result();
		$lead_array = array();
		if($deal_stage){
			foreach ($deal_stage as $key => $stage) {
				$this->db->where(['user_id'=> $this->admin['id'], 'pipeline_stage'=> $stage->pipeline_stage]);
				$stage->deals = $this->db->get('lead_deals')->result();
				$lead_array[] = $stage;
			}
		}
		$data['details']= $lead_array;
		$data['content'] = 'admin/deals/index';
		//print_r($data); die;
		$this->load->view('admin/layouts2/index', $data);
	}
	private function _load_details_view($parms){
		$data['admin'] = $this->admin;
		$data['project']=$parms['project'];
		$data['projectEmail']=$parms['projectEmail'];
		$data['projectDetails']=$parms['projectDetails'];
		//print_r($data['project']);die;
		$company_id=$data['project']['company_id'];
        $users = $this->mproject->get_users($company_id);
        
        //$assigned_data = $this->mproject->get_assign_details($data['project']['id']);
        
        // $data['assigned_data'] = $assigned_data;
		// $data['users'] = $users;
		$data['content'] = 'admin/leads/leads-details';
		$this->load->view('admin/layouts2/index', $data);
	}
	private function _load_add_view(){
		$data['roles'] = $this->mproject->get_roles();
		$data['content']='admin/leads/add';
		$this->load->view('admin/layouts/index',$data);
	}
	
	/**
	 * Add lead by chayan
	 */
	public function addDeal(){
		if($this->session->userdata('admin')){
			if($postArray = $this->input->post()){
				//check request is for save or update
				$dealArray = array(
					'lead_id'			=> $postArray['lead_id'],
					'user_id'			=>  $this->admin['id'],
				);
				//precess for unrequired fields
				if(isset($postArray['full_name'])){
					$dealArray['name'] = $postArray['full_name'];
				}
				if(isset($postArray['deal_value'])){
					$dealArray['deal_value'] = $postArray['deal_value'];
				}
				if(isset($postArray['account_name'])){
					$dealArray['account'] = $postArray['account_name'];
				}
				if(isset($postArray['deal_pipeline'])){
					$dealArray['pipeline'] = $postArray['deal_pipeline'];
				}
				if(isset($postArray['deal_stage'])){
					$dealArray['pipeline_stage'] = $postArray['deal_stage'];
				}
				if(isset($postArray['closed_date'])){
					$dealArray['closed_date'] = date('Y-m-d', strtotime($postArray['closed_date']));
				}
				if(isset($postArray['sales_owner'])){
					$dealArray['sales_owner'] = $postArray['sales_owner'];
				}

				//echo $leadArray; die;
				if(isset($postArray['lead_deal_id']) && !empty($postArray['lead_deal_id'])){
					if($this->common_model->update('lead_deals', $dealArray, ['lead_deal_id'=> $postArray['lead_deal_id']])){
						//echo $this->db->last_query(); die;
						
						/*--------------------*--------------------------------------------- */
						//add to activity log
						$log_array = array(
							'lead_id'=> $postArray['lead_id'],
							'action'=> 'Update Deal',
							'message'=> 'Update deal information',
							'user_id'=> $this->admin['id'],
							'created_at'=> date('Y-m-d h:ia'),
						);
						//Add log
						$this->common_model->add('lead_logs', $log_array);
						/*--------------------*--------------------------------------------- */
						$this->response = array('status' => array('error_code' => 0, 'message' => 'Deal updated successfully'), 'result' => array('data' => $this->obj));
					}else{
						$this->response = array('status' => array('error_code' => 1, 'message' => 'Unknown error, Unable to update lead'), 'result' => array('data' => $this->obj));
					}
				}else{
					//
					if($this->common_model->add('lead_deals', $dealArray)){
						//echo $this->db->last_query();
						/*--------------------*--------------------------------------------- */
						//add to activity log
						$log_array = array(
							'lead_id'=> $postArray['lead_id'],
							'action'=> 'Add new deal',
							'message'=> 'Add a new deal ',
							'user_id'=> $this->admin['id'],
							'created_at'=> date('Y-m-d h:ia'),
						);
						//Add log
						$this->common_model->add('lead_logs', $log_array);
						/*--------------------*--------------------------------------------- */
						$this->response = array('status' => array('error_code' => 0, 'message' => 'Deal added successfully'), 'result' => array('data' => $this->obj));

					}else{
						$this->response = array('status' => array('error_code' => 1, 'message' => 'Unknown error, Unable to add lead'), 'result' => array('data' => $this->obj));
					}
				}
			}else{
				//empty request
				$this->response = array('status' => array('error_code' => 1, 'message' => 'Unable to parse request'), 'result' => array('data' => $this->obj));

			}
		}
		header('Content-Type: application/json');
		echo json_encode($this->response);
		exit;
	}

	/*
		* @request id
		* response lead info
		* By chayan
	*/
	public function getDeal()
	{
		$result['data'] = $this->mdeals->getDetails($this->input->get('id'));
		$this->db->where(['deal_id'=> $this->input->get('id'), 'status'=> 1]);
		//$result['q'] = $this->db->last_query();
		if($result){
			$this->response = array('status' => array('error_code' => 0, 'message' => 'success'), 'result' => array('data' => $result));
		}else{
			$this->response = array('status' => array('error_code' => 1, 'message' => 'Unable to get result'), 'result' => array('data' => $this->obj));
		}
		header('Content-Type: application/json');
		echo json_encode($this->response);
		exit;
	}
	public function getLead()
	{
		$result['data'] = $this->mproject->getDetails($this->input->get('id'));
		$this->db->where(['lead_id'=> $this->input->get('id'), 'status'=> 1]);
		$result['email'] = $this->db->get('lead_emails')->result();
		//$result['q'] = $this->db->last_query();
		if($result){
			$this->response = array('status' => array('error_code' => 0, 'message' => 'success'), 'result' => array('data' => $result));
		}else{
			$this->response = array('status' => array('error_code' => 1, 'message' => 'Unable to get result'), 'result' => array('data' => $this->obj));
		}
		header('Content-Type: application/json');
		echo json_encode($this->response);
		exit;
	}

	public function updateStatus()
	{
		$updateArray = array($this->input->post('column')=> $this->input->post('status'));
		if($this->input->post('column') == 'stage'){
			$updateArray['updated_at'] = date('Y-m-d H:i:s a');
		}
		if($this->common_model->update('leads', $updateArray, ['lead_id '=> $this->input->post('id')])){
			//echo $this->db->last_query();
			$this->response = array('status' => array('error_code' => 0, 'message' => 'Action successfully done'), 'result' => array('data' => $result));
		}
		else{
			$this->response = array('status' => array('error_code' => 1, 'message' => 'Unable to perform request'), 'result' => array('data' => $result));
		}
		header('Content-Type: application/json');
		echo json_encode($this->response);
		exit;
	}

	/**
	 * @request data-column, lead_id, value
	 */
	public function updateLeadDetails()
	{
		$leadDetails = $this->common_model->select_row('lead_details', ['lead_id '=> $this->input->post('id')], 'lead_id');
		if(!$leadDetails){
			$this->common_model->add('lead_details', ['lead_id'=> $this->input->post('id')]);
		}
		$updateArray = array($this->input->post('column')=> $this->input->post('value'));
		if($this->common_model->update('lead_details', $updateArray, ['lead_id '=> $this->input->post('id')])){
			$this->response = array('status' => array('error_code' => 0, 'message' => 'Action successfully done'), 'result' => array('data' => $result));
		}
		else{
			$this->response = array('status' => array('error_code' => 1, 'message' => 'Unable to perform request'), 'result' => array('data' => $result));
		}
		header('Content-Type: application/json');
		echo json_encode($this->response);
		exit;
	}

	/**
	 * ---------------------- Manage leads addons ----------------------------------- *
	*/
	public function saveLeadNote()
	{
		if($this->input->post('note') && $this->input->post('lead_id')){
			$insertArray = array(
								'user_id'=> $this->admin['id'],
								'lead_id'=> $this->input->post('lead_id'),
								'note'=> $this->input->post('note'),
							);
			if(!empty($this->input->post('lead_note_id'))){
				$exe = $this->common_model->add('lead_notes', $insertArray, ['lead_note_id'=> $this->input->post('lead_note_id')]);
				$mgs = "Update note";
			}else{
				$exe = $this->common_model->update('lead_notes', $insertArray);
				$mgs = "Add note";
			}
				if($exe){
					/*--------------------*--------------------------------------------- */
					//add to activity log
					$log_array = array(
										'lead_id'=> $this->input->post('lead_id'),
										'action'=> $mgs,
										'message'=> $mgs.' for lead',
										'user_id'=> $this->admin['id'],
										'created_at'=> date('Y-m-d h:ia'),
									);
					//Add log
					$this->common_model->add('lead_logs', $log_array);
					/*--------------------*--------------------------------------------- */
					$this->response = array('status' => array('error_code' => 0, 'message' => 'Action successfully done'), 'result' => array('data' => []));
				}
			else{
				$this->response = array('status' => array('error_code' => 1, 'message' => 'Unable to perform request'), 'result' => array('data' => []));
			}
		}else{
			$this->response = array('status' => array('error_code' => 1, 'message' => 'Unable to perform request'), 'result' => array('data' => []));
		}
		header('Content-Type: application/json');
		echo json_encode($this->response);
		exit;
	}

	//Save task
	public function saveTask()
	{
		if($this->input->post('title') && $this->input->post('deal_id')){
			$insertArray = array(
								'user_id'=> $this->admin['id'],
								'deal_id'=> $this->input->post('deal_id'),
								'title'=> $this->input->post('title'),
								'description'=> $this->input->post('description'),
								'type'=> $this->input->post('type'),
								'date'=> date('Y-m-d', strtotime($this->input->post('date'))),
								'time'=> !empty($this->input->post('time'))?$this->input->post('time'):null,
								'outcome'=> $this->input->post('outcome')
							);
			if(!empty($this->input->post('deal_task_id'))){
				$exe = $this->common_model->update('lead_tasks', $insertArray, ['lead_task_id'=> $this->input->post('lead_task_id')]);
				$msg = "Task updated";
			}else{
				$exe = $this->common_model->add('deal_tasks', $insertArray);
				$msg = "Task added";
			}
			if( $exe ){
				/*--------------------*--------------------------------------------- */
				//add to activity log
				// $log_array = array(
				// 					'deal_id'=> $this->input->post('deal_id'),
				// 					'action'=> $msg,
				// 					'message'=> $msg.' for a lead',
				// 					'user_id'=> $this->admin['id'],
				// 					'created_at'=> date('Y-m-d h:ia'),
				// 				);
				// //Add log
				// $this->common_model->add('lead_logs', $log_array);
				/*--------------------*--------------------------------------------- */
				$this->response = array('status' => array('error_code' => 0, 'message' => 'Action successfully done'), 'result' => array('data' => []));
			}
			else{
				//echo $this->db->last_query();
				$this->response = array('status' => array('error_code' => 1, 'message' => 'Unable to perform request'), 'result' => array('data' => []));
			}
		}else{
			$this->response = array('status' => array('error_code' => 1, 'message' => 'Unable to perform request'), 'result' => array('data' => []));
		}
		header('Content-Type: application/json');
		echo json_encode($this->response);
		exit;
	}
	//Save lead files
	public function saveFiles()
	{
		if($this->input->post('file_name') && $_FILES['file']['name']){
			$image_file = '';
			$insertArray = array(
								'user_id'=> $this->admin['id'],
								'lead_id'=> $this->input->post('lead_id'),
								'file_name'=> $this->input->post('file_name')
							);
			if($_FILES['file']['name']){
				$filename = $_FILES['file']['name'];
				$ext = pathinfo($filename, PATHINFO_EXTENSION);

				$image_file = time().'_'.strtolower(str_replace(' ', '~', $this->input->post('file_name')))."." . $ext;
				$imgPath = getcwd()."/public/lead_files/".$image_file;
				ini_set('display_errors', 1);
				if(move_uploaded_file($_FILES['file']['tmp_name'], $imgPath)){
					$insertArray['file'] = $image_file;
				}
			}
			if($this->common_model->add('lead_files', $insertArray)){
				/*--------------------*--------------------------------------------- */
				//add to activity log
				$log_array = array(
									'lead_id'=> $this->input->post('lead_id'),
									'action'=> 'Add Lead file',
									'message'=> 'Add a lead file ( '.$this->input->post('file_name').' )',
									'user_id'=> $this->admin['id'],
									'created_at'=> date('Y-m-d h:ia'),
								);
				//Add log
				$this->common_model->add('lead_logs', $log_array);
				/*--------------------*--------------------------------------------- */
				$insertArray['file'] = base_url('public/lead_files/'.$image_file);
				$this->response = array('status' => array('error_code' => 0, 'message' => 'Action successfully done'), 'result' => array('data' => (object)$insertArray));
			}
			else{
				//echo $this->db->last_query();
				$this->response = array('status' => array('error_code' => 1, 'message' => 'Unable to perform request'), 'result' => array('data' => []));
			}
		}else{
			$this->response = array('status' => array('error_code' => 1, 'message' => 'Unable to perform request'), 'result' => array('data' => []));
		}
		header('Content-Type: application/json');
		echo json_encode($this->response);
		exit;
	}

	public function sendEmail(Type $var = null)
	{
		$to = $this->input->post('to');
		$cc = $this->input->post('cc');
		$subject = $this->input->post('subject');
		$body = $this->input->post('body');
		$lead_id = $this->input->post('lead_id');
		$logo               =   base_url('public/admin/images/logo.png');
		$params['to']       =   $to; 
		$params['subject']  =   $subject;                             
		$mail_temp          =   file_get_contents('./global/mail/lead-mail.html');
		$mail_temp          =   str_replace("{web_url}", base_url(), $mail_temp);
		$mail_temp          =   str_replace("{logo}", $logo, $mail_temp);
		$mail_temp          =   str_replace("{shop_name}", 'LEAD CRM', $mail_temp);
		$mail_temp          =   str_replace("{subject}", $subject, $mail_temp);
		$mail_temp          =   str_replace("{body}", $body, $mail_temp);
		$mail_temp          =   str_replace("{current_year}", date('Y'), $mail_temp);           
		$params['message']  =   $mail_temp;
		
		$response                =   mailSend($params);
		if($response){
			//insert mail details
			/*--------------------*--------------------------------------------- */
				//add to activity log
				$log_array = array(
					'deal_id'=> $this->input->post('deal_id'),
					'action'=> 'Send mail',
					'message'=> 'Send mail to '.$to,
					'user_id'=> $this->admin['id'],
					'created_at'=> date('Y-m-d h:ia'),
				);
		//Add log
		$this->common_model->add('lead_logs', $log_array);
		/*--------------------*--------------------------------------------- */
		$this->response = array('status' => array('error_code' => 0, 'message' => 'Action successfully done'), 'result' => array('data' => []));
		}else{
		$this->response = array('status' => array('error_code' => 1, 'message' => 'Mail not send'), 'result' => array('data' => []));
		}
	}

	public function deleteSection()
	{
		$lead_id = $this->input->post('lead_id');
		$id = $this->input->post('id');
		$key = $this->input->post('key');
		$table = $this->input->post('table');
		$where = array(
			$key=> $id,
			'lead_id'=> $lead_id
		);
		$exe = $this->common_model->update($table, ['status'=> 3], $where);
		$this->response = array('status' => array('error_code' => 0, 'message' => 'Action performed successfully'), 'result' => array('data' => []));

		header('Content-Type: application/json');
		echo json_encode($this->response);
		exit;
	}

	/**
	 * Get list list
	*/
	public function getDealList(){
		//print_r($this->admin);
		if($this->admin['role_id'] != '2'){
			if($this->admin['role_id'] == '1'){
				$user_id = '';
			}
			else{
				$user_id =	$this->admin['id'];
			}
			$company_id	= $this->admin['company_id'];
		}
		else{
			$company_id	= '';
			$user_id	= '';
		}
		$admin=$this->session->userdata('admin');
		//echo 'company_id'.$company_id;
		//$list = $this->mproject->get_datatables($company_id,$start_date,$end_date,$user_id);
		$where = array('lead_deals.company_id'=> $company_id);
		$join[] = ['table' => 'users', 'on' => 'users.id = lead_deals.sales_owner', 'type' => 'left'];
		$join[] = ['table' => 'company_master', 'on' => 'company_master.company_id = users.company_id', 'type' => 'left'];
		$list = $this->common_model->select('lead_deals', $where, 'lead_deals.*, users.name sales_user, company_master.name company_name', 'lead_deal_id', 'DESC', $join);
		
		// echo $this->db->last_query();
		// print_r($list); die;
       //$users = $this->mproject->get_users();
        $data = array();
		$i=1;
        foreach ($list as $project) {
            $row = array();
			$row[]='<input type="checkbox" id="deal-'.$project->lead_deal_id.'">';
			$row[] = '<a href="'.base_url('admin/leads/edit/'.$project->lead_deal_id).'" class="company-title">'.$project->name.'<br><span>'.$project->company_name.'</span></a>';
			$row[] = $project->deal_value;
			$row[] = '<span>Default Pipeline<p style="color:#3c8dbc">'.$project->pipeline_stage.'</p></span>';	//status/stage
			$row[] = date('d-M-Y h:ia', strtotime( $project->closed_date));			
            $row[] = $project->sales_user;
            $row[] = $project->account;
       
			$data[] = $row;
			$i++;
        }
        $output = array(
                        "draw" => $_POST['draw'],
                        "recordsTotal" => count($list),
                        "recordsFiltered" => count($list),
                        "data" => $data,
                );
        echo json_encode($output);
	}
}