<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Settings extends MY_Controller {
	public function __construct() {
		ini_set('display_errors', 1);
		parent::__construct();
		$this->redirect_guest();
		$this->admin = $this->session->userdata('admin');
		$this->load->model('mcommon');
	}
	public function index() {	
		$data['content']='admin/settings/index';
		$this->_load_view($data);
	}
	private function _load_view($data){
		$this->load->view('admin/layouts2/index', $data);
    }
    
    /*------------------Contact form settings-----------------------------*/
    public function contacts_form()
    {
        $data['element_list'] = $this->common_model->select('contact_form_elements', ['status'=> 1], '*', 'contact_form_element_id', 'ASC');
        $data['admin'] = $this->admin;
        $data['content']='admin/settings/contacts-form';
		$this->_load_view($data);
    }
    
    public function saveContactForm()
    {
        //print_r($this->input->post('form_element')); die;
        // //removed old settings if have
        $this->db->where('user_id', $this->admin['id']);
        $this->db->delete('company_contact_form_elements');

        $required_array = !empty($this->input->post('is_required'))?$this->input->post('is_required'): [];
        $add_array = !empty($this->input->post('quick_add'))?$this->input->post('quick_add'): [];

        $element_array = [];
        if(!empty($this->input->post('form_element'))){
            foreach ($this->input->post('form_element') as $key => $element_id) {
                $required_array = [1, 2, 4, 5, 8, 11];
                if(in_array($element_id, $required_array)){
                    $is_required = 1;
                    $quick_add = 1;
                }else{
                    $is_required = in_array($element_id, $required_array)?1:0;
                    $quick_add = in_array($element_id, $add_array)?1:0;
                }
                $element_array[] = array(
                                    'user_id'=> $this->admin['id'],
                                    'contact_form_element_id'=> $element_id,
                                    'is_required'=> $is_required,
                                    'quick_add'=> $quick_add
                                    );
            }
        }
        if(!empty($element_array)){
            // echo '<pre>';
            // print_r($element_array);
            $this->common_model->batch_insert('company_contact_form_elements', $element_array);
            //echo $this->db->last_query();
            echo 'Success';
        }else{
            echo 'Error';
        }
    }
    /*------------------Deals form settings-----------------------------*/
    public function deals_form()
    {
        $data['element_list'] = $this->common_model->select('deal_form_elements', ['status'=> 1], '*', 'rank', 'ASC');
        $data['admin'] = $this->admin;
        $data['content']='admin/settings/deals-form';
		$this->_load_view($data);
    }
    public function deals_pipeline()
    {
        $data['element_list'] = $this->common_model->select('deal_form_elements', ['status'=> 1], '*', 'deal_form_element_id', 'ASC');
        $data['admin'] = $this->admin;
        $data['content']='admin/settings/deal-pipeline';
		$this->_load_view($data);
    }
    
    public function saveDealForm()
    {
        // //removed old settings if have
        $this->db->where('user_id', $this->admin['id']);
        $this->db->delete('company_deal_form_elements');

        $required_array = !empty($this->input->post('is_required'))?$this->input->post('is_required'): [];
        $add_array = !empty($this->input->post('quick_add'))?$this->input->post('quick_add'): [];

        $element_array = [];
        if(!empty($this->input->post('form_element'))){
            foreach ($this->input->post('form_element') as $key => $element_id) {
                $required_array = [1, 2, 4, 5, 8, 15];
                if(in_array($element_id, $required_array)){
                    $is_required = 1;
                    $quick_add = 1;
                }else{
                    $is_required = in_array($element_id, $required_array)?1:0;
                    $quick_add = in_array($element_id, $add_array)?1:0;
                }
                $element_array[] = array(
                                    'user_id'=> $this->admin['id'],
                                    'deal_form_element_id'=> $element_id,
                                    'is_required'=> $is_required,
                                    'quick_add'=> $quick_add
                                    );
            }
        }
        if(!empty($element_array)){
            $this->common_model->batch_insert('company_deal_form_elements', $element_array);
            //echo $this->db->last_query();
            echo 'Success';
        }else{
            echo 'Error';
        }
    }

    public function saveDealPipelineStage()
    {
        if($this->input->post('stage') && $this->input->post('lead_deal_pipeline_id')){
            $this->db->where('user_id', $this->admin['id']);
            $this->db->delete('deals_company_pipelines');

            $stage_array = [];
            foreach ($this->input->post('stage') as $key => $stage) {
               $stage_array[] = array(
                                    'user_id'=> $this->admin['id'],
                                    'deals_pipeline_id'=> $this->input->post('lead_deal_pipeline_id'),
                                    'pipeline_stage'=> $stage,
                                    'probability'=> $this->input->post('probability')[$key],
                                    'rank'=> $key+1,
                                    'is_default'=>$this->input->post('is_default')[$key],
                                    );
            }
            if(!empty($stage_array)){
                $this->common_model->batch_insert('deals_company_pipelines', $stage_array);
                echo 'Success';
            }
        }else{
            echo 'Error';
        }
    }
    public function getPipelineStage()
    {
        $deals_pipeline_id = $this->input->post('deals_pipeline_id');
        $pipeline = $this->common_model->select('deals_company_pipelines', ['user_id'=> $this->admin['id']], '*', 'rank', 'ASC');
        if(empty($pipeline)){
            $pipeline = $this->common_model->select('deals_pipelines', ['status'=>1], '*', 'rank', 'ASC');
        }
        $html = '<option value=""> --Deal Stage-- </option>';
        if(!empty($pipeline )){
            foreach ($pipeline  as $key => $stage) {
                $html .= '<option value="'.$stage->pipeline_stage.'">'.$stage->pipeline_stage.'</option>';
            }
        }
        echo $html;
    }

    /**--------------------------------------Life cycle stage---------------------------------- */
    public function lifecycle()
    {
       $data['admin'] = $this->admin;
        $data['content']='admin/settings/lifecycle-stage';
		$this->_load_view($data);
    }

    public function getLifecycle()
    {
        $lifecycle = $this->common_model->select('lead_lifecycle', ['status'=> 1], '*', 'rank', 'ASC');
        $html = '';
        if(!empty($lifecycle )){
            foreach ($lifecycle  as $key => $value) {
                $html .= '<option value="'.$value->lead_lifecycle_id.'">'.$value->lifecycle.'</option>';
            }
        }

        echo $html;
    }
    public function getLifecycleStage()
    {
        $lead_lifecycle_id = $this->input->post('lead_lifecycle_id');
        $select = $this->input->post('select');
        $lifecycleStage = $this->common_model->select('`lead_company_lifecycle_stages', ['user_id'=> $this->admin['id'], 'lead_lifecycle_id'=> $lead_lifecycle_id], '*', 'rank', 'ASC');
        if(empty($lifecycleStage)){
            $lifecycleStage = $this->common_model->select('lead_lifecycle_stages', ['lead_lifecycle_id'=> $lead_lifecycle_id], '*', 'rank', 'ASC');
        }
        $html = '';
        $html .= '<div class="col-md-12 new-lifecycle-stage">
                    <div class="form-group">
                    <label>Status</label>
                        <select name="stage" class="js-states form-control">';
        if(!empty($lifecycleStage )){
            foreach ($lifecycleStage  as $key => $stage) {
                $selected = '';
                if($select == $stage->stage){
                    $selected = 'selected';
                }
                $html .= '<option value="'.$stage->stage.'" '.$selected.'>'.$stage->stage.'</option>';
            }
        }
        $html .= '</select></div></div>';
        echo $html;
    }

    /**
     * Save lifecycle stages based on lifecycleID for a user
    */
    public function saveLifecycleStage()
    {
        if($this->input->post('stage') && $this->input->post('lead_lifecycle_id')){
            $this->db->where('user_id', $this->admin['id']);
            $this->db->delete('lead_company_lifecycle_stages');

            $stage_array = [];
            foreach ($this->input->post('stage') as $key => $stage) {
               $stage_array[] = array(
                                    'user_id'=> $this->admin['id'],
                                    'lead_lifecycle_id'=> $this->input->post('lead_lifecycle_id'),
                                    'stage'=> $stage,
                                    'rank'=> $key+1
                                    );
            }
            if(!empty($stage_array)){
                $this->common_model->batch_insert('lead_company_lifecycle_stages', $stage_array);
                echo 'Success';
            }
        }else{
            echo 'Error';
        }
    }

    /**-------------------------Accounts------------------------------- */
    /*------------------Contact form settings-----------------------------*/
    public function accounts_form()
    {
        $data['element_list'] = $this->common_model->select('accounts_form_elements', ['status'=> 1], '*', 'accounts_form_element_id', 'ASC');
        $data['admin'] = $this->admin;
        $data['content']='admin/settings/accounts-form';
		$this->_load_view($data);
    }

    public function saveAccountsForm()
    {
        //print_r($this->input->post('form_element')); die;
        // //removed old settings if have
        $this->db->where('user_id', $this->admin['id']);
        $this->db->delete('company_accounts_form_elements');

        $required_array = !empty($this->input->post('is_required'))?$this->input->post('is_required'): [];
        $add_array = !empty($this->input->post('quick_add'))?$this->input->post('quick_add'): [];

        $element_array = [];
        if(!empty($this->input->post('form_element'))){
            foreach ($this->input->post('form_element') as $key => $element_id) {
                $element_array[] = array(
                                    'user_id'=> $this->admin['id'],
                                    'accounts_form_element_id'=> $element_id,
                                    'is_required'=> in_array($element_id, $required_array)?1:0,
                                    'quick_add'=> in_array($element_id, $add_array)?1:0
                                    );
            }
        }
        if(!empty($element_array)){
            // echo '<pre>';
            // print_r($element_array);
            $this->common_model->batch_insert('company_accounts_form_elements', $element_array);
            //echo $this->db->last_query();
            echo 'Success';
        }else{
            echo 'Error';
        }
    }
}