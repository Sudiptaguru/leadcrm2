<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends MY_Controller {

	public function __construct() {
		parent::__construct();
        //pr($this->menu_list);
		$this->redirect_guest();
		$this->load->model('admin/mdashboard');
        $this->admin = $this->session->userdata('admin');
		$this->obj=new stdClass();
	}
	private function outputJson($response){
        header('Content-Type: application/json');
        echo json_encode($response);
        exit;
    }
 
	public function index() { 
	    if($this->admin['role_id'] !='2'){
            $this->load_company_dashboard_view();
        }
        else{
            $this->load_dashboard_view();
        }
	}
	
    public function load_dashboard_view(){
        $cond['status']     =  1;
        $data['company']    =   $this->common_model->get('company_master',null, $cond,null,null,null,null,'name','asc',null,null,'result');
        $data['content']    = 'admin/superadmin_dashboard';        
        $this->load->view('admin/layouts/index', $data);
    }
    public function load_company_dashboard_view($companyId =null) {
        if(!empty($companyId)){
            $company_id   = $companyId;
        } 
        else{
            $company_id   = $this->admin['company_id'];
        }        
        $leads_cnt                      = 0;       
        $conversion_cnt                 = 0;  
        $SAL_cnt                        = 0;
        $SQL_cnt                        = 0;
        $MQL_cnt                        = 0;
        $SAL_funnel_cnt                 = 0;
        $ARR_amt                        = 0;
        $open_cnt                       = 0;
        $close_cnt                      = 0;
        $innegotiation_cnt              = 0;
        $lost_cnt                       = 0;
        $lost_ppc_cnt                   = 0;
        $open_ppc_cnt                   = 0;
        $close_ppc_cnt                  = 0;
        $innegotiation_ppc_cnt          = 0;
        $lost_fb_cnt                    = 0;
        $open_fb_cnt                    = 0;
        $close_fb_cnt                   = 0;
        $innegotiation_fb_cnt           = 0;
        $leads_pct                      = 0; 
        $MQL_pct                        = 0;
        $conversion_pct                 = 0;
        $bar_date                       = array();
        $leadsData                      = array();
        $admin = $this->session->userdata('admin');
        //echo "<pre>";print_r($admin);die();
        $postData   = $this->input->post();
        $end_date_cnt       = date('Y-m-d');
        $start_date_cnt     = date('Y-m-d', strtotime('-30 days'));
        if(!empty($postData)){
            $end_date       = date('Y-m-d',strtotime($this->input->post('to_dt')));
            $start_date     = date('Y-m-d',strtotime($this->input->post('frm_dt')));
        }
        else{
            $end_date       = date('Y-m-d');
            $start_date     = date('Y-m-d', strtotime('-30 days'));
        }
        //echo $end_date.'<br>'.$start_date;exit;
        $Astart_date    = date('Y-m-d', strtotime('-365 days'));
        $leads          = $this->mdashboard->dashboardCount($company_id,$start_date_cnt,$end_date_cnt,'leads');
        $conversion     = $this->mdashboard->dashboardCount($company_id,$start_date_cnt,$end_date_cnt,'conversion');
        $SAL            = $this->mdashboard->dashboardCount($company_id,$start_date_cnt,$end_date_cnt,'SAL');
        $SQL            = $this->mdashboard->dashboardCount($company_id,$start_date,$end_date,'SQL');
        $ARR            = $this->mdashboard->dashboardCount($company_id,$Astart_date,$end_date_cnt,'ARR');
        $MQL            = $this->mdashboard->dashboardCount($company_id,$start_date,$end_date,'leads');
        $SAL_funnel     = $this->mdashboard->dashboardCount($company_id,$start_date,$end_date,'SAL');
        if(!empty($postData) && !empty($postData['lead_status'])){
            $lead_status          = $this->mdashboard->dashboardCount($company_id,$start_date,$end_date,null,$postData['lead_status']); 
            if($postData['lead_status'] =='awarded') {
                $close          = $lead_status;
            }
            else if($postData['lead_status'] =='open'){
                $open           = $lead_status;
            }
            else if($postData['lead_status'] =='innegotiation'){
                $innegotiation   = $lead_status;
            }
            else if($postData['lead_status'] =='lost'){
                $lost           = $lead_status;
            }  
            
            $data['lead_status']       = $postData['lead_status'];       
        }
        else{
            $close          = $this->mdashboard->dashboardCount($company_id,$start_date,$end_date,'','awarded');
            $open           = $this->mdashboard->dashboardCount($company_id,$start_date,$end_date,'','open');
            $innegotiation  = $this->mdashboard->dashboardCount($company_id,$start_date,$end_date,'','innegotiation');
            $lost           = $this->mdashboard->dashboardCount($company_id,$start_date,$end_date,'','lost'); 
        }
        if(!empty($postData) && !empty($postData['lead_source'])){
            $lost_lead_status           = $this->mdashboard->dashboardCount($company_id,$start_date,$end_date,'','lost',$postData['lead_source']);
            $close_lead_status          = $this->mdashboard->dashboardCount($company_id,$start_date,$end_date,'','awarded',$postData['lead_source']);
            $open_lead_status           = $this->mdashboard->dashboardCount($company_id,$start_date,$end_date,'','open',$postData['lead_source']);
            $innegotiation_lead_status  = $this->mdashboard->dashboardCount($company_id,$start_date,$end_date,'','innegotiation',$postData['lead_source']);
            if($postData['lead_source'] =='ppc') {
                $lost_ppc           = $lost_lead_status;
                $close_ppc          = $close_lead_status;
                $open_ppc           = $open_lead_status;
                $innegotiation_ppc  = $innegotiation_lead_status;
            }
            else if($postData['lead_source'] =='fb'){
                $lost_fb           = $lost_lead_status;
                $close_fb          = $close_lead_status;
                $open_fb           = $open_lead_status;
                $innegotiation_fb  = $innegotiation_lead_status;
            }
            $data['lead_source']       = $postData['lead_source'];            
        }
        else{
            $lost_ppc           = $this->mdashboard->dashboardCount($company_id,$start_date,$end_date,'','lost','ppc');
            $close_ppc          = $this->mdashboard->dashboardCount($company_id,$start_date,$end_date,'','awarded','ppc');
            $open_ppc           = $this->mdashboard->dashboardCount($company_id,$start_date,$end_date,'','open','ppc');
            $innegotiation_ppc  = $this->mdashboard->dashboardCount($company_id,$start_date,$end_date,'','innegotiation','ppc');
            $lost_fb            = $this->mdashboard->dashboardCount($company_id,$start_date,$end_date,'','lost','fb');
            $close_fb           = $this->mdashboard->dashboardCount($company_id,$start_date,$end_date,'','awarded','fb');
            $open_fb            = $this->mdashboard->dashboardCount($company_id,$start_date,$end_date,'','open','fb');
            $innegotiation_fb   = $this->mdashboard->dashboardCount($company_id,$start_date,$end_date,'','innegotiation','fb');
        }
        
        $leads_data             = $this->mdashboard->getLeadsListByMonth($company_id);
        //pr($leads_data);
       //pr($conversion);
        if(!empty($leads)){
            $leads_cnt  = count($leads);
            $tmp_leads_cnt  = ($leads_cnt/30)*100;
            $data['details']= $leads;
            foreach($leads as $val){
                $bar_date[]     = date('d M Y',STRTOTIME($val->post_date));                
            }
        }
        if(!empty($leads_data)){
            foreach($leads_data as $year){
                foreach($year as $months){
                    foreach($months as $key => $list){
                        $leadsData[$key] = count($list);
                    }
                }
            }            
        }        
        if(!empty($SAL)){
            $SAL_cnt        = count($SAL);
            $tmp_SAL_cnt    = ($SAL_cnt/30)*100;
        }
        if(!empty($conversion)){
            $conversion_cnt  = count($conversion);
            $tmp_conversion_cnt    = ($conversion_cnt/30)*100;
        }
        if(!empty($ARR)){
            foreach($ARR as $val){
                $ARR_amt = $ARR_amt + $val->closing_price;
            }
        }
        if(!empty($SQL)){
            $SQL_cnt  = count($SQL);
        }
        if(!empty($MQL)){
            $MQL_cnt  = count($MQL);
        }
        if(!empty($SAL_funnel)){
            $SAL_funnel_cnt  = count($SAL_funnel);
        }
        if(!empty($close)){
            $close_cnt  = count($close);
        }
        if(!empty($open)){
            $open_cnt  = count($open);
        }
        if(!empty($innegotiation)){
            $innegotiation_cnt  = count($innegotiation);
        }
        if(!empty($lost)){
            $lost_cnt  = count($lost);
        }
        if(!empty($close_ppc)){
            $close_ppc_cnt  = count($close_ppc);
        }
        if(!empty($open_ppc)){
            $open_ppc_cnt  = count($open_ppc);
        }
        if(!empty($innegotiation_ppc)){
            $innegotiation_ppc_cnt  = count($innegotiation_ppc);
        }
        if(!empty($lost_ppc)){
            $lost_pcc_cnt  = count($lost_ppc);
        }
         if(!empty($close_fb)){
            $close_fb_cnt  = count($close_fb);
        }
        if(!empty($open_fb)){
            $open_fb_cnt  = count($open_fb);
        }
        if(!empty($innegotiation_fb)){
            $innegotiation_fb_cnt  = count($innegotiation_fb);
        }
        if(!empty($lost_fb)){
            $los_fb_cnt  = count($lost_fb);
        }
        $lead_percentage_data   = $this->common_model->getRow('leads_percentage',array('company_id' =>$company_id));
        if(empty($lead_percentage_data)){
            $leads_pct      = ($leads_cnt/30)*100;
            $MQL_pct        = ($MQL_cnt/30)*100;
            $SAL_pct        = ($SAL_cnt/30)*100;
            $conversion_pct = ($conversion_cnt/30)*100;
            $isertArr       = array(    'company_id'  =>$company_id,
                                        'leads'       =>ROUND($leads_pct,2),
                                        'MQL'         =>ROUND($MQL_pct,2),
                                        'SAL'         =>ROUND($SAL_pct,2),
                                        'conversion'  =>ROUND($conversion_pct,2)
                                    );
            $this->common_model->add('leads_percentage',$isertArr);
        }
        else{
            $prvc_leads_pct         = $lead_percentage_data['leads'];
            $prvc_MQL_pct           = $lead_percentage_data['MQL'];
            $prvc_SAL_pct           = $lead_percentage_data['SAL'];
            $prvc_conversion_pct    = $lead_percentage_data['conversion'];
            $leads_pct              = (($leads_cnt/30)*100) - $prvc_leads_pct;
            $MQL_pct                = (($MQL_cnt/30)*100) - $prvc_MQL_pct;
            $SAL_pct                = (($SAL_cnt/30)*100) - $prvc_SAL_pct;
            $conversion_pct         = (($conversion_cnt/30)*100) - $prvc_conversion_pct;

            $updateArr       = array( 
                                      'leads'       =>ROUND($leads_pct,2),
                                      'MQL'         =>ROUND($MQL_pct,2),
                                      'SAL'         =>ROUND($SAL_pct,2),
                                      'conversion'  =>ROUND($conversion_pct,2)
                                    );
            $this->common_model->update('leads_percentage',$updateArr,array('company_id' =>$company_id));
        }
        $data['leads_pct']      = ROUND($leads_pct,2);
        $data['MQL_pct']        = ROUND($MQL_pct,2);
        $data['SAL_pct']        = ROUND($SAL_pct,2);
        $data['conversion_pct'] = ROUND($conversion_pct,2);
        $data['leads']          = $leads_cnt;
        $data['MQL']            = $leads_cnt;
        $data['SAL']            = $SAL_cnt;
        $data['SQL']            = $SQL_cnt;
        $data['MQL_cnt']        = $MQL_cnt;
        $data['SAL_funnel_cnt'] = $SAL_funnel_cnt;
        $data['conversion']     = ROUND((($conversion_cnt/30)*100),2);
        $data['ARR_amt']        = $ARR_amt;
        $data['lost']           = $lost_cnt;
        $data['innegotiation']  = $innegotiation_cnt;
        $data['open']           = $open_cnt;
        $data['close']          = $close_cnt;
        $data['lost_ppc']       = $lost_ppc_cnt;
        $data['innegotiation_ppc']  = $innegotiation_ppc_cnt;
        $data['open_ppc']          = $open_ppc_cnt;
        $data['close_ppc']         = $close_ppc_cnt;
        $data['lost_fb']           = $lost_cnt;
        $data['innegotiation_fb']  = $innegotiation_fb_cnt;
        $data['open_fb']           = $open_fb_cnt;
        $data['close_fb']          = $close_fb_cnt;
        //$data['bar_date']       = implode(',',$bar_date);
        $data['bar_date']          = $bar_date;
        $data['leads_data_cnt']    = implode(',',$leadsData);
        
      //pr($data);
        $data['content'] = 'admin/dashboard';        
        $this->load->view('admin/layouts/index', $data);
    }
    
	public function changeStatus()
    {
        //echo "fshdfjksh";exit;
        $this->isJSON(file_get_contents('php://input'));
        $postData = $this->extract_json(file_get_contents('php://input'));
        //pr($postData);
        if ($postData) {
            //echo "dsfn";exit;
            if ($this->common_model->update($postData['table'], ['status' => $postData['status']], [$postData['indexKey'] => $postData['id']])) {
                //echo $this->db->last_query(); exit;
                //echo "344";exit;
                $this->response = array('status' => array('error_code' => 0, 'message' => 'Status Changed Successfully'), 'result' => array('data' => $this->obj));
            } else {
                //echo "777";exit;                  
                $this->response = array('status' => array('error_code' => 1, 'message' => 'Unable to Process Data'), 'result' => array('data' => $this->obj));
            }
        } else {
            //echo "4324";exit;
            $this->response = array('status' => array('error_code' => 1, 'message' => 'Unable to Parse Request Data'), 'result' => array('data' => $this->obj));
        }
        //pr($this->response);
        $this->outputJson($this->response);
    }
}